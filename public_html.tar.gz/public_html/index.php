<?php require("lib/page_top.php") ?>
<?php require("lib/index.php") ?>
<?php require("lib/page_body.php") ?>
