<?php
$bool_login= false;

if(isset($_POST['username']) && isset($_POST['password'])){
	if(($_POST['username'] == "user") && ($_POST['password'] == "Iowa2015?")){
		$bool_login = true;
		page();
	}
	else {
		echo "Invalid login<br><br>";
	}
}

if(! $bool_login){
	echo '
<form action="download.new.php" method="post">
Username: <input type="text" name="username"><br>
Password: <input type="password" name="password"><br>
<input type="submit" name="Login">
</form>';

}

function page(){
echo "
<style>
body {font-family: monospace;}
</style>

Date: 28 Nov 2015<br><br>

Steps taken:<br>
1. Download the W22 Fasta file: W22.v3.genome.fa<br><br>
2. Run Repeatmasker on individual files<br>
$ ./RepeatMasker -nolow -lib mtec_mips_repeats.fa -x -pa 8 W22.v3.genome.fa<br>
Output: W22.v3.genome.masked.fa<br><br>
Download: <a target='_blank' href='data/W22v3/W22.v3.genome.masked.fa'>W22.v3.genome.masked.fa</a><br><br>

+++++<br>
Parsed BLAST output: <br>
Input: AcDs(masked) 3133 sequences<br>
Database: W22.v3(masked) 12 sequences<br><br>
Assigning Quality and Placement<br> 
<!-- Updated: 11_28_2015(18:00) <a target='_blank' href='data/W22v3/out.DsAc_3133seq.fasta.masked_vs_W22.v3.genome.masked.fa.m8'>out.DsAc_3133seq.fasta.masked_vs_W22.v3.genome.masked.fa.m8</a> -->
Updated: 12_01_2015(06:00) <a target='_blank' href='data/W22v3/DsAc_3133seq.fasta.masked_vs_W22.v3.genome.masked.fa.m8.blout.solar.sql.out.txt'>DsAc_3133seq.fasta.masked_vs_W22.v3.genome.masked.fa.m8.blout.solar.sql.out.txt</a>
<br><br>
Predicted Ds Insertion site: column named 'ds_coord' <br>
<!-- Updated: 11_28_2015(18:00) <a target='_blank' href='data/W22v3/ins.DsAc_3133seq.fasta.masked_vs_W22.v3.genome.masked.fa.m8'>ins.DsAc_3133seq.fasta.masked_vs_W22.v3.genome.masked.fa.m8</a> -->
Updated: 12_01_2015(06:00) <a target='_blank' href='data/W22v3/DsAc_3133seq.fasta.masked_vs_W22.v3.genome.masked.fa.m8.blout.solar.sql.ins.txt'>DsAc_3133seq.fasta.masked_vs_W22.v3.genome.masked.fa.m8.blout.solar.sql.ins.txt</a>
<br><br>
+++++<br>
Parsed BLAST output: <br>
Input: AcDs(unmasked) 3133 sequences<br>
Database: W22.v3(masked) 12 sequences<br><br>
Assigning Quality and Placement<br> 
<!--Updated: 11_28_2015(18:00) <a target='_blank' href='data/W22v3/out.DsAc_3133seq.fasta_vs_W22.v3.genome.masked.fa.m8'>out.DsAc_3133seq.fasta_vs_W22.v3.genome.masked.fa.m8</a>-->
Updated: 12_01_2015(06:00) <a target='_blank' href='data/W22v3/DsAc_3133seq.fasta_vs_W22.v3.genome.masked.fa.m8.blout.solar.sql.out.txt'>DsAc_3133seq.fasta_vs_W22.v3.genome.masked.fa.m8.blout.solar.sql.out.txt</a>
<br><br>
Predicted Ds Insertion site: column named 'ds_coord' <br>
<!-- Updated: 11_28_2015(18:00) <a target='_blank' href='data/W22v3/ins.DsAc_3133seq.fasta_vs_W22.v3.genome.masked.fa.m8'>ins.DsAc_3133seq.fasta_vs_W22.v3.genome.masked.fa.m8</a> -->
Updated: 12_01_2015(06:00) <a target='_blank' href='data/W22v3/DsAc_3133seq.fasta_vs_W22.v3.genome.masked.fa.m8.blout.solar.sql.ins.txt'>DsAc_3133seq.fasta_vs_W22.v3.genome.masked.fa.m8.blout.solar.sql.ins.txt</a>
<br><br>
+++++<br>
Parsed BLAST output: <br>
Input: AcDs(masked) 3133 sequences<br>
Database: W22.v3(unmasked) 12 sequences<br><br>
Assigning Quality and Placement<br> 
<!-- Updated: 11_28_2015(18:00) <a target='_blank' href='data/W22v3/out.DsAc_3133seq.fasta.masked_vs_W22.v3.genome.fa.m8'>out.DsAc_3133seq.fasta.masked_vs_W22.v3.genome.fa.m8</a> -->
Updated: 12_01_2015(06:00) <a target='_blank' href='data/W22v3/DsAc_3133seq.fasta.masked_vs_W22.v3.genome.fa.m8.blout.solar.sql.out.txt'>DsAc_3133seq.fasta.masked_vs_W22.v3.genome.fa.m8.blout.solar.sql.out.txt</a>
<br><br>
Predicted Ds Insertion site: column named 'ds_coord' <br>
<!-- Updated: 11_28_2015(18:00) <a target='_blank' href='data/W22v3/ins.DsAc_3133seq.fasta.masked_vs_W22.v3.genome.fa.m8'>ins.DsAc_3133seq.fasta.masked_vs_W22.v3.genome.fa.m8</a> -->
Updated: 12_01_2015(06:00) <a target='_blank' href='data/W22v3/DsAc_3133seq.fasta.masked_vs_W22.v3.genome.fa.m8.blout.solar.sql.ins.txt'>DsAc_3133seq.fasta.masked_vs_W22.v3.genome.fa.m8.blout.solar.sql.ins.txt</a>
<br><br>
+++++<br>
Parsed BLAST output: <br>
Input: AcDs(unmasked) 3133 sequences<br>
Database: W22.v3(unmasked) 12 sequences<br><br>
Assigning Quality and Placement<br> 
<!-- Updated: 11_28_2015(18:00) <a target='_blank' href='data/W22v3/out.DsAc_3133seq.fasta_vs_W22.v3.genome.fa.m8'>out.DsAc_3133seq.fasta_vs_W22.v3.genome.fa.m8</a> -->
Updated: 12_01_2015(06:00) <a target='_blank' href='data/W22v3/DsAc_3133seq.fasta_vs_W22.v3.genome.fa.m8.blout.solar.sql.out.txt'>DsAc_3133seq.fasta_vs_W22.v3.genome.fa.m8.blout.solar.sql.out.txt</a>
<br><br>
Predicted Ds Insertion site: column named 'ds_coord' <br>
<!-- Updated: 11_28_2015(18:00) <a target='_blank' href='data/W22v3/ins.DsAc_3133seq.fasta_vs_W22.v3.genome.fa.m8'>ins.DsAc_3133seq.fasta_vs_W22.v3.genome.fa.m8</a> -->
Updated: 12_01_2015(06:00) <a target='_blank' href='data/W22v3/DsAc_3133seq.fasta_vs_W22.v3.genome.fa.m8.blout.solar.sql.ins.txt'>DsAc_3133seq.fasta_vs_W22.v3.genome.fa.m8.blout.solar.sql.ins.txt</a>
<br><br>
<hr>
		
Parsed BLAST output: <br>
Input: AcDs(masked) 3133 sequences<br>
Database: Zea_mays.AGPv3.25(masked) 12 sequences<br><br>
Assigning Quality and Placement<br> 
Updated: 12_01_2015(06:00) <a target='_blank' href='data/W22v3/DsAc_3133seq.fasta.masked_vs_Zea_mays.AGPv3.25.dna_rm.chromosome.fa.blout.solar.sql.out.txt'>DsAc_3133seq.fasta.masked_vs_Zea_mays.AGPv3.25.dna_rm.chromosome.fa.blout.solar.sql.out.txt</a>
<br><br>
Predicted Ds Insertion site: column named 'ds_coord' <br>
Updated: 12_01_2015(06:00) <a target='_blank' href='data/W22v3/DsAc_3133seq.fasta.masked_vs_Zea_mays.AGPv3.25.dna_rm.chromosome.fa.blout.solar.sql.ins.txt'>DsAc_3133seq.fasta.masked_vs_Zea_mays.AGPv3.25.dna_rm.chromosome.fa.blout.solar.sql.ins.txt</a>
<br><br>
+++++<br>
Parsed BLAST output: <br>
Input: AcDs(unmasked) 3133 sequences<br>
Database: Zea_mays.AGPv3.25(masked) 12 sequences<br><br>
Assigning Quality and Placement<br> 
Updated: 12_01_2015(06:00) <a target='_blank' href='data/W22v3/DsAc_3133seq.fasta_vs_Zea_mays.AGPv3.25.dna_rm.chromosome.fa.blout.solar.sql.out.txt'>DsAc_3133seq.fasta_vs_Zea_mays.AGPv3.25.dna_rm.chromosome.fa.blout.solar.sql.out.txt</a>
<br><br>
Predicted Ds Insertion site: column named 'ds_coord' <br>
Updated: 12_01_2015(06:00) <a target='_blank' href='data/W22v3/DsAc_3133seq.fasta_vs_Zea_mays.AGPv3.25.dna_rm.chromosome.fa.blout.solar.sql.ins.txt'>DsAc_3133seq.fasta_vs_Zea_mays.AGPv3.25.dna_rm.chromosome.fa.blout.solar.sql.ins.txt</a>
<br><br>
+++++<br>
Parsed BLAST output: <br>
Input: AcDs(masked) 3133 sequences<br>
Database: Zea_mays.AGPv3.25(unmasked) 12 sequences<br><br>
Assigning Quality and Placement<br> 
Updated: 12_01_2015(06:00) <a target='_blank' href='data/W22v3/DsAc_3133seq.fasta.masked_vs_Zea_mays.AGPv3.25.dna.chromosome.fa.blout.solar.sql.out.txt'>DsAc_3133seq.fasta.masked_vs_Zea_mays.AGPv3.25.dna.chromosome.fa.blout.solar.sql.out.txt</a>
<br><br>
Predicted Ds Insertion site: column named 'ds_coord' <br>
Updated: 12_01_2015(06:00) <a target='_blank' href='data/W22v3/DsAc_3133seq.fasta.masked_vs_Zea_mays.AGPv3.25.dna.chromosome.fa.blout.solar.sql.ins.txt'>DsAc_3133seq.fasta.masked_vs_Zea_mays.AGPv3.25.dna.chromosome.fa.blout.solar.sql.ins.txt</a>
<br><br>
+++++<br>
Parsed BLAST output: <br>
Input: AcDs(unmasked) 3133 sequences<br>
Database: Zea_mays.AGPv3.25(unmasked) 12 sequences<br><br>
Assigning Quality and Placement<br> 
Updated: 12_01_2015(06:00) <a target='_blank' href='data/W22v3/DsAc_3133seq.fasta_vs_Zea_mays.AGPv3.25.dna.chromosome.fa.blout.solar.sql.out.txt'>DsAc_3133seq.fasta_vs_Zea_mays.AGPv3.25.dna.chromosome.fa.blout.solar.sql.out.txt</a>
<br><br>
Predicted Ds Insertion site: column named 'ds_coord' <br>
Updated: 12_01_2015(06:00) <a target='_blank' href='data/W22v3/DsAc_3133seq.fasta_vs_Zea_mays.AGPv3.25.dna.chromosome.fa.blout.solar.sql.ins.txt'>DsAc_3133seq.fasta_vs_Zea_mays.AGPv3.25.dna.chromosome.fa.blout.solar.sql.ins.txt</a>
<br><br>
+++++<br>
		
<br>
<br>
<br>
";
}


?>
