<?php
$bool_login= false;

if(isset($_POST['username']) && isset($_POST['password'])){
	if(($_POST['username'] == "user") && ($_POST['password'] == "Iowa2015?")){
		$bool_login = true;
		page();
	}
	else {
		echo "Invalid login<br><br>";
	}
}

if(! $bool_login){
	echo '
<form action="download.php" method="post">
<input type="text" name="username">
<input type="password" name="password">
<input type="submit" name="Login">
</form>';

}

function page(){
echo "
<style>
body {font-family: monospace;}
</style>

Date: 15 Dec 2016<br><br>

1. Download the documentation <a href='data/20161215/2015_04_06W22.docx'>2015_04_06W22.docx</a><br>
2. Download the MySQL database backup <a href='data/20161215/acdstagging.sql'>acdstagging.sql</a><br>
3. Download the scripts and solar program <a href='data/20161215/scripts.tar.gz'>scripts.tar.gz</a><br>


			";
}


?>
