<?php require("../lib/page_top.php") ?>
<?php 
if($_GET['id']){
	$getbarcode = $_GET['id'];
}
else {
	$getbarcode = 'B.S05.0006';
}

?>

<h2>AcDs Tagging Seed Order Form </h2>

<form id="myForm" method="POST" action="confirm.php">
<table width="100%">
	<tr>
	<td width="50%" valign="top">
		<table class="data_entry" border="0">
		<h3>Ship To: Enter complete shipping and contact info:</h3>
		<tr>
			<td width="200">First Name</td>
			<td width="300"><input type="text" name="sfname" size="15" value=""></td>
		</tr>
		<tr>
			<td>Last Name</td>
			<td><input type="text" name="slname" size="15" value=""></td>
		</tr>
		<tr>
			<td>Department</td>
			<td><input type="text" name="sdepartment" size="15" value=""></td>
		</tr>
		<tr>
			<td>Company/School</td>
			<td><input type="text" name="sinstitution" size="15" value=""></td>
		</tr>
		<tr>
			<td>Street Address</td>
			<td><input type="text" name="sstreet_address" size="30" value=""></td>
		</tr>
		<tr>
			<td>City</td>
			<td><input type="text" name="scity" size="15" value=""></td>
		</tr>
		<tr>
			<td>Country</td>
			<td><input type="text" name="scountry" size="15" value=""></td>
		</tr>
		<tr>
			<td>State</td>
			<td><input type="text" name="sstate" id="sstate" size="15" value="" /></td>
		</tr>
		<tr>
			<td>Zip</td>
			<td><input type="text" name="szip" size="8" value=""></td>
		</tr>
		<tr>
			<td>Email</td>
			<td><input type="text" name="semail" size="20" value=""></td>
		</tr>
		<tr>
			<td>Phone #</td>
			<td><input type="text" name="sphone" size="15" value=""></td>
		</tr>
		<tr>
			<td>Project Leader</td>
			<td><input type="text" name="sproject_leader" size="15" value=""></td>
		</tr>
		<tr>
			<td>Purchase Order #</td>
			<td><input type="text" name="spurchase_order" size="15" value=""></td>
		</tr>
		</table>
	</td>
	<td width="50%" valign="top">
		<table class="data_entry" border="0">
		<h3>Bill To: (if different than Ship To) <input type="checkbox" name="billing" value="1" onchange="updateBillingAddress()" ></h3>
		<tr>
			<td width="100" >First Name</td>
			<td width="300"><input type="text" name="bfname" size="15" value=""></td>
		</tr>
		<tr>
			<td width="100" >Last Name</td>
			<td width="300"><input type="text" name="blname" size="15" value=""></td>
		</tr>	
		<tr>
			<td width="100" >Department</td>
			<td width="300"><input type="text" name="bdepartment" size="15" value=""></td>
		</tr>
		<tr>
			<td width="100" >Company/School</td>
			<td width="300"><input type="text" name="binstitution" size="15" value=""></td>
		</tr>
		<tr>
			<td width="100" >Street Address</td>
			<td width="300"><input type="text" name="bstreet_address" size="30" value=""></td>
		</tr>
		<tr>
			<td width="100" >City</td>
			<td width="300"><input type="text" name="bcity" size="15" value=""></td>
		</tr>
		<tr>
			<td width="100" >Country</td>
			<td width="300"><input type="text" name="bcountry" size="15" value=""></td>
		</tr>
		<tr>
			<td width="100" >State</td>
			<td width="300"><input type="text" name="bstate" id="bstate" size="15" value=""/></td>
  	</tr>
		<tr>
			<td width="100" >Zip</td>
			<td width="300"><input type="text" name="bzip" size="8" value=""></td>
		</tr>
		<tr>
			<td width="100" >Email</td>
			<td width="300"><input type="text" name="bemail" size="20" value=""></td>
		</tr>
		<tr>
			<td width="100" >Phone #</td>
			<td width="300"><input type="text" name="bphone" size="15" value=""></td>
		</tr>
		</table>
	</td>
	</tr>
</table>

<script>
$("#myForm").submit(function(event){
	v = validateForm();
	//getSegregates();
	//return v;
	console.log("____________test_________");
	console.log(v);
	if($("#grand_total").val() == 0){
		return false;
	}
	return v;
	//event.preventDefault();
});



function isValidEmailAddress(emailAddress) {
    var pattern = new RegExp(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i);
    return pattern.test(emailAddress);
};

function validateForm(){
	check = true;
	barr = new Array("bfname", "blname", "bdepartment", "binstitution", "bstreet_address", "bcity", "bstate", "bcountry", "bzip", "bemail", "bphone");
	sarr = new Array("sfname", "slname", "sdepartment", "sinstitution", "sstreet_address", "scity", "sstate", "scountry", "szip", "semail", "sphone", "sproject_leader", "spurchase_order", "grand_total");
	bool_checked = $("[name=billing]").is(":checked");
	if(bool_checked){
		tarr = $.merge(barr, sarr);
		if(!isValidEmailAddress($("[name=bemail]").val())){
			$("[name=bemail]").css({"border": "1px solid red"});
			check = false;
		} else {
			$("[name=bemail]").css({"border": ""});
		}
	} else {
		tarr = sarr;
	}
	$.each(tarr, function(k, v){
		if(! checkMark(v)){
			check = false
		}
	});
	if(!isValidEmailAddress($("[name=semail]").val())){
		$("[name=semail]").css({"border": "1px solid red"});
		check = false;
	} else {
		$("[name=semail]").css({"border": ""});
	}
	if(! check){
		return false;
	}
	console.log(check);
	createJson(tarr);
	return check;
}

jobj = {};
function createJson(tarr){
	$.each(tarr, function(k, v){
		jobj[v] = $("[name=" + v + "]").val()
	});
	bool_checked = $("[name=billing]").is(":checked");
	if(! bool_checked){
		$.each(tarr, function(k, v){
			bv = v.replace(/^s/, 'b');
			//console.log(bv, v);
			jobj[bv] = $("[name=" + v + "]").val()
		});
	}
	//console.log(jobj);
	getTable();
}

function getTable(){
	jobj["order"] = {};
	$("#dataload tr").each(function(i,row){
		q = $(row).children().eq(0).text();
		b = $(row).children().eq(1).text();
		if((q == "Quantity") || (b == "Barcode")){
			return;
		}
		if(b in jobj["order"]){
			//jobj["order"][b]['sum'] =  parseInt(jobj["order"][b]) + parseInt(q);
			jobj["order"][b] =  parseInt(jobj["order"][b]) + parseInt(q);
		} else {
			//jobj["order"][b]['sum'] = q
			jobj["order"][b] = q
		}
	});
	jobj["seg"] = {};
	$("#dataload tr").each(function(i,row){
		q = $(row).children().eq(0).text();
		b = $(row).children().eq(1).text();
		if((q == "Quantity") || (b == "Barcode")){
			return;
		}
		jobj["seg"][b] = "k";
		ok = $(row).children().eq(2).html();
		//console.log($(ok).html());
		jobj["seg"][b] = $(ok).html();
	});
	console.log(jobj["seg"]);
	console.log(jobj["order"]);
	if($("#certification").is(":checked")){
		jobj['certification'] = 1;
	} else {
		jobj['certification'] = 0;
	}
	if($("#expedited").is(":checked")){
		jobj['expedited'] = 1;
	} else {
		jobj['expedited'] = 0;
	}
	jobj['price'] = getPrice();
	data = JSON.stringify(jobj);
	console.log("218: kashi");
	console.log(data);
	console.log($("[name=kkkkk]").val());
	$('[name=kkkkk]').val(data);
	console.log($("[name=kkkkk]").val());
}

function checkMark(name){
	//console.log(name);
	if($("[name=" + name + "]").val() == ""){
		$("[name=" + name + "]").css({"border": "1px solid red"});
		return false;
	} else {
		$("[name=" + name + "]").css({"border": ""});
		return true;
	}
}

function updateBillingAddress(){
	console.log("kashi");
	bool_checked = $("[name=billing]").is(":checked");
	if(bool_checked){
		$("[name=bfname]").val("");
		$("[name=bstate_other]").val("");
		$("[name=bzip]").val("");
		$("[name=bemail]").val("");
		$("[name=bphone]").val("");
		$("[name=bfname]").val("");
		$("[name=bstate]").val("");
		//a = $("select[name=bstate]").val();
		//$("select[name=bstate]").find('option:contains("' +a +'")').removeAttr("selected");
		$("[name=bcountry]").val("");
		$("[name=bcity]").val('');
		$("[name=bstreet_address]").val('');
		$("[name=binstitution]").val('');
		$("[name=bdepartment]").val('');
		$("[name=blname]").val('');
	}
}

function togglefield(val,tbox) {
	var o = document.getElementById(tbox);
	(val == 'Other')? o.style.display = 'block' : o.style.display = 'none';
}

function addrow(){
	//$("#errorInput").css({"display": "none"});
	$("#dataload").css({"display": "block"});
	getPrice();
	//console.log("here");
	q = getQuantity();
	patt = new RegExp("[a-z]+");
	if(patt.test(q)){
		console.log("error");
		error("ERROR: Quantity should be numeral.");
	}
	b = getBarcode();
	//console.log(q,b);
	getinfo(q, b);
}
function error(txt){
	$("#errorInput").css({"display": "block"});
	$("#errorInput").val(txt);
}
function getQuantity(){
	return $("#quantity").val();
}

function getPrice(){
	return $("input[name=price]:checked").val();
}

function getBarcode(){
	return $("#barcode").val();
}
function removeFrom(ele){
	tr = $(ele).closest('tr');
	console.log(tr);
	$(tr).remove();
	updateTotal();
}

function getinfo(quantity, barcode){
	$('#errorSpan').remove();
	$("#errorInput").css('display', 'none');
	$("#errorInput").empty();
	$.ajax({
		url: '/ajax/searchBarcode.php',
		data: {
			barcode: barcode
		},
		dataType: 'json',
		method: 'GET',
		success: function(data){
			$("#errorInput").html('display', 'none');
			console.log(data.stock_center_id);
			console.log("---");
			if(data.length === 0){
				console.log("empty");
				var ss = $('<span/>', {'id':'errorSpan', 'text': '  ID not present'}); 		
				//$("#addbutton").after(ss);
				$("#errorInput").html(ss);
				$("#errorInput").css('display', 'block');
			} else if(data.stock_center_id === null){
				//console.log("available");
				string = []; 
				string.push(quantity);
				string.push(data.barcode);
				string.push(" \
						<span style='display:none'>Yes</span> \
						<span style='border: 5px solid teal; padding: 5px; cursor: pointer' onclick='toggleme(this)'>Yes</span> \
						&nbsp; \
						<span style='border: 0px solid teal; padding: 5px; cursor: pointer' onclick='togglethat(this)'>No</span> \
						&nbsp;<span style='display:none'>ANS</span> \
						");
				string.push(data.placement);
				string.push(data.bac_gi);
				string.push(data.ds_coord);
				price = getPrice();
				string.push((parseFloat(quantity) * price).toFixed(2));
				//string.push("<input type='button' value='remove' onclick=\"$(this).closest('tr').remove();\"> ");
				string.push("<input type='button' value='remove' onclick=\"removeFrom(this)\"> ");
				line = "<tr><td>";
				row = line.concat(string.join("</td><td>"), "</td></tr>");
				//console.log(row);
				$("#table_placeholder").remove();
				$("#dataload tr:last").after(row);
				updateTotal();
			}
			else {
				console.log("here");
				var ss = '<br>The barcode '+ barcode +' is only available at Maize COOP.<br>';
				ss = ss + 'Lookup the barcodes at Maize COOP Stocks Information <a href="http://archive.maizegdb.org/stockbasicquery.php" target="_blank">Simple Query</a>.'; 
				ss = ss + '<br>If you like to order it through this site, please contact <a href="mailto:ka38@cornell.edu" target="_blank">Kevin Ahern</a>.'; 
				$("#errorInput").html(ss);
				$("#errorInput").css('display', 'block');
			}
			//$('#result').html(data);
		},
		//* If error. show the error in console.log
		error: function(XMLHttpRequest, textStatus, errorThrown) {
			console.log(textStatus+" - "+errorThrown);
			console.log(XMLHttpRequest.responseText);
		}
	});
}

function updateTotal(){
	total = 0;
	$("#dataload tr").each(function(i,row){
		ok = $(row).children().eq(6).text();
		//console.log(ok);
		if(ok == "Price"){
			return;
		}
		total = total + parseInt(ok);
	});
	//console.log(total);
	$("#subtotal").val(total);
	grandTotal(total);
}

function grandTotal(total){
	subtotal = $("#subtotal").val();
	if($("#certification").is(":checked")){
		total = total + 60;
	}
	exp = $("#expedited").is(":checked");
	//console.log(subtotal, exp);
	$("#grand_total").val(total);
}
	
function get(){
	$('#dataentry tr').each(function() {
		q = $(this).find("td").eq(1).find("input");
		v = $(q).val();
		console.log(q);
		console.log(v);
	});
}

function updateTotal(){
	total = 0;
	$("#dataload tr").each(function(i,row){
		ok = $(row).children().eq(6).text();
		//console.log(ok);
		if(ok == "Price"){
			return;
		}
		total = total + parseInt(ok);
	});
	//console.log(total);
	$("#subtotal").val(total);
	grandTotal(total);
}

function getSegregates(){
	console.log("line 387");
	total = 0;
	$("#dataload tr").each(function(i,row){
		ok = $(row).children().eq(2).html();
		if(ok == "Segregates Ac"){
			//return;
		}
		//$(ok).children().each(function(){
			console.log($(ok).html());
		//});
		//l = $(ok).children("span");
		//console.log($(l));
	});
}

function toggleme(ok){
	console.log($(ok).html());
	$(ok).css({"border": "5px solid teal", "padding": "5px"});
	p = $(ok).next();
	$(p).css({"border": "0px", "padding": "5px"});
	
	//n = $(ok).next().next();
	//console.log($(n).html());
	//$(n).html("yes");
	n = $(ok).prev();
	//console.log($(n).html());
	$(n).html("Yes");
	//console.log($(n).html());
}
function togglethat(ok){
	console.log($(ok).html());
	$(ok).css({"border": "5px solid teal", "padding": "5px"});
	p = $(ok).prev();
	$(p).css({"border": "0px", "padding": "5px"});
	
	//n = $(ok).next();
	//console.log($(n).html());
	//$(n).html("no");
	n = $(ok).prev().prev();
	//console.log($(n).html());
	$(n).html("No");
	//console.log($(n).html());
}

function clear_table(){
	console.log("here");
	tr = $("#dataload").html();
	console.log(tr);
	$("#dataload tr").each(function(i,row){
		ok = $(row).children().eq(6).text();
		console.log(ok);
		if(ok != "Price"){
			$(row).remove();
			return;
		}
		//total = total + parseInt(ok);
	});
	$("#subtotal").val('');
	$("#grand_total").val('');
}


</script>

<br>
<h2>Pricing: Price per packet of 10 seeds. Select your institution type:</h2>
<p>
<input align="left" type="radio" name="price" class="unitprice" value="100" checked="yes" onchange="clear_table()"> $100 US Academic<br>
<input type="radio" name="price" class="unitprice" value="160" onchange="clear_table()"> $160 US Industry
<input type="hidden" name="kkkkk" value="kashi">
</p>

<h2>Seed Order Entry:</h2>
<p>
Enter Quantity (number of packets), Barcode ID, and whether you want seed segregating for Ac. <br />
The segregates Ac is selected <span style='border: 5px solid teal; padding: 1px 5px 1px 5px;width: 20px'>Yes</span> by default, click on "No" to change the default.<br>
Genome placement and price will be displayed if barcode is valid.<br />
Click Add to add additional rows.
</p>
				
<span style="width:80px; display: inline-block">Quantity:</span><input id="quantity" type="text" value="1"><br>
<span style="width:80px; display: inline-block">Barcode:</span><input id="barcode" type="text" value="<?php echo $getbarcode ?>"> 
<span onClick="addrow()" style="background-color: teal; color: white; padding: 5px 10px 5px 10px; cursor: pointer" id="addbutton">Add</span>

<div id="errorInput" style="display: none; color: red; width: 600px;"></div> 
<br>
<br>

<table id="dataload" width="600px" class="tab">
	<tr>
	<th>Quantity</th>
	<th>Barcode</th>
	<th>Segregates Ac</th>
	<th>Placement</th>
	<th>Chr</th>
	<th>Chr fDs Coord</th>
	<th>Price</th>
	<th>Remove</th>
	</tr>
	<tr id="table_placeholder">
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	</tr>
</table>

<table class="data_entry" width="600px" cellspacing="20">
	<tr>
	<td width="40%"></td>
	<td align="right"> Subtotal (in $): 
	<input style="text-align:right" onclicktype="text" name="subtotal" class="subtotal" tabindex="-1" readonly="readonly" id="subtotal" size="5"></td>
	</tr>
		
	<tr>
	<td width="40%">
	Phytosanitary: <span class="heading">(check if applicable)</span></td>
	<td align="right"> Phytosanitary certification (European Shipments) - $60 
	<input type="checkbox" id="certification" class="subtotal" value="60" onchange="updateTotal()"> </td>
	</tr>
	
	<tr>
	<td width="40%">
	Expedited shipping:  <span class="heading">(optional)</span></td>
	<td align="right">Expedited shipping (e.g. FedEx) - (Extra fees will apply) 
	<input type="checkbox" id="expedited" value=true > </td>
	</tr>

	<tr><td width="40%"><span class="warning"> NOTE: Internet Explorer users will not be able to view Grand Total. Apologies - fix in progress!</span></td>
	<td align="right"> <b>Grand total</b> (minus extra shipping if applicable)&nbsp;<b>$</b>
	<input style="text-align:right; font-weight:bold" type="text" name="grand_total" class="grand_total" id="grand_total" tabindex="-1" readonly="readonly" size="4" value=""></td>
	</tr>

	<tr><td width="40%"></td>
	<td align="left">
	</td>
	</tr>
</table>

<table class="data_entry" style="width:600px" border="0" cellpadding="5" >
	<tr>
	<td align="left">Preview your order: &nbsp;<span class="heading">Click "Preview Order"</span> </td>
	<td align="right"><input type="submit" name="submit" value="Preview Order">&nbsp;&nbsp;	<input type="reset" name="Reset" tabindex="-1" value="Clear form" onclick="clear_table()"></td>
	</tr>
</table>				
				
</form>	
<?php require("../lib/page_body.php") ?>
