<?php require("../lib/page_top.php") ?>
<?php 

require ("../lib/db.php");
require ("PHPMailer-master/class.phpmailer.php");

$bool = true;
$msg = '';
$query = "select invoice_no from INVOICES order by invoice_no desc limit 1";

try {
	$stmt = $db->prepare($query);
	#$result = $stmt->execute($query_params);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	$bool = false;
	$msg .= "Failed to run query: " . $ex->getMessage() ."<br>";
}

$result = $stmt->fetch();
$invoice_no = $result['invoice_no'] + 1;

$insert_user = "insert into SEED_USERS (department,institution,street_address,city,state,zip,email_address,phone,project_leader,purchase_order_no,billing_department,billing_institution,billing_street_address,billing_city,billing_state, billing_zip, billing_email_address, sfname, slname, bfname, blname, scountry, bcountry) 
values (
'". mysql_real_escape_string($_GET['sdepartment']) ."', 
'". mysql_real_escape_string($_GET['sinstitution']) ."', 
'". mysql_real_escape_string($_GET['sstreet_address']) ."', 
'". mysql_real_escape_string($_GET['scity']) ."',
'". mysql_real_escape_string($_GET['sstate']) ."',
'". mysql_real_escape_string($_GET['szip']) ."',
'". mysql_real_escape_string($_GET['semail']) ."', 
'". mysql_real_escape_string($_GET['sphone']) ."',
'". mysql_real_escape_string($_GET['sproject_leader']) ."', 
'". mysql_real_escape_string($_GET['spurchase_order']) ."',
'". mysql_real_escape_string($_GET['bdepartment']) ."',
'". mysql_real_escape_string($_GET['binstitution']) ."',
'". mysql_real_escape_string($_GET['bstreet_address']) ."',
'". mysql_real_escape_string($_GET['bcity']) ."',
'". mysql_real_escape_string($_GET['bstate']) ."',
'". mysql_real_escape_string($_GET['bzip']) ."',
'". mysql_real_escape_string($_GET['bemail']) ."',
'". mysql_real_escape_string($_GET['sfname']) ."',
'". mysql_real_escape_string($_GET['slname']) ."', 
'". mysql_real_escape_string($_GET['bfname']) ."',
'". mysql_real_escape_string($_GET['blname']) ."',
'". mysql_real_escape_string($_GET['scountry']) ."',
'". mysql_real_escape_string($_GET['bcountry']) ."'
)";

#echo "<br>", $insert_user;
$uid = 0;

try {
	$stmt = $db->prepare($insert_user);
	$result = $stmt->execute();
	$uid = $db->lastInsertId();
}
catch(PDOException $ex) {
	$bool = false;
	$msg .= "Failed to run query: " . $ex->getMessage() ."<br>";
}

$mail = new PHPMailer();
$mail->IsSMTP();  // telling the class to use SMTP
$mail->Host     = "data1.luhs.org"; // SMTP server

#$mail->SetFrom("acdsproject-l@iulist.indiana.edu", "AcDs Project");
$mail->SetFrom("krevanna@luc.edu", "AcDs Project");
#$mail->AddAddress($_GET["semail"]);
#$mail->AddAddress("kashi.mail@gmail.com");
$mail->AddAddress('ka38@cornell.edu');
$mail->AddCC('kashi.mail@gmail.com', 'qdong@luc.edu');

$mail->Subject  = "PlantGDB - New seed order received";
$auto = "<html><body><p>This is an auto-generated notification of a new seed order made on acdstagging.org. The order is summarized below. Follow the link below for details.\r\n<p>";
$invoice_msg = "<p>Invoice number: $invoice_no\r\n</p>";
$name_details = "<p>Seeds ordered by: ". $_GET['sfname'] ."\r\n</p>";
$amount_details = "<p>Total Order amount: $". $_GET['grand_total'] ."\r\n</p></body></html>";
$link = "<a href=\"http://acdstagging.org/admin/request_view.php?invoice_no=$invoice_no\">View Seed Order Details</a>";
$message = $auto . $link . $invoice_msg . $name_details . $amount_details;

$mail->MsgHTML($message);
$mail->WordWrap = 50;

if(!$mail->Send()) {
	$msg .= 'Message was not sent.<br>';
	$msg .= 'Mailer error: ' . $mail->ErrorInfo;
} else {
	$msg .= 'Message has been sent.';
}


#$pricing = 100;
#$segregate = 1;
$ship_cost = 0;

$date = date("Y/m/d");
$display_block = "
		<h1>Seed Order Receipt</h1>
		<br/>
		<h2> Invoice Number: $invoice_no </h2>
    <h2> Order date: $date</h2>     <br/>
		<table class=\"data_entry\" width=\"100%\">
			<tr>
			<td width=\"50%\">
				<h2 class=\"bottommargin1\">Ship To:</h2>
				<table border=\"0\">
				<tr><td width=\"100\">First Name</td><td width=\"300\">".$_GET['sfname']."</td></tr>
				<tr><td width=\"100\">Last Name</td><td width=\"300\">".$_GET['slname']."</td></tr>

				<tr><td width=\"100\">Department</td><td width=\"300\">".$_GET['sdepartment']."</td></tr>
				<tr><td width=\"100\">Company/School</td><td width=\"300\">".$_GET['sinstitution']."</td></tr>
				<tr><td width=\"100\">Street Address</td><td width=\"300\">".$_GET['sstreet_address']."</td></tr>
				<tr><td width=\"100\">City</td><td width=\"300\">".$_GET['scity']."</td></tr>
				<tr><td width=\"100\">Country</td><td width=\"300\">".$_GET['scountry']."</td></tr>

				<tr><td width=\"100\">State</td><td width=\"300\">".$_GET['sstate']."</td></tr>
				<tr><td width=\"100\">Zip</td><td width=\"300\">".$_GET['szip']."</td></tr>
				<tr><td width=\"100\">Email</td><td width=\"300\">".$_GET['semail']."</td></tr>
				<tr><td width=\"100\">Phone #</td><td width=\"300\">".$_GET['sphone']."</td></tr>
				<tr><td width=\"100\"><b>Project Leader</b></td><td width=\"300\">".$_GET['sproject_leader']."</td></tr>
				
				</table>
				
				</td>
				
				<td width=\"50%\">
				<h2 class=\"bottommargin1\">Bill To: </h2>
				<table class=\"data_entry\" border=\"0\">

				<tr><td width=\"100\">First Name</td><td width=\"300\">".$_GET['bfname']."</td></tr>
				<tr><td width=\"100\">Last Name</td><td width=\"300\">".$_GET['blname']."</td></tr>

				<tr><td width=\"100\">Department</td><td width=\"300\">".$_GET['bdepartment']."</td></tr>
				<tr><td width=\"100\">Company/School</td><td width=\"300\">".$_GET['binstitution']."</td></tr>
				<tr><td width=\"100\">Street Address</td><td width=\"300\">".$_GET['bstreet_address']."</td></tr>
				<tr><td width=\"100\">City</td><td width=\"300\">".$_GET['bcity']."</td></tr>
				<tr><td width=\"100\">Country</td><td width=\"300\">".$_GET['bcountry']."</td></tr>

				<tr><td width=\"100\">State</td><td width=\"300\">".$_GET['bstate']."</td></tr>
				<tr><td width=\"100\">Zip</td><td width=\"300\">".$_GET['bzip']."</td></tr>
				<tr><td width=\"100\">Email</td><td width=\"300\">".$_GET['bemail']."</td></tr>
				<tr><td width=\"100\">Phone #</td><td width=\"300\">".$_GET['bphone']."</td></tr>
				<tr><td width=\"100\"><b>Purchase Order</b></td><td width=\"300\">".$_GET['spurchase_order']."</td></tr>

				</table>
				
				</td>
				
				</tr>
				</table>
				<p></p>
				
				
				
				<table class=\"tab\" width=\"100%\" border=\"0\" cellspacing=\"5\">
				<tr>
				<th width=\"15%\" align=\"center\">Quantity<br /> (10 seeds per pack)</th>
				<th width=\"15%\" align=\"center\">Barcode</th>
				<th width=\"1%\" align=\"center\">Segregates_Ac</th>
				<th width=\"15%\" align=\"center\">Placement</th>	
				<th width=\"15%\" align=\"center\">Chr</th>
				<th width=\"15%\" align=\"center\">chr_fds_coord</th>
				<th width=\"15%\" align=\"center\">Price</th>
				</tr>";

#echo $display_block;
#echo "<br>";

$segarr = array();
foreach($_GET[seg] as $item){
	$segcols = explode("..", $item);
	$segarr[$segcols[0]] = $segcols[1];
	#echo "$item ". $segcols[0] . "<br>";
}

#echo $_GET[buy];
$subtotal = 0;

foreach($_GET[buy] as $item){
	#echo "$item <br>";
	$arr = explode("..", $item);
	#echo $segarr[$arr[0]]. "<br>";
	
	$sb = $arr[1] * $_GET["price"];
	if($segarr[$arr[0]] == "Yes"){
		$segregate = 1;
	} else {
		$segregate = 0;
	}
	$insert_invoice = "insert into INVOICES (user_uid,invoice_no,order_date,order_quantity,order_barcode, order_subtotal, order_shipping, order_total, order_price, order_certification, segregates_ac,ship_cost ) 
	values ('$uid', '$invoice_no', '". date("Y-m-d") ."', '$arr[1]', '$arr[0]', '$sb', '".mysql_real_escape_string($_GET['expedite'])."', '".mysql_real_escape_string($_GET["grand_total"])."', '".mysql_real_escape_string($_GET["price"])."', '".mysql_real_escape_string($_GET["certificate"])."', $segregate, '$ship_cost')";
	
	#echo $insert_invoice ."<br>";
	try {
		$stmt = $db->prepare($insert_invoice);
		$result = $stmt->execute();
	}
	catch(PDOException $ex) {
		$bool = false;
		$msg .= "Failed to run query: " . $ex->getMessage();
	}
	
	$b = `php ../ajax/searchBarcode.php $arr[0]`;
	$a = json_decode($b);
	$display_block .= "
		<tr>
		<td>".$arr[1]."</td>
		<td>".$a->barcode."</td>
		<td>".$segarr[$arr[0]]."</td>
		<td>".$a->placement."</td>
		<td>".$a->bac_gi ."</td>
		<td>".$a->ds_coord ."</td>
		<td>".$arr[1] * $_GET["price"] ."</td>
		</tr>
	";
	$subtotal = $subtotal + ($arr[1] * $_GET["price"]);
}



$display_block .= "
</table>
<hr />
<p></p>
<table class=\"data_entry\" width=\"90%\" border=\"0\">
<tr>
	<td width=\"85%\" align=\"right\">Subtotal<br />Phytosanitary Cert.<br />Expedited Shipping<br />Grand Total <span class=\"heading\">(minus extra shipping if applicable)</span></td>
	<td align=\"center\">$$subtotal<br />".$_GET["certificate"]."<br />".$_GET['expedite']."<br />$".$_GET['grand_total']."</td>
</tr>
</table>
<p></p>
";

#echo $display_block;


$order_status = '';

if($bool){
	echo "<h3>Order placement: SUCCESS</h3>";
	#echo "<p>". $msg . "<br>";
	$order_status = "<p>Your seed order request has been sent. We will contact you within 3 days with an estimated shipping date. If you need more information, please contact <a href=\"mailto:ka38@cornell.edu\">Kevin Ahern</a> at Boyce Thompson Institute</p>";
	echo $order_status;
} else {
	echo "<h3>Order placement: ERROR</h3>";
	#echo "<p>". $msg ."<br>";
	$order_status = '<p>There was some problem in our database and your seed order request could not be completed successfully. We apologize for the inconvenience and request that you email <a href="mailto:acdsproject-l@iulist.indiana.edu">acdsproject-l@iulist.indiana.edu</a> for further assistance.</p>';
	echo $order_status;
}

$mail = new PHPMailer();
$mail->IsSMTP();  // telling the class to use SMTP
$mail->Host     = "data1.luhs.org"; // SMTP server

#$mail->SetFrom("acdsproject-l@iulist.indiana.edu", "AcDs Project");
$mail->SetFrom("krevanna@luc.edu", "AcDs Project");
#$mail->AddAddress("kashi.mail@gmail.com");
$mail->AddAddress($_GET["semail"]);
#$mail->AddCC('ka38@cornell.edu');

$mail->Subject  = "PlantGDB - Seed order receipt";
$auto = "<html><body>";
$email_content = $order_status . $display_block;
$amount_details = "</body></html>";
$message = $auto . $email_content . $amount_details;

$mail->MsgHTML($message);
$mail->WordWrap = 50;

if(!$mail->Send()) {
	$msg .= 'Message was not sent.<br>';
	$msg .= 'Mailer error: ' . $mail->ErrorInfo;
} else {
	$msg .= 'Message has been sent.';
}

?>
<?php require("../lib/page_body.php") ?>
