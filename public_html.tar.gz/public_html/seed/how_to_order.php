<?php require("../lib/page_top.php") ?>

<h2 class="bottommargin1">Seed Order Form - Instructions:<!--span class="announcement"><a class="noprint" href="/prj/AcDsTagging/request_instructions.php" target="_blank" class="link">Printable version</a></span --></h2>

<p>NOTE: This order form is for <i>Ds</i> insertions, identified as B.SXX.XXXX or I.SXX.XXXX. If you want to order <i>Ac</i> stocks (e.g. Ac.mon0307), they are available from the <a href="http://maizecoop.cropsci.uiuc.edu/">Maize Genetics Stock Center </a>.</p>

<p><b>1) Please fill out the online form completely:</b> </p>
<ul class="bullet1">
	<li><b>Name, Address, Contact Information, Project Leader</b></li>
	<li><b>Purchase Order Number:</b> To order seed stocks, you must obtain a Purchase Order before we can ship seed. Click <i>Academic</i> or <i>Industry</i> as appropriate. The fee helps to subsidize the cost of propagating materials for distribution and genotyping.</li>
	<li><b>Quantity</b> - number of seed packets (10 seed per packet)</li>
	<li><b>Barcode </b> - This refers to the unique identifier for each W22 line, as listed on <a href="/v2/insertions.php">Browse Insertions</a> page or at GenBank. It should begin with B.S, I.S, B.W, or I.W (e.g. I.W06.1026R). <b>Type or paste a barcode ID;</b> the form will autosuggest valid barcodes. <b>Click the correct one</b> to fill the field.</li>
	<li><b>Segregates Ac</b> - Check this box if you want seed that still contains active Ac element, to allow further mutagenesis.</li>
	<li><b>Chr, Chr fDs Coord, Placement (autofilled)</b> - The Placement chromosome, coordinate, and type (Single or Dual) is displayed for each barcode. Please check to make sure this information matches what you are expecting.</li>
	<li><b>Price (autofilled)</b> - Calculates price from the order quantity and your institution type.</li>
	<li><b>Shipment options </b> - If shipment is to Europe, please check for phytosanitary certification.</li>
	<li><b>Expedited shipping</b>  - Please note that if you request this option, additional charges will apply. There is no extra charge for normal shipping.</li>
	<li><b>Grand Total</b> - This is your order total, minus any expedited shipping charges.</li>
</ul>
	
<p><b>2) When finished, click <i>Preview Order</i> to view final form.</b> If all information is correct, click <i>Submit</i>. To modify/correct the form, use the back browser button.</p>
<p><b>3) Email confirmation</b> will be sent to both shipping and billing emails. Please allow 2-3 weeks for shipment.</p>


<p><b>4) Our address,</b> should you need to correspond by mail, is:</p>
<div id="hcard-bti" class="directorylist vcard">
	<a class="fn org url" href="http://bti.cornell.edu/">Boyce Thompson Institute</a><br />
	ATTN:  Accounts Receivable<br />
	<div class="adr">
	<span class="street-address">533 Tower Road</span><br />
	<span class="locality">Ithaca</span>, <abbr class="region" title="New York">NY</abbr> <span class="postal-code">14853</span><br />
	</div>
	<span class="tel"><span class="type">Fax: 607-254-1242</span></span><br />
</div>

<br>
<p>If you have any questions about the order process, please contact <a href="mailto:ka38@cornell.edu" target="_blank">Kevin Ahern</a> at BTI using the contact information provided on the order form.</p>

<p>Happy hunting,<br>
- Tom and Erik</li>




<?php require("../lib/page_body.php") ?>
