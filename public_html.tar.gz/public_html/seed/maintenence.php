<?php require("../lib/page_top.php") ?>
<h2>AcDs Tagging Seed Order</h2>

Seed ordering is disabled for regular maintenance.<br>
The site should be live by 5 PM (C.S.T) on 5th May 2015.<br><br>  
We apologize for any inconvenience.<br>

<?php require("../lib/page_body.php") ?>
