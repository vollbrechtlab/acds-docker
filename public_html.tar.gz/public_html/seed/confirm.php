<?php require("../lib/page_top.php") ?>
<?php 

$data = $_POST['kkkkk'];

$obj = json_decode($data);

#print_r($obj);

#echo "<br>--<br>";

#print_r($obj->order);

?>

<form method="get" action="confirmorder.php" id="confirmorder"> 
<table width="100%">
	<tr>
	<td width="50%" valign="top">
		<table class="data_entry" border="0">
		<h3>Ship To:</h3>
		<tr>
			<td width="200">First Name</td>
			<td width="300"><input type="text" name="sfname" size="15" readonly="readonly" value="<?php echo $obj->sfname ?>"></td>
		</tr>
		<tr>
			<td>Last Name</td>
			<td><input type="text" name="slname" size="15" readonly="readonly" value="<?php echo $obj->slname ?>"></td>
		</tr>
		<tr>
			<td>Department</td>
			<td><input type="text" name="sdepartment" size="15" readonly="readonly" value="<?php echo $obj->sdepartment ?>"></td>
		</tr>
		<tr>
			<td>Company/School</td>
			<td><input type="text" name="sinstitution" size="15" readonly="readonly" value="<?php echo $obj->sinstitution ?>"></td>
		</tr>
		<tr>
			<td>Street Address</td>
			<td><input type="text" name="sstreet_address" size="30" readonly="readonly" value="<?php echo $obj->sstreet_address ?>"></td>
		</tr>
		<tr>
			<td>City</td>
			<td><input type="text" name="scity" size="15" readonly="readonly" value="<?php echo $obj->scity ?>"></td>
		</tr>
		<tr>
			<td>Country</td>
			<td><input type="text" name="scountry" size="15" readonly="readonly" value="<?php echo $obj->scountry ?>"></td>
		</tr>
		<tr>
			<td>State</td>
			<td><input type="text" name="sstate" id="sstate" readonly="readonly" value="<?php echo $obj->sstate ?>" /></td>
		</tr>
		<tr>
			<td>Zip</td>
			<td><input type="text" name="szip" size="8" readonly="readonly" value="<?php echo $obj->szip ?>"></td>
		</tr>
		<tr>
			<td>Email</td>
			<td><input type="text" name="semail" size="20" readonly="readonly" value="<?php echo $obj->semail ?>"></td>
		</tr>
		<tr>
			<td>Phone #</td>
			<td><input type="text" name="sphone" size="15" readonly="readonly" value="<?php echo $obj->sphone ?>"></td>
		</tr>
		<tr>
			<td>Project Leader</td>
			<td><input type="text" name="sproject_leader" readonly="readonly" size="15" value="<?php echo $obj->sproject_leader ?>"></td>
		</tr>
		<tr>
			<td>Purchase Order #</td>
			<td><input type="text" name="spurchase_order" readonly="readonly" size="15" value="<?php echo $obj->spurchase_order ?>"></td>
		</tr>
		</table>
	</td>
	<td width="50%" valign="top">
		<table class="data_entry" border="0">
		<h3>Bill To:</h3>
		<tr>
			<td width="100" >First Name</td>
			<td width="300"><input type="text" name="bfname" size="15" readonly="readonly" value="<?php echo $obj->bfname ?>"></td>
		</tr>
		<tr>
			<td width="100" >Last Name</td>
			<td width="300"><input type="text" name="blname" size="15" readonly="readonly" value="<?php echo $obj->blname ?>"></td>
		</tr>	
		<tr>
			<td width="100" >Department</td>
			<td width="300"><input type="text" name="bdepartment" size="15" readonly="readonly" value="<?php echo $obj->bdepartment ?>"></td>
		</tr>
		<tr>
			<td width="100" >Company/School</td>
			<td width="300"><input type="text" name="binstitution" size="15" readonly="readonly" value="<?php echo $obj->binstitution ?>"></td>
		</tr>
		<tr>
			<td width="100" >Street Address</td>
			<td width="300"><input type="text" name="bstreet_address" size="30" readonly="readonly" value="<?php echo $obj->bstreet_address ?>"></td>
		</tr>
		<tr>
			<td width="100" >City</td>
			<td width="300"><input type="text" name="bcity" size="15" readonly="readonly" value="<?php echo $obj->bcity ?>"></td>
		</tr>
		<tr>
			<td width="100" >Country</td>
			<td width="300"><input type="text" name="bcountry" size="15" readonly="readonly" value="<?php echo $obj->bcountry ?>"></td>
		</tr>
		<tr>
			<td width="100" >State</td>
			<td width="300"><input type="text" name="bstate" id="bstate" readonly="readonly" value="<?php echo $obj->bstate ?>"/></td>
  	</tr>
		<tr>
			<td width="100" >Zip</td>
			<td width="300"><input type="text" name="bzip" size="8" readonly="readonly" value="<?php echo $obj->bzip ?>"></td>
		</tr>
		<tr>
			<td width="100" >Email</td>
			<td width="300"><input type="text" name="bemail" size="20" readonly="readonly" value="<?php echo $obj->bemail ?>"></td>
		</tr>
		<tr>
			<td width="100" >Phone #</td>
			<td width="300"><input type="text" name="bphone" size="15" readonly="readonly" value="<?php echo $obj->bphone ?>"></td>
		</tr>
		</table>
	</td>
	</tr>
</table>

<br>
<table class="tab">
	<tr>
	<th>Quantity</th>
	<th>Barcode</th>
	<th>Segregates Ac</th>
	<th>Placement</th>
	<th>Chr</th>
	<th>Chr fDs Coord</th>
	<th>Price(in $)</th>
	</tr>
<?php
$subtotal = 0;

$segarr = array();
foreach($obj->seg as $k => $o){
	$segarr[$k] = $o;
}

foreach($obj->order as $k => $o){
	$b = `php ../ajax/searchBarcode.php $k`;
	$a = json_decode($b);
	?>
	<tr>
	<td><?php echo $o ?></td>
	<td><?php echo $a->barcode ?></td>
	<td><?php echo $segarr[$k]?></td>
	<td><?php echo $a->placement ?></td>
	<td><?php echo $a->bac_gi ?></td>
	<td><?php echo $a->ds_coord ?></td>
	<?php $subtotal = $subtotal + ($o * $obj->price); ?> 
	<td><?php echo $o * $obj->price ?></td>
	<input type="hidden" name="buy[]" value="<?php echo $a->barcode ?>..<?php echo $o ?>">
	<input type="hidden" name="seg[]" value="<?php echo $a->barcode ?>..<?php echo $segarr[$k] ?>">
	</tr>
	<?php #echo "(". $obj->price.")" ?>
<?php
} 
?>
</table>
<br>
<div style="width: 200px; float: left">Subtotal</div>$ <?php echo $subtotal?><br>
<input type="hidden" name="price" value="<?php echo $obj->price ?>">

<?php if($obj->certification == 1){ ?>
<div style="width: 200px; float: left">Certification</div>$ 60<br>
<input type="hidden" name="certificate" value="60">
<?php } else { ?>
<input type="hidden" name="certificate" value="0">
<?php } ?>

<div style="width: 200px; float: left">Expedite</div><?php echo ($obj->expedited == 1) ? "Yes" : "No" ?><br>
<input type="hidden" name="expedite" value="<?php echo ($obj->expedited == 1) ? "Yes" : "No" ?>">
<div style="width: 200px; float: left">Total</div>$ <?php echo $obj->grand_total ?><br>
<input type="hidden" name="grand_total" value="<?php echo $obj->grand_total ?>">

<br>
<script type="text/javascript">
function confirmo(){
	//$("#confirmorder").submit();
}

function confirm(){
	$.ajax({
		url: 'confirmorder.php',
		data: {
			kkkkk: $("#confirmorder").serialize()
		},
		dataType: 'json',
		method: 'GET',
		success: function(data){
		},
		//* If error. show the error in console.log
		error: function(XMLHttpRequest, textStatus, errorThrown) {
			console.log(textStatus+" - "+errorThrown);
			console.log(XMLHttpRequest.responseText);
		}
	});
}
</script>
<input type="submit" value="Confirm order" >
</form>
<?php require("../lib/page_body.php") ?>
