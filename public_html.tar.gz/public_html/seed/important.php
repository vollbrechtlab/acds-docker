<?php require("../lib/page_top.php") ?>

<h2>Some notes on your Ds insertion seed stock:</h2>

<p>
<b>We maintain all <i>Ds</i> insertions as single heterozygous testcross ears (Ds/+ x +/+).</b> 
The lines are maintained in the W22 inbred and are homozygous for the <i>Ds</i> reporter at either the r1-sc:m3 or a1-m3 locus. 
Thus, half of the seed we send you will contain the <i>Ds</i> insertion and half will not. 
It is to your advantage to identify the plants containing the insertion in advance of pollinations. 
In most cases, each <i>Ds</i> insertion is confirmed as segregating in the stock via a PCR (preferred) or DNA blot assay in advance of 
shipping or billing. Currently, we are verifying over 80% of our insertion lines.  However, in some instances, a <i>Ds</i> 
that was isolated and subsequently annotated in our screens was found to be a transposition event that occurred in just a single kernel, 
and therefore is not recoverable in sibling progeny. Thus, it is important that we verify seed stocks before we ship. 
Please make your seed request well in advance of planting and be patient for your order to arrive, since we verify each <i>Ds</i> stock on demand. 
In the event that we bill you for a stock in which the <i>Ds</i> insertion cannot be verified, we will give you a credit for an alternative pedigree.</p>

<p><b>If available, seed segregating the <i>Ds</i> heterozygote and containing <i>Ac-im</i> is shipped for each stock request</b>, unless the request indicates a preference for the stable insertion instead. Not all stocks segregate Ac-im at this time; therefore, seed containing <i>Ac-im</i> may limited or unavailable. In these instances, seed segregating only the <i>Ds</i> heterozygote will be shipped instead. We will also provide you with the primer sequences that were used to confirm the <i>Ds</i> insertion site.</p>
	
<p><b>All orders will include ten kernels of homozygous (based on kernel dosage phenotype) <i>Ac-im</i> seed</b> (Conrad and Brutnell 2005 Genetics171:1999-2012) to remobilize <i>Ds</i> insertions . All orders will also include ten kernels of homozygous reporter stock experiment (either r1-sc:m3/r1-sc:m3 or a1-m3/a1-m3, depending upon the original donor locus), which should be self-pollinated to bulk tester stocks in advance of a large-scale mutagenesis experiment. If you do not need Ac-im and/or tester stocks, please indicate this on your order form so we can conserve our germplasm.  </p>
	
<p><b>Please be aware that assignment of a genomic location for a given <i>Ds</i> insertion based on sequence homology over a limited distance is subject to error</b>, given the possibility of duplicated sequences in maize, genotypic differences between W22 and B73, and incomplete genome sequence.  However, each <i>Ds</i> placement is given a quality score as described on our project web site.</p>
	
<p><b>Please reference the paper below when describing the materials:</b></p>

<ul class="bullet1">
	<li>Ahern KR, Deewatthanawong P, Schares J, Muszynski M, Weeks R, Vollbrecht E, Duvick J, Brendel VP, Brutnell TP. Regional mutagenesis using Dissociation in maize. <b>Methods</b> 49 (2009) 248-254. PMID: 19394430</li>
</ul>

<div id="hcard-bti" class="directorylist vcard">
	<a class="fn org url" href="http://bti.cornell.edu/">Boyce Thompson Institute</a><br />
	ATTN:  Accounts Receivable<br />
	<div class="adr">
	<span class="street-address">533 Tower Road</span><br />
	<span class="locality">Ithaca</span>, <abbr class="region" title="New York">NY</abbr> <span class="postal-code">14853</span><br />
	</div>
	<span class="tel"><span class="type">Fax: 607-254-1242</span></span><br />
</div>

<br>
<p>Thanks for your interest, and best of luck with the tagging!</p>
<p>-Tom and Erik</p>


<?php require("../lib/page_body.php") ?>

	

