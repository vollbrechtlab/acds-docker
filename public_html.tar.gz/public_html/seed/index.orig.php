<?php 

$ExtraHeadInfo = "
<script language=\"javascript\" type=\"text/javascript\">
function togglefield(val,tbox) {
  var o = document.getElementById(tbox);
  (val == 'Other')? o.style.display = 'block' : o.style.display = 'none';
}
</script>
<script language=\"javascript\" type=\"text/javascript\" src=\"/js/fillFields.js\"></script>
<link href=\"/css/barcode_suggest_styles.css\" rel=\"stylesheet\" type=\"text/css\" />";

/*If the text box doesn't have required data e.g; empty text box for a required field or alphabets in numeric field*/
/*Changes styling of the label corresponding to the text box to Red*/
function error_text_box($error, $field){
	if($error[$field]){
		print("class=\"empty_field\"");
	}
}

/*Checks the quantity barcode table*/
/* If any field in the first row is empty, it shades the text box.*
 * If any one quantity or barcode is filled without filling the   *
 * other, then the empty field is shaded			  */
function error_table($error, $field){
	if($error[$field]){
		print("class=\"empty_tbox\"");
	}
}

?>

<?php
function show_form(){
	global $HTTP_POST_VARS, $print_again, $error;
	if($_POST["Reset"]){
		//session_unset();		
		session_destroy();
		//$_SESSION = array();	
		//session_start();
		//session_regenerate_id();	
		//if(isset($_SESSION['fields']))
		//		unset($_SESSION['fields']);
		unset($_SESSION['fields']);
		header("Location: index.php");
	}
	$data=array();
	$data = $_SESSION['fields'];
?>
	<form name="seed_info" method="post">
				
		<h1 class="bottommargin1">AcDs Tagging Seed Order Form <!-- span class="heading">Instructions: </span--><!--img id='acds_request_form' title='Sequence Record View Help' style="margin-bottom: -3px" class='help-button' /--> &nbsp;<span class="heading"><a target="_blank" href="/prj/AcDsTagging/seed/how_to_order.php">[How to order<!--printable-->]</a><!--/span>&nbsp;&nbsp;&nbsp;<span class="heading">Important Info: </span>&nbsp;<img id='acds_request_info' title='Sequence Record View Help' style="margin-bottom: -3px" class='help-button' /--> &nbsp;<span class="heading"><a target="_blank" href="/prj/AcDsTagging/seed/important.php">[Important Information<!--printable-->]</a></span>&nbsp;</h1>
		
		<table width="100%">
			<tr><td width="50%" valign="top">
			<table class="data_entry" border="0">
				
				<h2 class="bottommargin1">Ship To:&nbsp;<span class="heading">Enter complete shipping and contact info:</span></h2>

				<tr><td width="100" <?php error_text_box($error,"sfname");?> >First Name</td><td width="300"><input type="text" name="sfname" size="15" value="<?php print $data["sfname"]?>"></td></tr>
				<tr><td width="100" <?php error_text_box($error, "slname"); ?>>Last Name</td><td width="300"><input type="text" name="slname" size="15" value="<?php print $data["slname"]?>"></td></tr>

				<tr><td width="100" <?php error_text_box($error, "sdepartment"); ?>>Department</td><td width="300"><input type="text" name="sdepartment" size="15" value="<?php print $data["sdepartment"]?>">
</td></tr>
				<tr><td width="100" <?php error_text_box($error, "sinstitution"); ?>>Company/School</td><td width="300"><input type="text" name="sinstitution" size="15" value="<?php print $data["sinstitution"]?>"></td></tr>
				<tr><td width="100" <?php error_text_box($error, "sstreet_address"); ?>>Street Address</td><td width="300"><input type="text" name="sstreet_address" size="30" value="<?php print $data["sstreet_address"]?>"></td></tr>
				<tr><td width="100" <?php error_text_box($error, "scity"); ?>>City</td><td width="300"><input type="text" name="scity" size="15" value="<?php print $data["scity"]?>"></td></tr>
				<tr><td width="100" <?php error_text_box($error, "scountry"); ?>>Country</td><td width="300"><input type="text" name="scountry" size="15" value="<?php print $data["scountry"]?>"></td></tr>

				<tr><td width="100" <?php error_text_box($error, "sstate"); ?>>State</td><td width="300"><select name="sstate" id="sstate" onChange="togglefield(this.value,'sstate_other');">
					<option value="<?php echo $data['sstate']; ?>" selected="selected"><?php echo $data['sstate'];?></option>
						<?php include('states.inc.php'); ?>
				
				</select><input type="text" name="sstate_other" id="sstate_other" style="display:none;" value="<?php print $data["sstate_other"]?>" /></td></tr>
				<tr><td width="100" <?php error_text_box($error, "szip"); ?>>Zip</td><td width="300"><input type="text" name="szip" size="8" value="<?php print $data["szip"]?>"></td></tr>
				<tr><td width="100" <?php error_text_box($error,"semail"); ?>>Email</td><td width="300"><input type="text" name="semail" size="20" value="<?php print $data["semail"]?>"></td></tr>
				<tr><td width="100" <?php error_text_box($error,"sphone"); ?>>Phone #</td><td width="300"><input type="text" name="sphone" size="15" value="<?php print $data["sphone"]?>"></td></tr>
				<tr><td width="100" <?php error_text_box($error,"sproject_leader"); ?>>Project Leader</td><td width="300"><input type="text" name="sproject_leader" size="15" value="<?php print $data["sproject_leader"]?>"></td></tr>
				<tr><td width="100" <?php error_text_box($error,"spurchase_order"); ?>>Purchase Order #</td><td width="300"><input type="text" name="spurchase_order" size="15" value="<?php print $data["spurchase_order"]?>"></td></tr>

				
			</table>
		
			</td>
			
		<td width="50%" valign="top">
		<table class="data_entry" border="0">
		<h2 class="bottommargin1">Bill To: (if different than Ship To) <input type="checkbox" name="billing" value="1" <?php if($data["billing"]==1) print "checked=\"yes\"" ?>></h2> 

		<tr><td width="100" <?php error_text_box($error, "bfname"); ?>>First Name</td><td width="300"><input type="text" name="bfname" size="15" value="<?php print $data["bfname"]?>"></td></tr>
		<tr><td width="100" <?php error_text_box($error, "blname"); ?>>Last Name</td><td width="300"><input type="text" name="blname" size="15" value="<?php print $data["blname"]?>"></td></tr>	
		<tr><td width="100" <?php error_text_box($error, "bdepartment"); ?>>Department</td><td width="300"><input type="text" name="bdepartment" size="15" value="<?php print $data["bdepartment"]?>"></td></tr>
		<tr><td width="100" <?php error_text_box($error, "binstitution"); ?>>Company/School</td><td width="300"><input type="text" name="binstitution" size="15" value="<?php print $data["binstitution"]?>"></td></tr>
		<tr><td width="100" <?php error_text_box($error, "bstreet_address"); ?>>Street Address</td><td width="300"><input type="text" name="bstreet_address" size="30" value="<?php print $data["bstreet_address"]?>"></td></tr>
		<tr><td width="100" <?php error_text_box($error, "bcity"); ?>>City</td><td width="300"><input type="text" name="bcity" size="15" value="<?php print $data["bcity"]?>"></td></tr>
		<tr><td width="100" <?php error_text_box($error, "bcountry"); ?>>Country</td><td width="300"><input type="text" name="bcountry" size="15" value="<?php print $data["bcountry"]?>"></td></tr>

		<tr><td width="100" <?php error_text_box($error, "bstate"); ?>>State</td><td width="300"><select name="bstate" id="bstate" onChange="togglefield(this.value,'bstate_other');">
  			<option value="<?php echo $data['bstate']; ?>" selected="selected"><?php echo $data['bstate'];?></option>
			<?php include('states.inc.php'); ?>
			
		</select>
<input type="text" name="bstate_other" id="bstate_other" style="display:none;"  value="<?php print $data["bstate_other"]?>"/></td></tr>
		<tr><td width="100" <?php error_text_box($error, "bzip"); ?>>Zip</td><td width="300"><input type="text" name="bzip" size="8" value="<?php print $data["bzip"]?>"></td></tr>
		<tr><td width="100" <?php error_text_box($error, "bemail"); ?>>Email</td><td width="300"><input type="text" name="bemail" size="20" value="<?php print $data["bemail"]?>"></td></tr>
		<tr><td width="100" <?php error_text_box($error, "bphone"); ?>>Phone #</td><td width="300"><input type="text" name="bphone" size="15" value="<?php print $data["bphone"]?>"></td></tr>
		</table>
				
		</td>
				
	</tr>
	</table>

<h2 class="topmargin1 bottommargin1">Pricing:&nbsp;<span class="heading">Price per packet of 10 seeds. Select your institution type:</span></h2>
	<table class="data_entry">
	<tr><td width="80">US Academic $100</td><td width="40"><input align="left" type="radio" name="price" class="unitprice" value="100" <?php if($data["price"]!=160) print "checked=\"yes\"" ?>></td>
    <td width="80">US Industry $160</td><td width="20"><input type="radio" name="price" class="unitprice" value="160" <?php if($data["price"]==160) print "checked=\"yes\"" ?>></td></tr>
	</table>
	<h2 class="topmargin1 bottommargin1">Seed Order Entry:</h2>
	<span class="heading">Enter Quantity (number of packets), Barcode ID, and whether you want seed segregating for Ac (default="yes"). <br />Genome placement and price will be displayed if barcode is valid.<br />Click <span><img src="images/plus_row.gif" alt="Add" \></span> to add additional rows.</span>
				
	
	<table class="data_entry topmargin1" style="width:95%" border="0" cellpadding="5" >
	<col width="5%" /><col width="10%" /><col width="10%" align="center" /><col width="15%" /><col width="15%" /><col width="10%" /><col width="10%" /><col width="10%" /><col width="10%" />
	<thead>
	<tr>
	<th>(Add)</th>
	<th align="center">Item #</th>
	<th>Quantity</th>
	<th>Barcode</th>
	<th align="center" >Segregates<br /> Ac</th>
	<th style="color:gray">Placement</th>
	<th style="color:gray">Chr</th>
	<th style="color:gray">Chr fDS Coord</th>
	<th align="center">Price (USD)</th>
	</tr>
	</thead>

	<?php 
	$i=1;
	while($i<=10)
	{
	$quantity = 'quantity'.$i;
	$barcode = 'barcode'.$i;
	$suggestionsBox = 'suggestionsBox'.$i;
	$suggestionList = 'suggestionList'.$i;
	$segregates_ac = 'segregates_ac'.$i;
	$placement = 'placement'.$i;
	$chr = 'chr'.$i;
	$chr_fds_coord = 'chr_fds_coord'.$i;
	$price = 'price'.$i;
	
	echo "<tr class=\"orderRow row_hide'\">
	<td align=\"right\"><a title=\"Add item row\" class=\"addRow more_rows\" style=\"cursor:pointer\"></a></td>
	<td align=\"center\">$i</td>
	<td><input type=\"text\" style=\"text-align:center\" name=\"$quantity\" size=\"3\"";
	error_table($error, "$quantity");
	echo "value=\"$data[$quantity]\"></td>
	<td id=\"barcode\"><input type=\"text\" name=\"$barcode\" size=\"12\"";
	error_table($error, "$barcode");
	echo "onkeyup=\"lookup(this.value,this.name);\" onclick=\"lookup(this.value,this.name);\" onchange=\"interval_fillFields('$i');\"  value=\"$data[$barcode]\">
	<div class=\"suggestionsBox\" name=\"$suggestionsBox\" style=\"display: none;\">
       		<img src=\"/prj/AcDsTagging/upArrow.png\" style=\"position: relative; top: -18px; left: 30px;\" alt=\"upArrow\" />
        	<div class=\"suggestionList\" name=\"$suggestionList\"></div>
	</div>
	</td>
	<td align='center' ><input type='checkbox' name='$segregates_ac' value=true if($data[$segregates_ac]== true) print 'checked='yes''></td>
	<td><input style='text-align:center; color:gray' type='text' name='$placement' tabindex='-1' readonly='readonly' size='5' id='$placement' value='$data[$placement]'></td>
	<td><input style='text-align:center; color:gray' type='text' name='$chr' id='$chr' tabindex='-1' readonly='readonly' size='3' value='$data[$chr]'></td>
	<td><input style='text-align:center; color:gray' type='text' name='$chr_fds_coord' tabindex='-1' readonly='readonly' size='10' id='$chr_fds_coord' value='$data[$chr_fds_coord]'></td>

	<td><input style='text-align:right' type='text' name='$price' class='price' tabindex='-1' readonly='readonly' size='5' id='$price' value='$data[$price]'></td>
	</tr>
	";
	$i++;
	 }
	;?>
				
	</table>				
	<table class="data_entry" width="95%" cellspacing="20">
		<tr><td width="40%"></td>
		<td align="right"> Subtotal <input style="text-align:right" onclicktype="text" name="subtotal" class="subtotal" tabindex="-1" readonly="readonly" id="subtotal" size="5"></td>
		</tr>
		<tr><td width="40%"><h3>Phytosanitary: <span class="heading">(check if applicable)</span></h3></td>
		<td align="right"> Phytosanitary certification (European Shipments) - $60 <input type="checkbox" name="certification" class="subtotal" value="60" <?php if($data["certification"]==60) print "checked=\"yes\"" ?>> </td>
		</tr>

		<tr><td width="40%"><h3>Expedited shipping:  <span class="heading">(optional)</span></h3></td>
		<td align="right">Expedited shipping (e.g. FedEx) - (Extra fees will apply) <input type="checkbox" name="expedited" value=true <?php if($data["expedited"]==true) print "checked=\"yes\"" ?>> </td>
		</tr>

		<tr><td width="40%"><span class="warning"> NOTE: Internet Explorer users will not be able to view Grand Total. Apologies - fix in progress!</span></td>
		<td align="right"> <b>Grand total</b> (minus extra shipping if applicable)&nbsp;<b>$</b><input style="text-align:right; font-weight:bold" type="text" name="grand_total" class="grand_total" id="grand_total" tabindex="-1" readonly="readonly" size="4" value="<?php print $data["grand_total"]?>"></td>
		</tr>

		<tr><td width="40%"></td>
		<td align="left">
		</td>
		</tr>
	</table>
	<table class="data_entry" style="width:95%" border="0" cellpadding="5" >
		<tr>
		<td align="left"> <h2 class="bottommargin1">Preview your order: &nbsp;<span class="heading">Click "Preview Order"</span> </h2 </td>
		<td align="right"><input type="submit" name="submit" value="Preview Order" >&nbsp;&nbsp;	<input type="Submit" name="Reset" tabindex="-1" value="Clear form"></td>
		</tr>
	</table>				
				
</form>	
<?php
}

/*If Submit is clicked validate the form*/
if(isset($_POST["submit"]))
	{
		check_form();
	}
else
	{
		show_form();
	}

function check($rowno)
{
	global $HTTP_POST_VARS, $error, $print_again;                
	if(!isEmpty($_POST['quantity'.$rowno]) && isEmpty($_POST['barcode'.$rowno]))
		{
			$error['barcode'.$rowno] = true;
			$print_again = true;
			if(!is_numeric($_POST["quantity".$rowno]))
			{
				$error['quantity'.$rowno] = true;
			} 
		}       
	else if(isEmpty($_POST['quantity'.$rowno]) && !isEmpty($_POST['barcode'.$rowno]))
		{
			$error['quantity'.$rowno] = true;
			$print_again = true;
			if(isEmpty($_POST["barcode".$rowno]))
			{
				$error['barcode'.$rowno] = true;
			}
		}
	else if(!isEmpty($_POST['quantity'.$rowno]) && !isEmpty($_POST['barcode'.$rowno]) )
                {
			if(!is_numeric($_POST["quantity".$rowno]))
			{
                       		$error['quantity'.$rowno] = true;
                        	$print_again = true;
                        }
                }

}


function check_form()
{

global $HTTP_POST_VARS, $error, $print_again;

$data = array ('sfname' => $_POST["sfname"],'slname' => $_POST["slname"], 'sdepartment' => $_POST["sdepartment"], 'sinstitution' => $_POST["sinstitution"], 'sstreet_address' => $_POST["sstreet_address"], 'scity' => $_POST["scity"], 'scountry' => $_POST["scountry"], 'sstate' => $_POST["sstate"], 'szip' => $_POST["szip"], 'semail' => $_POST["semail"], 'sphone' => $_POST["sphone"],'bfname' => $_POST["bfname"],'blname' => $_POST["blname"], 'bdepartment' => $_POST["bdepartment"], 'binstitution' => $_POST["binstitution"], 'bstreet_address' => $_POST["bstreet_address"], 'bcity' => $_POST["bcity"], 'bcountry' =>$_POST["bcountry"], 'bstate' => $_POST["bstate"], 'bzip' => $_POST["bzip"], 'bemail' => $_POST["bemail"], 'bphone' => $_POST["bphone"], 'billing' => $_POST["billing"], 'price' => $_POST["price"], 'sproject_leader' => $_POST["sproject_leader"], 'spurchase_order' => $_POST["spurchase_order"], 'certification' => $_POST["certification"], 'expedited' => $_POST["expedited"], 'subtotal' => $_POST["subtotal"], 'grand_total' => $_POST["grand_total"], 'sstate_other' => $_POST["sstate_other"], 'bstate_other' => $_POST["bstate_other"]);

for($counter=1;$counter<=20;$counter++) 
	{
	$data['quantity'.$counter] = $_POST["quantity".$counter];
	$data['barcode'.$counter] = $_POST["barcode".$counter];
	$data['segregates_ac'.$counter] = $_POST["segregates_ac".$counter];
	$data['chr'.$counter] = $_POST["chr".$counter];
	$data['chr_fds_coord'.$counter] = $_POST["chr_fds_coord".$counter]; 
	$data['placement'.$counter] = $_POST["placement".$counter]; 
	$data['price'.$counter] = $_POST["price".$counter];
	}


$_SESSION['fields']=$data;




	$error['sfname'] = false;
    	if(isEmpty($_POST["sfname"]))
	{
       		$error['sfname'] = true;
         	$print_again = true;
    	}
     	$error['slname'] = false;
	if(isEmpty($_POST["slname"]))
	{
		$error['slname'] = true;
		$print_again = true;
	}
	$error['sdepartment'] = false;
	if(isEmpty($_POST["sdepartment"]))
	{
		$error['sdepartment'] = true;
		$print_again = true;
	}
	$error['sinstitution'] = false;
	if(isEmpty($_POST["sinstitution"]))
	{
		$error['sinstitution'] = true;
		$print_again = true;
	}	
	$error['sstreet_address'] = false;
	if(isEmpty($_POST["sstreet_address"]))
	{
		$error['sstreet_address'] = true;
		$print_again = true;
	}
	$error['scity'] = false;
	if(isEmpty($_POST["scity"]))
	{
		$error['scity'] = true;
		$print_again = true;
	}
	$error['scountry'] = false;
	if(isEmpty($_POST["scountry"]))
	{
		$error['scountry'] = true;
		$print_again = true;
	}
	$error['sstate'] = false;
	if(checkDropdown($_POST["sstate"]))
	{
		$error['sstate'] = true;
		$print_again = true;
	}
	if($_POST["sstate"]=="Other")
	{
		if(isEmpty($_POST["sstate_other"]))
			{
				$error['sstate_other'] = true;
                		$print_again = true;
	
			}
	}		



	$error['szip'] = false;
	if(isEmpty($_POST["szip"]))
	{
		$error['szip'] = true;
		$print_again = true;
	}
	$error['semail'] = false;
	if(checkEmail($_POST["semail"]))
	{
		$error['semail'] = true;
		$print_again = true;
	}
	$error['sphone'] = false;
	if(checkPhone($_POST["sphone"]))
	{
		$error['sphone'] = true;
		$print_again = true;
	}
	$error['sproject_leader'] = false;
	if(isEmpty($_POST["sproject_leader"]))
	{
		$error['sproject_leader'] = true;
		$print_again = true;
	}
	$error['spurchase_order'] = false;
	if(isEmpty($_POST["spurchase_order"]))
	{
		$error['spurchase_order'] = true;
		$print_again = true;
	}

	$error['bfname'] = false;
	$error['blname'] = false;
	$error['bdepartment'] = false;       
	$error['binstitution'] = false;
	$error['bstreet_address'] = false;
	$error['bcity'] = false;
	$error['bcountry'] = false;
	$error['bstate'] = false;
	$error['bzip'] = false;
	$error['bemail'] = false;
	$error['bphone'] = false;


	/*Check Billing address fields only if Billing is different than shipping*/ 
	if($_POST["billing"]==1)
	{
		if(isEmpty($_POST["bfname"]))
		{
                	$error['bfname'] = true;
                	$print_again = true;
        	}
       
        	if(isEmpty($_POST["blname"]))  
		{
                	$error['blname'] = true;
                	$print_again = true;
        	}
       
        	if(isEmpty($_POST["bdepartment"]))     
		{
               		$error['bdepartment'] = true;
                	$print_again = true;
        	}

        	if(isEmpty($_POST["binstitution"]))
		{
               		$error['binstitution'] = true;
                	$print_again = true;
		}

        	if(isEmpty($_POST["bstreet_address"]))
		{
               		$error['bstreet_address'] = true;
                	$print_again = true;
        	}

        	if(isEmpty($_POST["bcity"]))   
		{
			$error['bcity'] = true;
                	$print_again = true;
		}

		if(isEmpty($_POST["bcountry"]))
		{
			$error['bcountry'] = true;
			$print_again = true;
		}

		if(checkDropdown($_POST["bstate"]))
		{
			$error['bstate'] = true;
			$print_again = true;
	        }
		 if($_POST["bstate"]=="Other")           
	        {               
                if(isEmpty($_POST["bstate_other"]))              
                        {               
                                $error['bstate_other'] = true;
                                $print_again = true;

                        }
        	}               


        	if(isEmpty($_POST["bzip"])) 
		{
         		$error['bzip'] = true;
                	$print_again = true;
        	}

        	if(checkEmail($_POST["bemail"]))   
		{
               		$error['bemail'] = true;
                	$print_again = true;
        	}
       
	        if(checkPhone($_POST["bphone"]))  
      		{
                	$error['bphone'] = true;
                	$print_again = true;
        	}
	}/*End of IF _POST["billing"]*/	



	if(!is_numeric($_POST["quantity1"]))
		{
			$error['quantity1'] = true;
			$print_again = true;
		}
	if(isEmpty($_POST["barcode1"]))
		{
			$error['barcode1'] = true;
			$print_again = true;
		}
	check('2');
	check('3');	
	check('4');
	check('5');
	check('6');
	check('7');
	check('8');
	check('9');
	check('10');






	if($print_again)
	{
		show_form();
	} 

	else
	{
		header("Location: request_process.php");
	}
}
?>

<p />
</div> <!--end maincontentsfull-->
</div><!--end maincontentscontainer-->




<div id="rightcolumncontainer">
	<div class="minicolumnright"> </div><!--end minicolumn right-->
</div><!--end rightcolumncontainer-->


<!--?php include($PLANTGDB_FOOTER); ?-->
</div><!--end outercontainer-->
</body>
</html>
<? ob_flush(); ?>
