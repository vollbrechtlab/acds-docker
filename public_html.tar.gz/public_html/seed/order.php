<?php
$data=array();
#$data = $_SESSION['fields'];

$certification = $data['certification'];
$expedited = ($data['expedited']==true)?1:0;
if ($certification == ""){
	$certification = 0;
};
	

$quantity1 = $data['quantity1'];
$quantity2 = $data['quantity2'];
$quantity3 = $data['quantity3'];
$quantity4 = $data['quantity4'];
$quantity5 = $data['quantity5'];
$quantity6 = $data['quantity6'];
$quantity7 = $data['quantity7'];
$quantity8 = $data['quantity8'];
$quantity9 = $data['quantity9'];
$quantity10 = $data['quantity10'];

$segregates_ac1 = ($data['segregates_ac1']==true)?1:0;
$segregates_ac2 = ($data['segregates_ac2']==true)?1:0;
$segregates_ac3 = ($data['segregates_ac3']==true)?1:0;
$segregates_ac4 = ($data['segregates_ac4']==true)?1:0;
$segregates_ac5 = ($data['segregates_ac5']==true)?1:0;
$segregates_ac6 = ($data['segregates_ac6']==true)?1:0;
$segregates_ac7 = ($data['segregates_ac7']==true)?1:0;
$segregates_ac8 = ($data['segregates_ac8']==true)?1:0;
$segregates_ac9 = ($data['segregates_ac9']==true)?1:0;
$segregates_ac10 = ($data['segregates_ac10']==true)?1:0;


$chr1 = $data['chr1'];
$chr2 = $data['chr2'];
$chr3 = $data['chr3'];
$chr4 = $data['chr4'];
$chr5 = $data['chr5'];
$chr6 = $data['chr6'];
$chr7 = $data['chr7'];
$chr8 = $data['chr8'];
$chr9 = $data['chr9'];
$chr10 = $data['chr10'];

$chr_fds_coord1 = $data['chr_fds_coord1'];
$chr_fds_coord2 = $data['chr_fds_coord2'];
$chr_fds_coord3 = $data['chr_fds_coord3'];
$chr_fds_coord4 = $data['chr_fds_coord4'];
$chr_fds_coord5 = $data['chr_fds_coord5'];
$chr_fds_coord6 = $data['chr_fds_coord6'];
$chr_fds_coord7 = $data['chr_fds_coord7'];
$chr_fds_coord8 = $data['chr_fds_coord8'];
$chr_fds_coord9 = $data['chr_fds_coord9'];
$chr_fds_coord10 = $data['chr_fds_coord10'];


$placement1 = $data['placement1'];
$placement2 = $data['placement2'];
$placement3 = $data['placement3'];
$placement4 = $data['placement4'];
$placement5 = $data['placement5'];
$placement6 = $data['placement6'];
$placement7 = $data['placement7'];
$placement8 = $data['placement8'];
$placement9 = $data['placement9'];
$placement10 = $data['placement10'];


$barcode1 = $data['barcode1'];
$barcode2 = $data['barcode2'];
$barcode3 = $data['barcode3'];
$barcode4 = $data['barcode4'];
$barcode5 = $data['barcode5'];
$barcode6 = $data['barcode6'];
$barcode7 = $data['barcode7'];
$barcode8 = $data['barcode8'];
$barcode9 = $data['barcode9'];
$barcode10 = $data['barcode10'];

	
$price_choice = $data['price'];
$pricing = $price_choice;	
$sfname = mysql_real_escape_string($_POST['sfname']);
$slname = mysql_real_escape_string($_POST['slname']);
$sdepartment = mysql_real_escape_string($_POST['sdepartment']);
$sinstitution = mysql_real_escape_string($_POST['sinstitution']);
$sstreet_address = mysql_real_escape_string($_POST['sstreet_address']);
$scity = mysql_real_escape_string($_POST['scity']);
$sstate = mysql_real_escape_string($_POST['sstate']);
$szip = mysql_real_escape_string($_POST['szip']);
$semail = mysql_real_escape_string($_POST['semail']);
$sphone = mysql_real_escape_string($_POST['sphone']);
$scountry = mysql_real_escape_string($_POST['scountry']);

$sproject_leader = mysql_real_escape_string($_POST['sproject_leader']);
$spurchase_order = mysql_real_escape_string($_POST['spurchase_order']);

if (!$data['billing']){
	$bfname = mysql_real_escape_string($_POST['sfname']);
	$blname = mysql_real_escape_string($_POST['slname']);

	$bdepartment = mysql_real_escape_string($_POST['sdepartment']);
	$binstitution = mysql_real_escape_string($_POST['sinstitution']);
	$bstreet_address = mysql_real_escape_string($_POST['sstreet_address']);
	$bcity = mysql_real_escape_string($_POST['scity']);
	$bstate = mysql_real_escape_string($_POST['sstate']);
	$bzip = mysql_real_escape_string($_POST['szip']);
	$bcountry = mysql_real_escape_string($_POST['scountry']);
	
	$bemail = mysql_real_escape_string($_POST['semail']);
	$bphone = mysql_real_escape_string($_POST['sphone']);
	$bproject_leader = mysql_real_escape_string($_POST['sproject_leader']);
} else {
	$bfname = mysql_real_escape_string($_POST['bfname']);
	$blname = mysql_real_escape_string($_POST['blname']);
	$bdepartment = mysql_real_escape_string($_POST['bdepartment']);
	$binstitution = mysql_real_escape_string($_POST['binstitution']);
	$bstreet_address = mysql_real_escape_string($_POST['bstreet_address']);
	$bcountry = mysql_real_escape_string($_POST['bcountry']);
	$bcity = mysql_real_escape_string($_POST['bcity']);
	$bstate = mysql_real_escape_string($_POST['bstate']);
	$bzip = mysql_real_escape_string($_POST['bzip']);
	$bemail = mysql_real_escape_string($_POST['bemail']);
	$bphone = mysql_real_escape_string($_POST['bphone']);
	$bproject_leader = mysql_real_escape_string($_POST['bproject_leader']);
}

if ($quantity1 != ""){
	$price1sign = "$";
	$price1 = $quantity1 * $pricing;
}
if ($quantity2 != ""){
	$price2 = $quantity2 * $pricing;
	$price2sign = "$";
}
if ($quantity3 != ""){
	$price3 = $quantity3 * $pricing;
	$price3sign = "$";
}
if ($quantity4 != ""){
	$price4 = $quantity4 * $pricing;
	$price4sign = "$";
}
if ($quantity5 != ""){
	$price5 = $quantity5 * $pricing;
	$price5sign = "$";
}
if ($quantity6 != ""){
	$price6 = $quantity6 * $pricing;
	$price6sign = "$";
	}
if ($quantity7 != ""){
	$price7 = $quantity7 * $pricing;
	$price7sign = "$";
}
if ($quantity8 != ""){
	$price8 = $quantity8 * $pricing;
	$price8sign = "$";
}
if ($quantity9 != ""){
	$price9 = $quantity9 * $pricing;
	$price9sign = "$";
}
if ($quantity10 != ""){
	$price10 = $quantity10 * $pricing;
	$price10sign = "$";
}


$subtotal = $data['subtotal'];	
$certification = $data['certification'];
$grand_total = $data['grand_total'];	
	
	
$get_last_id = "select invoice_no from INVOICES order by invoice_no";
#$check_get_last_id = mysql_query($get_last_id) or die("Database query problem". mysql_error());
try {
	$stmt = $db->prepare($get_last_id);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}

$result = $stmt->fetchAll();

foreach($result as $last_id_array){
	$last_id = $last_id_array['invoice_no'];
};

if ($last_id > 0){
	$invoice_no = $last_id+1;
} else {
	$invoice_no = 1;

};
	
///////////////////////
if($data['price'] != ""){
	//submit
	$insert_user = "insert into SEED_USERS (department,institution,street_address,city,state,zip,email_address,phone,project_leader,purchase_order_no,billing_department,billing_institution,billing_street_address,billing_city,billing_state, billing_zip, billing_email_address, sfname, slname, bfname, blname, scountry, bcountry) values ('$sdepartment', '$sinstitution', '$sstreet_address', '$scity', '$sstate', '$szip', '$semail', '$sphone', '$sproject_leader', '$spurchase_order', '$bdepartment', '$binstitution', '$bstreet_address', '$bcity', '$bstate', '$bzip', '$bemail', '$sfname', '$slname', '$bfname', '$blname', '$scountry', '$bcountry')";
	#$check_insert_user = mysql_query($insert_user);
	try {
		$stmt = $db->prepare($insert_user);
		$result = $stmt->execute();
	}
	catch(PDOException $ex) {
		die("Failed to run query: " . $ex->getMessage());
	}

	$get_id = "select * from SEED_USERS order by uid";
	#$check_get_id = mysql_query($get_id);
	try {
		$stmt = $db->prepare($get_id);
		$result = $stmt->execute();
	}
	catch(PDOException $ex) {
		die("Failed to run query: " . $ex->getMessage());
	}
	
	$result = $stmt->fetchAll();
	foreach($result as $id_array){
		$user_uid = $id_array['uid'];
	}

	/*****E-Mail Composition for the Admin user.*****/
	$mail = new PHPMailer();
	$mail->IsSMTP();  // telling the class to use SMTP
	$mail->Host     = "mail.cas.unt.edu"; // SMTP server
	
	#$mail->SetFrom("acdsproject-l@iulist.indiana.edu", "AcDs Project");
	$mail->SetFrom("kashi.revanna@unt.edu", "AcDs Project");
	$mail->AddAddress($_GET["semail"]);
	#$mail->AddCC('ka38@cornell.edu');
	
	$mail->Subject  = "PlantGDB - New seed order received";
	$auto = "<html><body><p>This is an auto-generated notification of a new seed order made on acdstagging.org. The order is summarized below. Follow the link below for details.\r\n<p>";
	$invoice_msg = "<p>Invoice number: $invoice_no\r\n</p>";
	$name_details = "<p>Seeds ordered by: ". $sfname ."\r\n</p>";
	$amount_details = "<p>Total Order amount: $". $grand_total ."\r\n</p></body></html>";
	$link = "<a href=\"http://www.plantgdb.org/prj/AcDsTagging/Admin/request_view.php?invoice_no=$invoice_no\">View Seed Order Details</a>";
	$message = $auto . $link . $invoice_msg . $name_details . $amount_details;
	
	$mail->MsgHTML($message);
	$mail->WordWrap = 50;
	
	if(!$mail->Send()) {
		$msg .= 'Message was not sent.<br>';
		$msg .= 'Mailer error: ' . $mail->ErrorInfo;
	} else {
		$msg .= 'Message has been sent.';
	}

	$ship_cost = 0;
	/*****Start of Database update with Order details*****/
	$check_insert_invoice1 = true;
	if ($quantity1 != ""){
		$insert_invoice1 = "insert into INVOICES (user_uid,invoice_no,order_date,order_quantity,order_barcode, order_subtotal, order_shipping, order_total, order_price, order_certification, segregates_ac,ship_cost ) values ('$user_uid', '$invoice_no', now(), '$quantity1', '$barcode1', '$subtotal', $expedited, '$grand_total', '$pricing','$certification',$segregates_ac1, '$ship_cost')";
		#$check_insert_invoice1 = mysql_query($insert_invoice1);
		try {
			$stmt = $db->prepare($insert_invoice1);
			$result = $stmt->execute();
		}
		catch(PDOException $ex) {
			die("Failed to run query: " . $ex->getMessage());
		}		
	}

	$check_insert_invoice2 = true;
	if ($quantity2 != ""){
		$insert_invoice2 = "insert into INVOICES (user_uid,invoice_no,order_date,order_quantity,order_barcode, order_subtotal, order_shipping, order_total, order_price, order_certification, segregates_ac,ship_cost ) values ('$user_uid', '$invoice_no', now(),  '$quantity2', '$barcode2', '$subtotal', $expedited, '$grand_total', '$pricing','$certification',$segregates_ac2,'$ship_cost')";
		#$check_insert_invoice2 = mysql_query($insert_invoice2);
		try {
			$stmt = $db->prepare($insert_invoice2);
			$result = $stmt->execute();
		}
		catch(PDOException $ex) {
			die("Failed to run query: " . $ex->getMessage());
		}
	};

	$check_insert_invoice3 = true;
	if ($quantity3 != ""){
		$insert_invoice3 = "insert into INVOICES (user_uid,invoice_no,order_date,order_quantity,order_barcode, order_subtotal, order_shipping, order_total, order_price, order_certification, segregates_ac,ship_cost ) values ('$user_uid', '$invoice_no', now(), '$quantity3', '$barcode3', '$subtotal', $expedited, '$grand_total', '$pricing','$certification',$segregates_ac3,'$ship_cost')";
		#$check_insert_invoice3 = mysql_query($insert_invoice3);
		try {
			$stmt = $db->prepare($insert_invoice3);
			$result = $stmt->execute();
		}
		catch(PDOException $ex) {
			die("Failed to run query: " . $ex->getMessage());
		}
	};
	
	$check_insert_invoice4 = true;
	if ($quantity4 != ""){
		$insert_invoice4 = "insert into INVOICES (user_uid,invoice_no,order_date,order_quantity,order_barcode, order_subtotal, order_shipping, order_total, order_price, order_certification, segregates_ac,ship_cost ) values ('$user_uid', '$invoice_no', now(), '$quantity4', '$barcode4', '$subtotal', $expedited, '$grand_total', '$pricing','$certification',$segregates_ac4,'$ship_cost')";
		#$check_insert_invoice4 = mysql_query($insert_invoice4);
		try {
			$stmt = $db->prepare($insert_invoice4);
			$result = $stmt->execute();
		}
		catch(PDOException $ex) {
			die("Failed to run query: " . $ex->getMessage());
		}
	};
	
	$check_insert_invoice5 = true;
	if ($quantity5 != ""){
		$insert_invoice5 = "insert into INVOICES (user_uid,invoice_no,order_date,order_quantity,order_barcode, order_subtotal, order_shipping, order_total, order_price, order_certification, segregates_ac,ship_cost ) values ('$user_uid', '$invoice_no', now(), '$quantity5', '$barcode5', '$subtotal', $expedited, '$grand_total', '$pricing','$certification',$segregates_ac5,'$ship_cost')";
		#$check_insert_invoice5 = mysql_query($insert_invoice5);
		try {
			$stmt = $db->prepare($insert_invoice5);
			$result = $stmt->execute();
		}
		catch(PDOException $ex) {
			die("Failed to run query: " . $ex->getMessage());
		}
	};
	
	$check_insert_invoice6 = true;
	if ($quantity6 != ""){
		$insert_invoice6 = "insert into INVOICES (user_uid,invoice_no,order_date,order_quantity,order_barcode, order_subtotal, order_shipping, order_total, order_price, order_certification, segregates_ac,ship_cost ) values ('$user_uid', '$invoice_no', now(), '$quantity6', '$barcode6', '$subtotal', $expedited, '$grand_total', '$pricing','$certification',$segregates_ac6,'$ship_cost')";
		#$check_insert_invoice6 = mysql_query($insert_invoice6);
		try {
			$stmt = $db->prepare($insert_invoice6);
			$result = $stmt->execute();
		}
		catch(PDOException $ex) {
			die("Failed to run query: " . $ex->getMessage());
		}
	};
	
	$check_insert_invoice7 = true;
	if ($quantity7 != ""){
		$insert_invoice7 = "insert into INVOICES (user_uid,invoice_no,order_date,order_quantity,order_barcode, order_subtotal, order_shipping, order_total, order_price, order_certification, segregates_ac,ship_cost ) values ('$user_uid', '$invoice_no', now(), '$quantity7', '$barcode7', '$subtotal', $expedited, '$grand_total', '$pricing','$certification',$segregates_ac7,'$ship_cost')";
		#$check_insert_invoice7 = mysql_query($insert_invoice7);
		try {
			$stmt = $db->prepare($insert_invoice7);
			$result = $stmt->execute();
		}
		catch(PDOException $ex) {
			die("Failed to run query: " . $ex->getMessage());
		}
	};
	
	$check_insert_invoice8 = true;
	if ($quantity8 != ""){
		$insert_invoice8 = "insert into INVOICES (user_uid,invoice_no,order_date,order_quantity,order_barcode, order_subtotal, order_shipping, order_total, order_price, order_certification, segregates_ac,ship_cost ) values ('$user_uid', '$invoice_no', now(), '$quantity8', '$barcode8', '$subtotal', $expedited, '$grand_total', '$pricing','$certification',$segregates_ac8,'$ship_cost')";
		#$check_insert_invoice8 = mysql_query($insert_invoice8);
		try {
			$stmt = $db->prepare($insert_invoice8);
			$result = $stmt->execute();
		}
		catch(PDOException $ex) {
			die("Failed to run query: " . $ex->getMessage());
		}
	};
	
	$check_insert_invoice9 = true;
	if ($quantity9 != ""){
		$insert_invoice9 = "insert into INVOICES (user_uid,invoice_no,order_date,order_quantity,order_barcode, order_subtotal, order_shipping, order_total, order_price, order_certification, segregates_ac,ship_cost ) values ('$user_uid', '$invoice_no', now(), '$quantity9', '$barcode9', '$subtotal', $expedited, '$grand_total', '$pricing','$certification',$segregates_ac9,'$ship_cost')";
		#$check_insert_invoice9 = mysql_query($insert_invoice9);
		try {
			$stmt = $db->prepare($insert_invoice9);
			$result = $stmt->execute();
		}
		catch(PDOException $ex) {
			die("Failed to run query: " . $ex->getMessage());
		}
	};

	$check_insert_invoice10 = true;
	if ($quantity10 != ""){
		$insert_invoice10 = "insert into INVOICES (user_uid,invoice_no,order_date,order_quantity,order_barcode, order_subtotal, order_shipping, order_total, order_price, order_certification, segregates_ac,ship_cost ) values ('$user_uid', '$invoice_no', now(), '$quantity10', '$barcode10', '$subtotal', $expedited, '$grand_total', '$pricing','$certification',$segregates_ac10,'$ship_cost')";
		#$check_insert_invoice10 = mysql_query($insert_invoice10);
		try {
			$stmt = $db->prepare($insert_invoice10);
			$result = $stmt->execute();
		}
		catch(PDOException $ex) {
			die("Failed to run query: " . $ex->getMessage());
		}
	};
/*****End of Database update with order details*****/

$date = date("Y/m/d");

/************Check if database update was successful. Else display error message*************/
if($check_insert_user==false || $check_insert_invoice1 ==false || $check_insert_invoice2 ==false || $check_insert_invoice3 ==false || $check_insert_invoice4 ==false || $check_insert_invoice5 ==false || $check_insert_invoice6==false || $check_insert_invoice7 ==false || $check_insert_invoice8==false ||$check_insert_invoice9==false||$check_insert_invoice10==false ){
	$display_success = 'There was some problem in our database and your seed order request could not be completed successfully. We apologize for the inconvenience and request that you email <a href="mailto:acdsproject-l@iulist.indiana.edu">acdsproject-l@iulist.indiana.edu</a> for further assistance.';
} else {
	$display_success = "Your seed order request has been sent. We will contact you within 3 days with an estimated shipping date. If you need more information, please contact <a href=\"mailto:ka38@cornell.edu\">Kevin Ahern</a> at Boyce Thompson Institute";
}
/************End of database update check*************/

if($segregates_ac1==1) $segregates_ac1 = "Yes"; else $segregates_ac1 = "No";
if($quantity1=="") $segregates_ac1="";
if($segregates_ac2==1) $segregates_ac2 = "Yes"; else $segregates_ac2 = "No"; 
if($quantity2=="") $segregates_ac2="";
if($segregates_ac3==1) $segregates_ac3 = "Yes"; else $segregates_ac3 = "No";
if($quantity3=="") $segregates_ac3="";
if($segregates_ac4==1) $segregates_ac4 = "Yes"; else $segregates_ac4 = "No";
if($quantity4=="") $segregates_ac4="";
if($segregates_ac5==1) $segregates_ac5 = "Yes"; else $segregates_ac5 = "No";
if($quantity5=="") $segregates_ac5="";
if($segregates_ac6==1) $segregates_ac6 = "Yes"; else $segregates_ac6 = "No";
if($quantity6=="") $segregates_ac6="";
if($segregates_ac7==1) $segregates_ac7 = "Yes"; else $segregates_ac7 = "No";
if($quantity7=="") $segregates_ac7="";
if($segregates_ac8==1) $segregates_ac8 = "Yes"; else $segregates_ac8 = "No";
if($quantity8=="") $segregates_ac8="";
if($segregates_ac9==1) $segregates_ac9 = "Yes"; else $segregates_ac9 = "No";
if($quantity9=="") $segregates_ac9="";
if($segregates_ac10==1) $segregates_ac10 = "Yes"; else $segregates_ac10 = "No";
if($quantity10=="") $segregates_ac10="";

if($expedited == 1) $expedited = "Yes"; else $expedited = "No";

$display_block = "
<h2>Seed Order Receipt</h2>
<br/>
<h3>$display_success</h3><br/>	

<h2> Invoice Number: $invoice_no </h2>
<h2> Order date: $date</h2>     <br/>

<table class=\"data_entry\" width=\"100%\">
<tr>
<td width=\"50%\">
	<h2 class=\"bottommargin1\">Ship To:</h2>
	<table border=\"0\">
		<tr><td width=\"100\">First Name</td><td width=\"300\">$sfname</td></tr>
		<tr><td width=\"100\">Last Name</td><td width=\"300\">$slname</td></tr>
		<tr><td width=\"100\">Department</td><td width=\"300\">$sdepartment</td></tr>
		<tr><td width=\"100\">Company/School</td><td width=\"300\">$sinstitution</td></tr>
		<tr><td width=\"100\">Street Address</td><td width=\"300\">$sstreet_address</td></tr>
		<tr><td width=\"100\">City</td><td width=\"300\">$scity</td></tr>
		<tr><td width=\"100\">Country</td><td width=\"300\">$scountry</td></tr>

		<tr><td width=\"100\">State</td><td width=\"300\">$sstate</td></tr>
		<tr><td width=\"100\">Zip</td><td width=\"300\">$szip</td></tr>
		<tr><td width=\"100\">Email</td><td width=\"300\">$semail</td></tr>
		<tr><td width=\"100\">Phone #</td><td width=\"300\">$sphone</td></tr>
		<tr><td width=\"100\"><b>Project Leader</b></td><td width=\"300\">$sproject_leader</td></tr>
	</table>
</td>
				
<td width=\"50%\">
	<h2 class=\"bottommargin1\">Bill To: </h2>
	<table class=\"data_entry\" border=\"0\">
		<tr><td width=\"100\">First Name</td><td width=\"300\">$bfname</td></tr>
		<tr><td width=\"100\">Last Name</td><td width=\"300\">$blname</td></tr>
		<tr><td width=\"100\">Department</td><td width=\"300\">$bdepartment</td></tr>
		<tr><td width=\"100\">Company/School</td><td width=\"300\">$binstitution</td></tr>
		<tr><td width=\"100\">Street Address</td><td width=\"300\">$bstreet_address</td></tr>
		<tr><td width=\"100\">City</td><td width=\"300\">$bcity</td></tr>
		<tr><td width=\"100\">Country</td><td width=\"300\">$bcountry</td></tr>

		<tr><td width=\"100\">State</td><td width=\"300\">$bstate</td></tr>
		<tr><td width=\"100\">Zip</td><td width=\"300\">$bzip</td></tr>
		<tr><td width=\"100\">Email</td><td width=\"300\">$bemail</td></tr>
		<tr><td width=\"100\">Phone #</td><td width=\"300\">$bphone</td></tr>
		<tr><td width=\"100\"><b>Purchase Order</b></td><td width=\"300\">$spurchase_order</td></tr>
	</table>
</td>
</tr>
</table>

<p></p>
				
<table class=\"data_entry\" width=\"100%\" border=\"0\" cellspacing=\"5\">
<tr>
<th width=\"15%\" align=\"center\">Quantity<br /> (10 seeds per pack)</th>
<th width=\"15%\" align=\"center\">Barcode</th>
<th width=\"1%\" align=\"center\">Segregates_Ac</th>
<th width=\"15%\" align=\"center\">Placement</th>	
<th width=\"15%\" align=\"center\">Chr</th>
<th width=\"15%\" align=\"center\">chr_fds_coord</th>
<th width=\"15%\" align=\"center\">Total</th>
</tr>
			
<tr>
<td width=\"15%\" align=\"center\">$quantity1</td>
<td width=\"15%\" align=\"center\">$barcode1</td>
<td width=\"1%\" align=\"center\">$segregates_ac1</td>
<td width=\"15%\" align=\"center\">$placement1</td>	
<td width=\"15%\" align=\"center\">$chr1</td>
<td width=\"15%\" align=\"center\">$chr_fds_coord1</td>
<td width=\"15%\" align=\"center\">$price1sign$price1</td>
</tr>
				
<tr>
<td width=\"15%\" align=\"center\">$quantity2</td>
<td width=\"15%\" align=\"center\">$barcode2</td>
<td width=\"1%\" align=\"center\">$segregates_ac2</td>
<td width=\"15%\" align=\"center\">$placement2</td>   	
<td width=\"15%\" align=\"center\">$chr2</td>   
<td width=\"15%\" align=\"center\">$chr_fds_coord2</td> 
<td width=\"15%\" align=\"center\">$price2sign$price2</td>
</tr>
			
<tr>
<td width=\"15%\" align=\"center\">$quantity3</td>
<td width=\"15%\" align=\"center\">$barcode3</td>
<td width=\"1%\" align=\"center\">$segregates_ac3</td>
<td width=\"15%\" align=\"center\">$placement3</td>  
<td width=\"15%\" align=\"center\">$chr3</td>   
<td width=\"15%\" align=\"center\">$chr_fds_coord3</td> 
<td width=\"15%\" align=\"center\">$price3sign$price3</td>
</tr>
		
<tr>
<td width=\"15%\" align=\"center\">$quantity4</td>
<td width=\"15%\" align=\"center\">$barcode4</td>
<td width=\"1%\" align=\"center\">$segregates_ac4</td>
<td width=\"15%\" align=\"center\">$placement4</td>	
<td width=\"15%\" align=\"center\">$chr4</td>   
<td width=\"15%\" align=\"center\">$chr_fds_coord4</td> 
<td width=\"15%\" align=\"center\">$price4sign$price4</td>
</tr>
	
<tr>
<td width=\"15%\" align=\"center\">$quantity5</td>
<td width=\"15%\" align=\"center\">$barcode5</td>
<td width=\"1%\" align=\"center\">$segregates_ac5</td>
<td width=\"15%\" align=\"center\">$placement5</td>	
<td width=\"15%\" align=\"center\">$chr5</td>   
<td width=\"15%\" align=\"center\">$chr_fds_coord5</td> 
<td width=\"15%\" align=\"center\">$price5sign$price5</td>
</tr>

<tr>
<td width=\"15%\" align=\"center\">$quantity6</td>
<td width=\"15%\" align=\"center\">$barcode6</td>
<td width=\"1%\" align=\"center\">$segregates_ac6</td>
<td width=\"15%\" align=\"center\">$placement6</td>	
<td width=\"15%\" align=\"center\">$chr6</td>   
<td width=\"15%\" align=\"center\">$chr_fds_coord6</td> 
<td width=\"15%\" align=\"center\">$price6sign$price6</td>
</tr>

<tr>
<td width=\"15%\" align=\"center\">$quantity7</td>
<td width=\"15%\" align=\"center\">$barcode7</td>
<td width=\"1%\" align=\"center\">$segregates_ac7</td>
<td width=\"15%\" align=\"center\">$placement7</td>	
<td width=\"15%\" align=\"center\">$chr7</td>   
<td width=\"15%\" align=\"center\">$chr_fds_coord7</td> 
<td width=\"15%\" align=\"center\">$price7sign$price7</td>
</tr>

<tr>
<td width=\"15%\" align=\"center\">$quantity8</td>
<td width=\"15%\" align=\"center\">$barcode8</td>
<td width=\"1%\" align=\"center\">$segregates_ac8</td>
<td width=\"15%\" align=\"center\">$placement8</td>	
<td width=\"15%\" align=\"center\">$chr8</td>   
<td width=\"15%\" align=\"center\">$chr_fds_coord8</td> 
<td width=\"15%\" align=\"center\">$price8sign$price8</td>
</tr>

<tr>
<td width=\"15%\" align=\"center\">$quantity9</td>
<td width=\"15%\" align=\"center\">$barcode9</td>
<td width=\"1%\" align=\"center\">$segregates_ac9</td>
<td width=\"15%\" align=\"center\">$placement9</td>	
<td width=\"15%\" align=\"center\">$chr9</td>   
<td width=\"15%\" align=\"center\">$chr_fds_coord9</td> 
<td width=\"15%\" align=\"center\">$price9sign$price9</td>
</tr>
				
<tr>
<td width=\"15%\" align=\"center\">$quantity10</td>
<td width=\"15%\" align=\"center\">$barcode10</td>
<td width=\"1%\" align=\"center\">$segregates_ac10</td>
<td width=\"15%\" align=\"center\">$placement10</td>
<td width=\"15%\" align=\"center\">$chr10</td>
<td width=\"15%\" align=\"center\">$chr_fds_coord10</td>
<td width=\"15%\" align=\"center\">$price10sign$price10</td>
</tr>

</table>
<hr />

<p></p>

<table class=\"data_entry\" width=\"90%\" border=\"0\">
<tr>
<td width=\"85%\" align=\"right\">Subtotal<br />Phytosanitary Cert.<br />Expedited Shipping<br />Grand Total <span class=\"heading\">(minus extra shipping if applicable)</span></td>
<td align=\"center\">$$subtotal<br />$$certification<br />$expedited<br />$$grand_total</td>
</tr>
</table>
				
<p></p>
				
";

/*****E-Mail Composition for the Orderer. *****/
if($data['price'] != ""){
	$mail = new PHPMailer();
	$mail->IsSMTP();  // telling the class to use SMTP
	$mail->Host     = "mail.cas.unt.edu"; // SMTP server
	
	#$mail->SetFrom("acdsproject-l@iulist.indiana.edu", "AcDs Project");
	$mail->SetFrom("kashi.revanna@unt.edu", "AcDs Project");
	$mail->AddAddress($_GET["semail"]);
	#$mail->AddCC('ka38@cornell.edu');
	
	$mail->Subject  = "PlantGDB - Seed Order Receipt";
	$auto = "<html><body>"; #<p>This is an auto-generated notification of a new seed order made on acdstagging.org. The order is summarized below. Follow the link below for details.\r\n<p>";
	$email_content = $display_block;
	$amount_details = "</body></html>";
	$message = $auto . $email_content . $amount_details;
	$mail->MsgHTML($message);
	$mail->WordWrap = 50;
	
	if(!$mail->Send()) {
	$msg .= 'Message was not sent.<br>';
		$msg .= 'Mailer error: ' . $mail->ErrorInfo;
	} else {
	$msg .= 'Message has been sent.';
	}
}
/*****End of E-mail confirmation for the Orderer*****/
?>
<?php require("../lib/page_body.php") ?>