module Coffee
  module Rails
    VERSION = "4.0.1"
  end
end
