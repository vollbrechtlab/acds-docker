module Treetop #:nodoc:
  module VERSION #:nodoc:
    MAJOR = 1
    MINOR = 4
    TINY  = 15

    STRING = [MAJOR, MINOR, TINY].join('.')
  end
end
