## 4.0.1 (October 17, 2013) ##

*   Drop support to Rails `4.0.0.rc` releases

    *Rafael Mendonça França*


## 4.0.0 (April 18, 2013) ##

*   Bump railties version to 4.0.0.beta.

    *José Valim*


## 3.2.2 (January 26, 2012) ##

*   Bump railties version to ~> 3.2.0.

    *Aaron Patterson*


## 3.2.1 (January 5, 2012) ##

*   No changes.


## 3.2.0 (December 17, 2011) ##

*   Add coffee-script.js for asset pipeline. Now your app will support
    `<script type="text/coffeescript">` in views.

    *Guillermo Iguaran*

*   Add Action View template handler for coffee views.

    *Guillermo Iguaran*
