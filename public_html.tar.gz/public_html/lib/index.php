<h2>What is the Ac/Ds project?</h2>
<p>A collection of sequence-tagged Ds insertions in W22-derived inbred lines, for reverse genetics in maize.
The project is funded through the National Science Foundation <a title="NSF Project Page" href="http://www.nsf.gov/awardsearch/showAward.do?AwardNumber=0922701">(Award #0922701)</a>. 
See <a href="#introduction">project summary</a> / <a href="#resources">resource links</a> below, refer to our <a href="#publications">publications</a>, or download <a href="/Ac-Ds.pdf" target="_blank">project summary slides</a>.</p>

<fieldset>
<legend>Quick Search</legend>

<form method="get" action="v2/gene_ds.php" style="padding: 10px">
Search by transcript/locus: 
<input type="text" name="geneidv2" size="20" value="GRMZM2G104843_T01" />
<input type="submit" value="Find closest Ds" />
</form>

<form method="get" action="v2/genes.php" style="padding: 10px">
Search by gene description: 
<input type="text" name="term" size="20" value="lipoxygenase" />
<input type="hidden" name="field" value="description" />
<input type="submit" value="Find closest Ds" />
</form>

<span style="padding: 10px">
Show all maize transcripts close to a Ds insertion: 
<a href="/v2/genes.php?field=distance&term=40">< 40 kb</a> |
<a href="/v2/genes.php?field=distance&term=10">< 10 kb</a> |
<a href="/v2/genes.php?field=distance&term=1">< 1 kb</a> |
<a href="/v2/genes.php?field=distance&term=0">< 0 kb</a>
</span>
<br><br>


<form method="get" action="v2/generate.php" style="padding: 10px">
Search by Barcode ID or GenBank GI: 
<input type="text" name="id" size="20" value="I.S06.2099" />
<input type="submit" value="Show Ds record" />
</form>

<form method="get" action="v2/genes.php" style="padding: 10px">
Search by chromosome/region: 
<input type="text" name="term" size="20" value="2:1..50000000" />
<input type="hidden" name="field" value="chromosome" />
<input type="submit" value="Find Ds in this region" />
</form>

</fieldset>
<br>
<br>
<h2><a name="resources">What resources are available for Ac/Ds?</a></h2>
<ol class="bullet1">
	<li><a href="#introduction">Project overview</a> - project updates, and publications (see below)</li>
	<li><a title="fDs insertions page" href="/v2/insertions.php"><i>Ds</i> Insertion Sites</a> - Chromosome coordinates and closest maize gene for each mapped <i>Ds</i> insertion in the B73 reference genome.</li>
	<li><a title="fDs insertions page" href="/v2/genes.php"><i>Ds</i> - Gene Distance</a> - Closest <i>Ds</i> insertions for each annotated maize gene</li>
	<li><a title="AcDs seed order instructions and online form" href="/seed/">Order Seed</a> form, for requesting seedstocks containing a distinct <i>Ds</i> insertion, for reverse mutagenesis or re-mobilization experiments.</li>
	<!-- 
	<li><a title="AcDs blast page" href="/prj/AcDsTagging/tool/blast.php">BLAST page</a> for querying against <i>Ds</i>-flanking sequences.</li>
	<li><a title="Download AcDs Data" href="ftp://ftp.plantgdb.org/download/MaizeData/AcDs/">Download (ftp)</a> fDs FASTA sequences and placement data tables</li>
	<li><a title="AcDs workshop information" href="/prj/AcDsTagging/workshop/">Workshop Announcement</a> page for summer workshop, 2011</li>
	-->
	<li><a title="AcDs contact information" href="/contact.php">Contact</a> page for corresponding with project leaders.</li>
</ol>

<p><b>For more information</b>, visit <a title="AcDs Help" href="/help.php">Ac/Ds Help</a>.</p>

<p><b>To contact the project PI's</b>, see the <a title="AcDs contact information" href="/contact.php">Ac/Ds Contact Page</a>.</p>

<h2><a name="introduction">Introduction</a></h2>

<p>The maize transposable elements Ac/Ds were the first transposable elements discovered by Barbara McClintock over 50 years ago.  Over the years, these elements have been extensively characterized through classical genetic and molecular genetic studies that have 1) elucidated the mechanism of transposition 2) examined the modes of Ac/Ds regulation and 3) explored the utility of Ac/Ds as gene cloning and characterization tools.  We have exploited this tremendous foundation to develop a two-component Ac/Ds gene tagging platform for maize.</p>
						
<p>Through <a href="http://www.nsf.gov/awardsearch/showAward.do?AwardNumber=0501713">NSF funding</a>, members of the <a href="http://bti.cornell.edu/TomBrutnell.php">Brutnell</a> and <a href="http://www.gdcb.iastate.edu/faculty_and_research/bios/evollbrecht.shtml">Vollbrecht</a> groups are now developing a series of Ds-containing lines for use in both forward and reverse genetic screens.  The goal of the project is to create a collection of approximately 10,000 Ds insertions distributed uniformly throughout the maize genome. DNA flanking each Ds insertion will be cloned and sequenced providing a precise physical location for each insertion. These insertions will be integrated into genomic assemblies and displayed graphically through web links at <a href="/">PlantGDB</a> by members of the <a href="http://brendelgroup.org/">Brendel</a> group.</p>

<h2>How It Works</h2>

<p>We have <a href="/Ac-Ds.pdf">slides</a> (PDF format) outlining the project goals and methods.</p>
					
<h2>Progress Reports</h2>

<p>November, 2008</p>

<p>Our focus over the past year has been to mobilize additional Ds insertions throughout the genome, clone and sequence DNA flanking the insertions and position these insertions onto the maize genome.  We have also begun a detailed analysis of the first 1,000+ transpositions at the local, intrachromosomal and interchromosomal level. DNA sequences that flank the Ds elements are exceptionally low in repeat content, leading to a high proportion of insertions in annotated genes. Selection for unlinked transpositions recovers randomly distributed insertions.</p>
					
<p>Data from selections for linked transposition events from the r locus indicate the collection will be useful for local mutagenesis, which may be critical for knocking out both copies of tandem duplicated genes as occurs with high frequency in maize. Despite the uniform distribution of Ds elements throughout the genome, there appears to me some local preference for Ds insertion.</p>
						
<p>We have used two restriction endonucleases (PvuII, SacII) for the molecular identification of Ds flanking sequences (fDs).  Approximately 30% of all families screened carry Ds elements that are loosely linked or unlinked from the donor locus on chromosome 10.  In 2007, all transposition events used in cloning were generated from r1-scm:3. Over the past year, a total of 1376 fDs events were amplified and sent to Iowa for sequencing and bioinformatics analyses. </p>
		
<p>March, 2007 </p>

<h3>Cloning fDs</h3>

<p>To facilitate the cloning of Ds flanking sequences we developed a high-throughput (96-well plate format) method to isolate high-quality DNA from seedling tissues.  Using this method we have been able to isolate up to 30 ug of high quality DNA from each seedling prep.  This is sufficient for all subsequent DNA blot and IPCR amplification protocols.  Thus, we are now screening each family individually in DNA blot analysis. To identify trDs elements and enrich for Ds insertions in the hypomethylated, low copy regions of the maize genome, DNA is digested with a methylation sensitive restriction enzyme prior to DNA blot analysis.  We estimate that we can detect nearly 90% of the trDs elements using the two restriction enzymes, PvuII and SacII.  As of Jan. 31, 2007, we have isolated DNA and performed DNA blot analysis using PvuII and SacII on 3509 families and identified approximately 900 Ds-containing fragments that are of a suitable size for amplifying by IPCR.  We have amplified 664 fragments representing germinal Ds insertions.  In December 2006 and January 2007 325 fragments were amplified using IPCR by the Brutnell group and were sent to the Vollbrecht lab for sequencing.  We anticipate that from this point forward 200-250 fDs sequences/month will be amplified by the Brutnell lab.</p>

<h3>Sequence analysis of fDs</h3>

<p> Over the past year, we have developed scripts, software and protocols in anticipation of a large number of fDs sequences. Sequence tracefiles from each shipment of fragments are first batch processed by scripts and software that renames tracefiles according to their parent maize lines, removes low quality, vector and Ds sequences, and assembles paired reads into contigs. These cleaned assemblies are then inspected manually for template content and where appropriate (i.e., in most cases) for agreement with the size expectations from DNA blot analysis and IPCR steps carried out at BTI, an important quality control measure.  The bioinformatics pipeline then generates and exports fasta files for each shipment, which are compared by BLAST against our cumulative fDs database before we append the new, unique sequences to the database. When the cumulative database consisted of 387 fDs in mid-February, the "unique-only" database consisted of 372 fDs sequences (96%) that were isolated only once, while nine were isolated twice (2-copy), three were 3-copy, two were 4-copy, and one fDs was 8-copy. This analysis indicates that insertion hotspots or cryptic or other preexisting Ds elements are rare. The current dataset of 469 fDs assemblies will be deposited to the GSS section of GenBank in March 2007.</p>

<h3>Database development</h3>

<p>As a means to visualize fDs:BAC matches in PlantGDB, we have developed a new annotation track for the ZmGDB genome browser that shows the match between fDs and BAC sequence in a genome context view.  The new track will be implemented when we release our next iteration of BAC annotation, scheduled for March 2007.</p>

<p>February 1, 2006</p>

<p>Our work to date has focused on developing the genetic materials necessary to create large populations of transposed Ds (tDs) insertions and on improving molecular techniques to identify and clone tDs flanking sequences.  We have also generated a small population of approximately 1000 families, each carrying a unique tDs insertion generated from excision of Ds at the r-sc:m3 locus.  We are now screening this population to identify tDs insertions that are unlinked to the r locus.  Thus far, we have screened approximately 400 families and have identified 79 tDs insertions that segregate independently from the r locus.  Over the next 6 months, we will attempt to clone DNA flanking these insertions using an inverse PCR technique and begin integrating flanking sequences into genomic assemblies.</p>
					
<h2>Activator mutagenesis of the maize genome</h2>

<p>Through <a href="http://www.nsf.gov/awardsearch/showAward.do?AwardNumber=0922701">NSF support</a>, several <i>Ac</i> elements have been distributed throughout the genome.  These elements have been positioned relative to molecular markers on the IBM2 framework maps and are available through the Maize Genetics Cooperative Stock Center.</p>
					
<h2 class="topmargin1" id="Dissociation">Genome-wide mutagenesis of maize with Dissociation</h2>

<p>Please follow the links on the left menubar under "Ac/Ds Taggin" to identify sequences and their most significantly matching maize sequence in the B73 Reference Genome. Older datasets matching <i>Ds</i> insertions with GSS sequences are also available.</p>
						
<h2><a name="publications">Relevant Publications</a></h2>

<p>E. Vollbrecht, J. et al. Genome-Wide Distribution of Transposed Dissociation Elements in Maize. Plant Cell, First published on June 25, 2010; 10.1105/tpc.109.073452 <a href="http://www.plantcell.org/cgi/content/abstract/tpc.109.073452v1">Abstract</a>; <a href="http://www.plantcell.org/cgi/reprint/tpc.109.073452v1">pdf</a>.</span></p>
<p>Ahern, K.R., Deewatthanawonga, P., Schares, J., Muszynski, M., Weeks, R., Vollbrecht, E., Duvick, J., Brendel, V., and T.P. Brutnell (2009) Regional Mutagenesis using Dissociation in Maize. Methods 49(3): 248-254 [<a href="http://dx.doi.org/10.1016/j.ymeth.2009.04.009">online article</a>].</p>
<p>Conrad L.J., Bai L., Ahern K., Dusinberre K., Kane D.P. and T.P. Brutnell (2007) State II dissociation element formation following activator excision in maize. Genetics 177: 737-747 [<a href="http://www.genetics.org/cgi/content/full/177/2/737">online article</a>].</p>
<p>Conrad L.J., Kikuchi K. and T.P. Brutnell (2008) "Transposon tagging in cereal crops" in Handbook of Functional Genomics, eds. Kahl and Meksem, Wiley Press.</p>
<p>Conrad, L.J. and T. P. Brutnell (2005) Ac-immobilized, a stable source of Activator transposase that mediates sporophytic and gametophytic excision of dissociation elements in maize. Genetics 171: 1999-2012. [<a href="http://www.genetics.org/cgi/content/full/171/4/1999">online article</a></p>
