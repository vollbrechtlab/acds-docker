<!-- 
<div>
	<div>
	<h3>Contact Us</h3>
	<ul>
	<li>
		<span>Address:</span>
		<p>Neodance Studio<br> 1294 Saint Francis Way<br> West Allis, WI 53227<br><br></p>
	</li>
	<li>
		<span>Phone:</span>
		<p>262-956-6778</p>
	</li>
	<li>
		<span>Fax:</span>
		<p>262-956-6779<br><br></p>
	</li>
	<li>
		<span>Email:</span>
		<p></p>
	</li>
	</ul>
	</div>
</div>
-->