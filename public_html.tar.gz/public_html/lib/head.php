<!DOCTYPE html>
<!-- Website template by freewebsitetemplates.com -->
<html>
	<head>
		<meta charset="UTF-8">
		<title>AcDsTagging</title>
		<link rel="stylesheet" href="/css/style.css" type="text/css">
		<script language="javascript" type="text/javascript" src="/js/ajax_request.js"></script>
		<script language="javascript" type="text/javascript" src="/js/jquery.min.js"></script>
	</head>
	<body>
		<div id="page">