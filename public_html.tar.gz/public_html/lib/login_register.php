<?php require("../lib/page_top.php") ?>
<?php 

// First we execute our common code to connection to the database and start the session
require("../lib/login_common.php"); 
     
// This if statement checks to determine whether the registration form has been submitted 
// If it has, then the registration code is run, otherwise the form is displayed 
if(!empty($_POST)) {
	if(empty($_POST['username'])) {
		die("Please enter your username.");
	}
	if(empty($_POST['password'])) {
		die("Please enter a password.");
	}
	if(empty($_POST['password_confirmation'])) {
		die("Please enter a password.");
	}
	if($_POST['password'] != $_POST['password_confirmation']){
		die("Passwords do not match.");
	}
	
	if(!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
		die("Invalid E-Mail Address");
	} 
         
  $query = "SELECT 1 FROM users WHERE email = :email OR username = :username";
	$query_params = array(':email' => $_POST['email'], ':username' => $_POST['username']);
	
	try {
		$stmt = $db->prepare($query);
		$result = $stmt->execute($query_params);
	}
	catch(PDOException $ex) {
		die("Failed to run query: " . $ex->getMessage());
	}
	
	$row = $stmt->fetch();
	if($row) {
		die("This email is already in use");
	}
	
	$query = "
			INSERT INTO users (
				username,
				password, 
				salt, 
				email
			) 
			VALUES (
				:username,
				:password, 
				:salt, 
				:email
			)
		";
	
	$salt = dechex(mt_rand(0, 2147483647)) . dechex(mt_rand(0, 2147483647));
	$password = hash('sha256', $_POST['password'] . $salt);
	for($round = 0; $round < 65536; $round++) {
		$password = hash('sha256', $password . $salt);
	}
	
	$query_params = array(
		':username' => $_POST['username'],
		':password' => $password,
		':salt' => $salt,
		':email' => $_POST['email']
	);
	
	$email = $_POST['email'];
	#system("mkdir tmp/$email");
	
	try {
		// Execute the query to create the user
		$stmt = $db->prepare($query);
		$result = $stmt->execute($query_params);
	}
	catch(PDOException $ex) {
		// Note: On a production website, you should not output $ex->getMessage().
		// It may provide an attacker with helpful information about your code.
		die("Failed to run query: " . $ex->getMessage());
	}
	
	// This redirects the user back to the login page after they register
	header("Location: /admin/index.php");
	
	// Calling die or exit after performing a redirect using the header function
	// is critical.  The rest of your PHP script will continue to execute and
	// will be sent to the user if you do not die or exit.
	die("Redirecting to /admin/index.php");
} 
     
?> 
   		
   		<h1>Register</h1>
   		
   		<br>
   		<form action="/lib/login_register.php" method="post">
   		Username:<br />
   		<input type="text" name="username" value="" />
   		<br /><br />
   		
   		E-Mail:<br />
   		<input type="text" name="email" value="" />
   		<br /><br />
   		
   		Password:<br />
   		<input type="password" name="password" value="" />
   		<br /><br />
   		
   		Confirm Password:<br />
   		<input type="password" name="password_confirmation" value="" />
   		<br /><br />
   		
   		<input type="submit" value="Register" />
   		</form>

<?php require("../lib/page_body.php") ?>