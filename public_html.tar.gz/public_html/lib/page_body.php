		</div>
		<div id="sidebar">
			<div class="section">
				<?php require("sidebar.php") ?>
			</div>
			<div id="section" >
				<?php #require("contact.php") ?>
			</div>
		</div>
	</div>
</div>
<?php require("footer.php") ?>