<div style="border: 1px solid gainsboro">
	<span style="padding: 20px;">Admin tools</span>
	<ul>
	<li><a href="/admin/request_admin.php">View Order Invoices</a></li>
	<li><a href="/admin/request_admin_viewall.php">List of Requested Barcodes</a></li>
	<li>
	<form action="/admin/logout.php" method="post" id="logoutform"><input type="hidden" value="Logout" /></form>
	<a href="#" onclick="$('#logoutform').submit();">Logout</a>
	</li>
	</ul>
</div>