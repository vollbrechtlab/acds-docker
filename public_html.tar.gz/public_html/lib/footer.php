<div id="footer">
	<span class="shadow">
	</span>
</div>

	</div>
</body>
</html>