<div style="border: 1px solid gainsboro">
	<ul>
	<li><a href="/index.php">Home</a></li>
	<li><a href="/v2/insertions.php">Insertion sites</a></li>
	<li><a href="/v2/genes.php">Genes</a></li>
	<li><a href="/v2/pipeline.php">Source Data</a></li>
	<li><a href="/blast.php">BLAST</a></li>
	<!-- <li><a href="/primer/">Primers</a></li> -->
	<!--  <li><a href="#">Download</a></li> -->
	<li><a href="/seed/index.php">Order Seed</a></li>
	<li><a href="/workflow.php">PE75 Workflow</a></li>
	<!-- <li><a href="#">Workshop 2011</a></li>
	<li><a href="#">Find primers</a></li> -->
	<li><a href="/contact.php">Contact Us</a></li>
	<li><a href="/help.php">Help</a></li>
	<li><a href="/admin">Admin</a></li>
	<!-- <li class="selected"><a href="#">F.A.Q.</a></li> -->
	</ul>
</div>