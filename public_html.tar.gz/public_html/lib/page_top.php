<?php require("head.php") ?>
<?php require("header.php") ?>
<div id="contents">
	<div id="schedules">
		<div id="main">
