<?php
if(count($_POST) < 1){
	#echo " POST NOT present<br>";
} else {
	$program = $_POST['program'];
	#$database = $_POST['database'];
	$seq = $_POST['seq'];
	$evalue = $_POST['evalue'];
}
	
?>
<h2>BLAST search Ac/Ds flannking sequences</h2>
<p>
To check if your sequence of interest contains an Ac/Ds tag, please paste or upload your sequence below and search the current collection of Ac/Ds flanking sequences.
</p>

<form id="blastform" action="/blast.php" method="post" enctype="multipart/form-data">
<span style="width: 200px; display:inline-block">Program</span>
<select name="program">
	<option selected>blastn</option>
	<option>tblastn</option>
</select>
<br>
<!-- 
<span style="width: 200px; display:inline-block">Database</span>
<select name="database">
	<option selected>Ds</option>
	<option>Ac</option>
</select>
<br>
-->
<span style="width: 200px; display:inline-block">E-value</span>
<select name="evalue">
	<option value="1e-50">1e-50</option>
	<option value="1e-20" selected>1e-20</option>
	<option value="0.01">0.01</option>
	<option value="1">1</option>
</select>
<br>
<span style="width: 200px; display:inline-block">Database</span>DsAc sequences (3006 sequences)
<br><br>
Paste query sequence (raw or FASTA format):
<br>
<textarea style="width:500px;" rows=5 id="seq" name="seq">
</textarea>
<br>
<span style="color: blue; cursor: pointer" onclick="loadTextArea('>Test\nTCTGCCTCTTTGAGCCTCCAACATTTTTTTAACCTGAAAGCAGAAGTCAATATGCACACCGTAAGCTTCTCTGAATTGTAAACATTTATTCTAATTTGTACTATGTGATATGTGCTTGTACTGATTTCGGTTGAAGCTGCTACTATAGCTTTTTAGTAAAGACCTCCCTACCAGAAATCACCCACTTGAAAAAAAACAAAAGAAAGGACAACAAAGAACTACCCAAAGCTTGCCTNGTCACACGCTAAAAGGCCATGGAGATGCCCTTTGGCATAAGTTGTGACTCCTAGAGTAATATGAGAACTGCATGTCCGGGTGCAAGCTGGATGCATGAGGATNAGAGTGGCAAGAATCCAAACTTTTCTATGGAGGAAGGAGAAATTGGTCA')">sample nucleotide sequence</span>
<script type="text/javascript">
function loadTextArea(text){
	$("#seq").empty();
	$("#seq").val(text);
}
</script>
<br>
<br>
Or upload query sequence <input type="file" name="file" id="file">
<br><br>
<input type="submit" name="submit" value="Submit">
</form>

<?php
if(count($_POST) < 1){
	#echo " POST NOT present<br>";
} else {
	$path = "/var/www/example.com/public_html/tmp/";
	$file = $path .  generateRandomString();
	#$file = $path .  "test";

	try{
		if(empty($seq) && empty($_FILES["file"]["tmp_name"])){
			throw new Exception("No Sequence provided and No File uploaded");
		}
		if(! empty($_FILES["file"]["tmp_name"])){
			save_uploaded_file($file);
		} elseif (! empty($seq)){
			file_put_contents("$file", $seq);
		}
		#verify_save_file();
		
		verify_fasta($file);
		verify_program($file, $program, $type);
		
		run_blast($file, $program, $evalue);
		show_contents($file);
	}
	catch (Exception $e){
		echo "<span style='color:red; font-weight: bold'>ERROR: ". $e->getMessage() ."</span><br>";
	}
}

function startsWith($haystack, $needle)
{
	return $needle === "" || strpos($haystack, $needle) === 0;
}

function verify_program($file, $program, $type){
	$line = ` head -n 2 $file | tail -n 1`;
	$line = preg_replace("/\r|\n/", "", $line);
	$pattern = "/[^ATGCN]/i";
	#error_log(preg_match($pattern, $line));
	if(preg_match($pattern, $line)){
		#error_log($line);
		#error_log("bad seq");
		throw new Exception("Input data is not compatible with BLASTn, BLASTx and tBLASTx");
	} 
}

function verify_fasta($file){
	$line = `head -n 1 $file`;
	#error_log($line);
	if(startsWith($line, ">")){
		#error_log("Fasta");
	} else {
		#error_log("Not Fasta");
		throw new Exception("Input data is not in FASTA format");
	}
}

function show_contents($file){
	echo "<pre>";
	echo `cat $file.blout`;
	echo "</pre>";
	
}

function verify_save_file(){
	if(empty($_FILES["file"]["tmp_name"])){
	} else {
		save_uploaded_file($file);
	}
}

function run_blast($file, $program, $evalue){
	#echo "/var/www/acds/data/blast-2.2.26/bin/blastall -i /var/www/acds/$file -o /var/www/acds/$file.blout -p blastn -e 1e-20<br>";
	#$output = `/media/storage/www/acds/data/blast-2.2.26/bin/blastall -i /media/storage/www/acds/$file -d /media/storage/www/acds/data/DsAc_3006seq.fasta -o /media/storage/www/acds/$file.blout -p $program -e $evalue`;
	$output = `/var/www/example.com/public_html/data/blast-2.2.26/bin/blastall -i $file -d /var/www/example.com/public_html/data/DsAc_3006seq.fasta -o $file.blout -p $program -e $evalue`;
	#echo "/var/www/html/biodb/acds/data/blast-2.2.26/bin/blastall -i $file -d /var/www/html/biodb/acds/data/DsAc_3006seq.fasta -o $file.blout -p $program -e $evalue";
	#$output = `tmp/blast-2.2.26/bin/blastall -i $file -o $file.blout -d /var/www/acds/data/DsAc_3006seq.fasta $file -p blastn -e 1e-20`;
	return $output;
}

function save_uploaded_file($file){
	#echo "($file)<br>";
	move_uploaded_file($_FILES["file"]["tmp_name"], $file);
}

function generateRandomString($length = 10) {
	$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	$randomString = '';
	for ($i = 0; $i < $length; $i++) {
		$randomString .= $characters[rand(0, strlen($characters) - 1)];
	}
	return $randomString;
}

?>
