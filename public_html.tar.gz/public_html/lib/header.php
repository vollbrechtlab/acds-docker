<div id="header">
	<div style="float:left; margin-left: 250px; width: 200px">
		<a href="/index.php" id="logo" style="text-decoration: none">
			<!-- <span style="color: white; font-size: 40px"><span style="color: yellow">Ac</span><span style="color: red">Ds</span>Tagging</span> -->
			<img src="/img/AcDs_Logo_2.png" height="50px">
		</a>
	</div>
	<div style="float:left; width: 600px">
		<span style="color: white; font-size: 20px; color:yellow">Genome-wide mutagenesis of <br>Maize using Ac/Ds transposons.</span>
	</div>
	<span class="shadow"></span>
</div>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-55307922-1', 'auto');
  ga('send', 'pageview');

</script>