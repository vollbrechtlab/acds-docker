<?php require("../lib/page_top.php") ?>
<?php $id = $_GET['geneidv2'] ?>
<h2><?php  echo $id ?></h2>

<div id="divtable">
	<?php 
		require("../ajax/gene_ds.php");
		echo $html;
	?>
</div>



<?php require("../lib/page_body.php") ?>
