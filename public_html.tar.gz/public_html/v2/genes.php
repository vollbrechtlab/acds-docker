<?php require("../lib/page_top.php") ?>
<h2>Genes (5b.60) - Closest Ds <a href="/v1/genes.php" style="font-size: small; background: yellow; text-decoration: none; padding: 10px" onMouseOver="this.style.background='#66CDAA'" onMouseOut="this.style.background='yellow'">Switch to RefGen_v1</a></h2>
<!-- 
<div style="float:right; cursor: pointer; position: relative;">
	<a href="/v1/genes.php" style="background: yellow; text-decoration: none; padding: 10px" onMouseOver="this.style.background='#66CDAA'" onMouseOut="this.style.background='yellow'">Switch to RefGen_v1</a>
</div>
-->
<table style="width:100%"><tr>
	<td style="width:120px">
		<span style="border: 1px solid black; background: teal; padding: 10px; color: white; cursor: pointer" onclick="previouspage()">&larr; previous</span>
	</td>
	<td>
		<span style="border: 1px solid black; background: teal; padding: 10px; color: white; cursor: pointer" onclick="nextpage()">next &rarr;</span>
	</td>
	<td style="padding-right: 20px">
	# per page: 
	<select id="perpage" onchange="update_table()">
		<option>100</option>
		<option>200</option>
		<option>500</option>
		<option>1000</option>
		<option>2000</option>
	</select>
	<br>
	Go to page:
	<select id="pagenum" onchange="update_table_page()">
		<?php
		for($i = 0, $j = 1; $i <= 63293; $i = $i + 100, $j = $j + 1){
			echo "<option val='$i'>$j</option>";
		}
		?>
	</select>
	<br>
	<span id="spaninfo">
		<!-- Displaying 1 - 100 of 63293 entries.-->
	</span>
	</td><td style="border-left: 2px solid black; padding-left: 20px">
	Sort by Column <br>
	<select id="colname" onchange="update_sort()">
		<option value="id">Gene transcript ID</option>
		<option value="description">Gene Descriptions</option>
		<option value="chromosome">chr:start..end</option>
		<option value="barcode">Closest Ds Insertion</option>
		<option value="ds_coordinate">Ds Insertion site</option>
		<option value="distance">Distance (kb) (in gene)</option>
		<option value="prime">5' or 3'</option>
	</select>
	</td><td style="border-left: 2px solid black; padding-left: 20px">
	Search
	<select id="searchfield">
		<option value="id">Gene transcript ID</option>
		<?php if($_GET['field'] == 'description'){ ?>
			<option value="description" selected="selected">Gene Descriptions</option>
		<?php } else { ?>
			<option value="description">Gene Descriptions</option>
		<?php } ?>
		<?php if($_GET['field'] == 'chromosome'){ ?>
			<option value="chromosome" selected="selected">chr:start..end</option>
		<?php } else { ?>
			<option value="chromosome">chr:start..end</option>
		<?php } ?>
		<option value="barcode">Closest Ds Insertion</option>
		<option value="chr">Chromosome</option>
		<?php if($_GET['field'] == 'distance'){ ?>
			<option value="distance" selected="selected">Distance (kb) (in gene)</option>
		<?php } else { ?>
			<option value="distance">Distance (kb) (in gene)</option>
		<?php } ?>
	</select>
	<br>
	<?php $term = isset($_GET['term']) ? $_GET['term'] : '' ?>
	for <input id="searchval" placeholder="enter value" value='<?php echo $term ?>' />
	<span style="border: 1px solid black; background: teal; color: white; cursor: pointer" onclick="searchterm()">Go</span>
	</td>
	</tr>
</table>

<input type="hidden" id="version" value="v2">


<div id="divtable">
	<?php
		if(isset($_GET['term'])){
			$field = $_GET['field'];
			$term = $_GET['term'];
		} 
		require("../ajax/database.php");
		echo $html;
	?>
</div>



<?php require("../lib/page_body.php") ?>
