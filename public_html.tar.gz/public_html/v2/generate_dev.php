<?php require("../lib/page_top.php") ?>
<?php $id = $_GET['id'] ?>
<h2><?php  echo $id ?></h2>

<div id="divtable">
	<?php 
		require("../ajax/generate_dev.php");
		echo $html;
	?>
</div>



<?php require("../lib/page_body.php") ?>