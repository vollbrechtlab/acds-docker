<?php 
require("../lib/page_top.php");
?>
<script type="text/javascript">
$(function(){
	pipeline_ajax();
});

function pipeline_table_settings(){
	var limit = $("#perpage option:selected").text();
	var page = $("#pagenum option:selected").text();
	var key = $("#selectterm option:selected").val();
	var term = $("input[name=term]").val();
	//var sort = get_sort_select();
	//var field = get_search_field();
	//var term = get_search_val();
	//var version = get_version();
	//var type = get_type();
	//console.log(version);
	return {
		limit: limit,
		page: page,
		key: key,
		term: term
	}
}
function pipeline_ajax(){
	ts = pipeline_table_settings();
	var url = '/ajax/pipeline.php';
	$.ajax({
	//* file
	url: url,
	//* data required
	data: {
		limit: ts.limit,
		page: ts.page,
		key: ts.key,
		term: ts.term
	},
	//* datatype returned
	dataType: 'json',
	//* request method
	method: 'GET',
	//* If success
	success: function(data){
		//console.log(data);
		//$('#divtable').empty();
		$('#divtable').html(data);
	},
	//* If error. show the error in console.log
	error: function(XMLHttpRequest, textStatus, errorThrown) {
		console.log(textStatus+" - "+errorThrown);
		console.log(XMLHttpRequest.responseText);
	}
});
}
</script>


<div id="divtable">
	<?php #require("../ajax/pipeline.php"); ?>
</div>
<?php 
require("../lib/page_body.php");
?>