<?php require("../lib/page_top.php") ?>
<h2>
Ds Insertion Sites (RefGen_v1)
<a href="/v2/insertions.php" style="font-size: small; background: yellow; text-decoration: none; padding: 10px" onMouseOver="this.style.background='#66CDAA'" onMouseOut="this.style.background='yellow'">Switch to RefGen_v2</a>
</h2>

<p>
<table style="width:100%"><tr>
	<td style="width:120px">
		<span style="border: 1px solid black; background: teal; padding: 10px; color: white; cursor: pointer" onclick="previouspage()">&larr; previous</span>
	</td>
	<td>
		<span style="border: 1px solid black; background: teal; padding: 10px; color: white; cursor: pointer" onclick="nextpage()">next &rarr;</span>
	</td>
	<td style="padding-right: 20px">
	# per page: 
	<select id="perpage" onchange="update_table()">
		<option>100</option>
		<option>200</option>
		<option>500</option>
		<option>1000</option>
		<option>2000</option>
	</select>
	<br>
	Go to page:
	<select id="pagenum" onchange="update_table_page()">
		<?php
		for($i = 0, $j = 1; $i <= 63293; $i = $i + 100, $j = $j + 1){
			echo "<option val='$i'>$j</option>";
		}
		?>
	</select>
	<br>
	<span id="spaninfo">
		<!-- Displaying 1 - 100 of 63293 entries.-->
	</span>
	</td><td style="border-left: 2px solid black; padding-left: 20px">
	Sort by Column <br>
	<select id="colname" onchange="update_sort()">
		<option value="barcode">Ds Barcode ID</option>
		<option value="placement">Placement</option>
		<option value="quality">Quality</option>
		<option value="chr">Chr</option>
		<option value="ds_coord">Ds Insertion site</option>
		<option value="closest_gene">Closest Gene</option>
		<option value="distance">Distance (kb) (in gene)</option>
		<option value="prime">5' or 3'</option>
		<option value="gene_blastp_homology">Gene description</option>
		<option value="confirm">Confirm</option>
	</select>
	</td><td style="border-left: 2px solid black; padding-left: 20px">
	Search
	<select id="searchfield">
		<option value="id" selected="selected">Gene transcript ID</option>
		<option value="description">Gene Descriptions</option>
		<option value="chromosome">chr:start..end</option>
		<option value="barcode">Closest Ds Insertion</option>
		<option value="chr">Chromosome</option>
		<option value="distance">Distance (kb) (in gene)</option>
	</select>
	<br>
	for <input id="searchval" placeholder="enter value" />
	<span style="border: 1px solid black; background: teal; color: white; cursor: pointer" onclick="searchterm()">Go</span>
	</td>
	</tr>
</table>

<input type="hidden" id="version" value="v1">
<input type="hidden" id="type" value="insertions">
</p>

<div id="divtable">
	<?php 
		$version = "v1";
		require("../ajax/insertion_database.php");
		echo $html;
	?>
</div>



<?php require("../lib/page_body.php") ?>
