<?php require("../lib/page_top.php") ?>
<?php require("../lib/login_check.php"); ?>
<h2>Admin Pages for AcDs.</h2>
<span style="color: red">Note: This is a restricted, password-protected area in PlantGDB, for <span style="font-weight: bold">authorized users only</span>. Do not use on a public computer.</span>
<br>
<br>
<h3>Select from the links below.</h3>
<a href="/admin/request_admin.php">View Order Invoices</a> - View or edit seed orders received online<br>
<a href="/admin/request_admin_viewall.php">List of Requested Barcodes</a> - View and edit all barcode requests for all orders<br>
<br>
<form action="/admin/logout.php" method="post">
	<input type="submit" value="Logout" />
</form>
</div>
		<div id="sidebar">
			<div class="section">
				<?php require("../lib/sidebar.php") ?>
			</div>
			<div id="section" >
				<?php require("../lib/sidebar_admin.php") ?>
			</div>
		</div>
	</div>
</div>
<?php require("footer.php") ?>