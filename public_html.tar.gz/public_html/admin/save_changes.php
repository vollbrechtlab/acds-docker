<?php require("../lib/page_top.php") ?>
<?php require("../lib/login_check.php"); ?>
<?php 

$invoice_no = mysql_real_escape_string($_POST['invoice_no']);
#$pricing = $_POST['pricing'];
$pricing = mysql_real_escape_string($_POST['us_ac_ind']);
$certification = mysql_real_escape_string($_POST['certification']); 
$user_uid = mysql_real_escape_string($_POST['user_uid']);

//UPDATE SEED_USERS TABLE
$sfname = mysql_real_escape_string($_POST['sfname']);
$slname = mysql_real_escape_string($_POST['slname']);
$sdepartment = mysql_real_escape_string($_POST['sdepartment']);
$sinstitution = mysql_real_escape_string($_POST['sinstitution']);
$sstreet_address = mysql_real_escape_string($_POST['sstreet_address']);
$scity = mysql_real_escape_string($_POST['scity']);
$scountry = mysql_real_escape_string($_POST['scountry']);
$sstate = mysql_real_escape_string($_POST['sstate']);
$szip = mysql_real_escape_string($_POST['szip']);
$semail = mysql_real_escape_string($_POST['semail']);
$sphone = mysql_real_escape_string($_POST['sphone']);
$sproject_leader = mysql_real_escape_string($_POST['sproject_leader']);
		
$bfname = mysql_real_escape_string($_POST['bfname']);
$blname = mysql_real_escape_string($_POST['blname']);
$bdepartment = mysql_real_escape_string($_POST['bdepartment']);
$binstitution = mysql_real_escape_string($_POST['binstitution']);
$bstreet_address = mysql_real_escape_string($_POST['bstreet_address']);
$bcity = mysql_real_escape_string($_POST['bcity']);
$bcountry = mysql_real_escape_string($_POST['bcountry']);
$bstate = mysql_real_escape_string($_POST['bstate']);
$bzip = mysql_real_escape_string($_POST['bzip']);
$bemail = mysql_real_escape_string($_POST['bemail']);
$bphone = mysql_real_escape_string($_POST['bphone']);
$spurchase_order = mysql_real_escape_string($_POST['spurchase_order']);
	
$update_user_info = "update SEED_USERS set sfname='$sfname', slname='$slname', department='$sdepartment', institution='$sinstitution', street_address='$sstreet_address', city='$scity', scountry='$scountry', state='$sstate', zip='$szip', email_address='$semail', phone='$sphone', project_leader='$sproject_leader', bfname='$bfname', blname='$blname', billing_department='$bdepartment', billing_institution='$binstitution', billing_street_address='$bstreet_address', billing_city='$bcity', bcountry='$bcountry', billing_state='$bstate', billing_zip='$bzip',billing_email_address='$bemail', purchase_order_no='$spurchase_order' where uid='$user_uid'";

try {
	$stmt = $db->prepare($update_user_info);
	$result = $stmt->execute();
	#echo $update_user_info;
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}

//END OF UPDATE SEED_USERS TABLE
	
	
//UPDATE INVOICES TABLE
$select_invoice = "select * from INVOICES where invoice_no = '$invoice_no'";

try {
	$stmt = $db->prepare($select_invoice);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}

$i = 0;
$subtotal = 0;
$result = $stmt->fetchAll();
foreach( $result as $invoice_array){

	$uid ="uid".$i;
  $uid = mysql_real_escape_string($_POST[$uid]);
	
   //Update Barcode
	$barcode = "barcode".$i;
	$barcode = mysql_real_escape_string($_POST[$barcode]);
	
	//Update Segregates_Ac
	$segregates_ac = "segregates_ac".$i;	
	//$segregates_ac = $_POST[$segregates_ac];	
	$segregates_ac = (mysql_real_escape_string($_POST[$segregates_ac])==true)?1:0;

	//Update Phenotype
	$phenotype = "phenotype".$i;
	$phenotype = mysql_real_escape_string($_POST[$phenotype]);
	
	//Update Nursery Propagation
	$nursery_propagation = "nursery_propagation".$i;
	$nursery_propagation = mysql_real_escape_string($_POST[$nursery_propagation]);
	
	//Update Genotyping
	$genotyping = "genotyping".$i;
	$genotyping = mysql_real_escape_string($_POST[$genotyping]);
	
	//Update ac_immobilized_stock
	$ac_immobilized_stock = "ac_immobilized_stock".$i;
	$ac_immobilized_stock = mysql_real_escape_string($_POST[$ac_immobilized_stock]);
	
	//Update Tester
	$tester = "tester".$i;
	$tester = mysql_real_escape_string($_POST[$tester]);
	
	//Update notes
	$note = "note".$i;	
	$note = mysql_real_escape_string($_POST[$note]);	
	
	//Update Quantity
	$quantity = "quantity".$i;
	$quantity = mysql_real_escape_string($_POST[$quantity]);
	
	//Update Shipping cost
	$ship_cost = mysql_real_escape_string($_POST["ship_cost"]);
	
	//Update Subtotal
	$subtotal = $subtotal + ($quantity * $pricing);
	
	$update = "update INVOICES set order_price = $pricing, note = '$note' , tester='$tester', ac_immobilized_stock='$ac_immobilized_stock', genotyping='$genotyping', nursery_propagation='$nursery_propagation', phenotype = '$phenotype' , segregates_ac = $segregates_ac, order_quantity = '$quantity',order_barcode = '$barcode', ship_cost='$ship_cost' where uid = '$uid'";
	#$check_update = mysql_query($update);
	
	try {
		$stmt = $db->prepare($update);
		$result = $stmt->execute();
		#echo "<br>" . $update . "</br>";
	}
	catch(PDOException $ex) {
		die("Failed to run query: " . $ex->getMessage());
	}
	
	echo $update;
	$i = $i +1;	
};	

$grand_total = $subtotal + $ship_cost + $certification;	
//Update Grand total and subtotal	
$update = "update INVOICES set order_certification = '$certification', order_total = '$grand_total' , order_subtotal = '$subtotal' where invoice_no = '$invoice_no'";

try {
	$stmt = $db->prepare($update);
	$result = $stmt->execute();
	#echo "<br>" . $update . "</br>";
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}

echo $update;
header("Location: request_view.php?invoice_no=$invoice_no");
exit();
	
	?>