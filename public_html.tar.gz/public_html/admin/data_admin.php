<?php require("../lib/page_top.php") ?>
<?php require("../lib/login_check.php"); ?>
<?php

$id = mysql_real_escape_string($_GET['id']);

echo "<script language=\"javascript\" type=\"text/javascript\">
function checkImage(fieldName){
	var reImage=/^\S+.jpg$/; //regular expression defining a image name
	if (document.getElementsByName(fieldName)[0].value.search(reImage)==-1) // match failed
		alert(\"Please enter a valid \" + fieldName);
}
</script>
";

echo "<script language=\"javascript\" type=\"text/javascript\">
function confirmAndDelete(){
	var agree=confirm(\"Are you sure you wish to delete this barcode?\");
	if(agree)
		return true;
	else
		return false;
}
</script>
";

$get_data = "select * from BARCODES where barcode='$id'";
try {
	$stmt = $db->prepare($get_data);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}

#$check_get_data = mysql_query($get_data);
function formatDate($format,$dateStr)	{
	if (trim($dateStr) == "" || substr($dateStr,0,10) == "0000-00-00") {
		return '';
	}
	$ts = strtotime($dateStr);
	if ($ts === false) {
		return '';
	}
	return date($format,$ts);
}

$result = $stmt->fetchAll();
foreach($result as $barcodes_array){
#while ($barcodes_array = mysql_fetch_array($check_get_data)){

	$barcode = $barcodes_array['barcode'];
	$ipcr_date = $barcodes_array['ipcr_date'];
	$ipcr_user = $barcodes_array['ipcr_user'];
	$restriction_enzyme = $barcodes_array['restriction_enzyme'];
	$which_band = $barcodes_array['which_band'];
	$southern_band_size = $barcodes_array['southern_band_size'];
	$southern_notes = $barcodes_array['southern_notes'];
	$ipcr_primer_set = $barcodes_array['ipcr_primer_set'];
	$re_pcr_primer_set = $barcodes_array['re_pcr_primer_set'];
	$ipcr_band_size = $barcodes_array['ipcr_band_size'];
	$amplified_fragment = $barcodes_array['amplified_fragment'];
	$ipcr_notes = $barcodes_array['ipcr_notes'];
	$template = $barcodes_array['template'];
	$sent_to_ia = $barcodes_array['sent_to_ia'];
	$shipping_notes = $barcodes_array['shipping_notes'];
	$selection = $barcodes_array['selection'];
	$ds_donor = $barcodes_array['ds_donor'];
	$seq_expt_date = $barcodes_array['seq_expt_date'];
	$seq_experimenter = $barcodes_array['seq_experimenter'];
	$f_seq_primer = $barcodes_array['f_seq_primer'];
	$r_seq_primer = $barcodes_array['r_seq_primer'];
	$expected_size = $barcodes_array['expected_size'];
	$seq_size = $barcodes_array['seq_size'];
	$sequencing_notes = $barcodes_array['sequencing_notes'];
	$parental = $barcodes_array['parental'];
	$release_seq = $barcodes_array['release_seq'];
	$release_notes = $barcodes_array['release_notes'];
	$placed_chr = $barcodes_array['placed_chr'];

	$confirm_method = $barcodes_array['confirm_method'];
	$confirm_result = $barcodes_array['confirm_result'];
	$confirm_pcr_protocol = $barcodes_array['confirm_pcr_protocol'];
	$confirm_ds_primer = $barcodes_array['confirm_ds_primer'];
	$confirm_ds_primersequence = $barcodes_array['confirm_ds_primersequence'];
	$confirm_flanking_primer_type = $barcodes_array['confirm_flanking_primer_type'];
	$confirm_flanking_primer_seq = $barcodes_array['confirm_flanking_primer_seq'];
	$confirm_ds_primer_tm = $barcodes_array['confirm_ds_primer_tm'];
	$confirm_flanking_primer_tm = $barcodes_array['confirm_flanking_primer_tm'];
	$confirm_amplicon_size = $barcodes_array['confirm_amplicon_size'];
	$confirm_amplicon_sequence = $barcodes_array['confirm_amplicon_sequence'];
	$confirm_amplicon_gc = $barcodes_array['confirm_amplicon_gc'];
	$confirm_amplicon_flag = $barcodes_array['confirm_amplicon_flag'];

	$confirmed = $barcodes_array['confirmed'];
	$Redundancy = $barcodes_array['Redundancy'];
	$ipcr_image = $barcodes_array['ipcr_image'];
	$southern_image = $barcodes_array['southern_image'];
	$southern_image_comments = $barcodes_array['southern_image_comments'];
	$ipcr_image_comments = $barcodes_array['ipcr_image_comments'];
	$fds_clone_5a = $barcodes_array['fds_clone_5a'];
	$fds_clone_3a = $barcodes_array['fds_clone_3a'];
	$fds_clone_5d = $barcodes_array['fds_clone_5d'];
	$fds_clone_3d = $barcodes_array['fds_clone_3d'];


}

$get_placement = "select group_concat(placement) as placement, group_concat(bac_gi) as chromosome, group_concat(bac_start)  as coordinate from PLACEMENT_CHR_ALL_V2 where barcode='$id' group by barcode";
try {
	$stmt = $db->prepare($get_placement);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}
$result = $stmt->fetchAll();

foreach($result as $placement_array){
	$placement = $placement_array['placement'];
	$chr = $placement_array['chromosome'];
	$coord= $placement_array['coordinate'];
}

$formatted_ipcr_date = formatDate("Y-m-d",$ipcr_date);
$formatted_sent_to_ia = formatDate("Y-m-d",$sent_to_ia);
$formatted_seq_expt_date = formatDate("Y-m-d", $seq_expt_date);

$display_ipcr_primer_sets = "
<option value=\"$ipcr_primer_set\">$ipcr_primer_set</option>";


$get_extra_ipcr_primer_set = "select distinct(ipcr_primer_set) from BARCODES where ipcr_primer_set != '$ipcr_primer_set'";
try {
	$stmt = $db->prepare($get_extra_ipcr_primer_set);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}
$result = $stmt->fetchAll();
#$check_get_extra_ipcr_primer_set = mysql_query($get_extra_ipcr_primer_set);
foreach ($result as $extra_ipcr_primer_set_array){
	$extra_ipcr_primer_set = $extra_ipcr_primer_set_array['ipcr_primer_set'];
	$display_ipcr_primer_sets .= "<option value=\"$extra_ipcr_primer_set\">$extra_ipcr_primer_set</option>";

}
$display_re_pcr_primer_sets = "
<option value=\"$re_pcr_primer_set\">$re_pcr_primer_set</option>";


$get_extra_re_pcr_primer_set = "select distinct(re_pcr_primer_set) from BARCODES where re_pcr_primer_set != '$re_pcr_primer_set'";
try {
	$stmt = $db->prepare($get_extra_re_pcr_primer_set);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}
$result = $stmt->fetchAll();
#$check_get_extra_re_pcr_primer_set = mysql_query($get_extra_re_pcr_primer_set);
foreach ($result as $extra_re_pcr_primer_set_array){
	$extra_re_pcr_primer_set = $extra_re_pcr_primer_set_array['re_pcr_primer_set'];
	$display_re_pcr_primer_sets .= "<option value=\"$extra_re_pcr_primer_set\">$extra_re_pcr_primer_set</option>";

}
$display_templates = "
<option value=\"$template\">$template</option>";


$get_extra_template = "select distinct(template) from BARCODES where template != '$template'";
try {
	$stmt = $db->prepare($get_extra_template);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}
$result = $stmt->fetchAll();
#$check_get_extra_template = mysql_query($get_extra_template);
foreach($result as $extra_template_array){
	$extra_template = $extra_template_array['template'];
	$display_templates .= "<option value=\"$extra_template\">$extra_template</option>";
}
$display_seq_experimenters = "
<option value=\"$seq_experimenter\">$seq_experimenter</option>";


$get_extra_seq_experimenter = "select distinct(seq_experimenter) from BARCODES where seq_experimenter != '$seq_experimenter'";
try {
	$stmt = $db->prepare($get_extra_seq_experimenter);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}
$result = $stmt->fetchAll();
#$check_get_extra_seq_experimenter = mysql_query($get_extra_seq_experimenter);
foreach($result as $extra_seq_experimenter_array){
	$extra_seq_experimenter = $extra_seq_experimenter_array['seq_experimenter'];
	$display_seq_experimenters .= "<option value=\"$extra_seq_experimenter\">$extra_seq_experimenter</option>";

}
$display_f_seq_primers = "
<option value=\"$f_seq_primer\">$f_seq_primer</option>";


$get_extra_f_seq_primer = "select distinct(f_seq_primer) from BARCODES where f_seq_primer != '$f_seq_primer'";
try {
	$stmt = $db->prepare($get_extra_f_seq_primer);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}
$result = $stmt->fetchAll();
#$check_get_extra_f_seq_primer = mysql_query($get_extra_f_seq_primer);
foreach($result as $extra_f_seq_primer_array){
	$extra_f_seq_primer = $extra_f_seq_primer_array['f_seq_primer'];
	$display_f_seq_primers .= "<option value=\"$extra_f_seq_primer\">$extra_f_seq_primer</option>";

}
$display_r_seq_primers = "
<option value=\"$r_seq_primer\">$r_seq_primer</option>";


$get_extra_r_seq_primer = "select distinct(r_seq_primer) from BARCODES where r_seq_primer != '$r_seq_primer'";
try {
	$stmt = $db->prepare($get_placement);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}
$result = $stmt->fetchAll();
#$check_get_extra_r_seq_primer = mysql_query($get_extra_r_seq_primer);
foreach($result as $extra_r_seq_primer_array){
	$extra_r_seq_primer = $extra_r_seq_primer_array['r_seq_primer'];
	$display_r_seq_primers .= "<option value=\"$extra_r_seq_primer\">$extra_r_seq_primer</option>";

}

$display_confirm_result = "
<option value=\"$confirm_result\">$confirm_result</option>";


$get_extra_confirm_result = "select distinct(confirm_result) from BARCODES where confirm_result != '$confirm_result'";
try {
	$stmt = $db->prepare($get_extra_confirm_result);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}
$result = $stmt->fetchAll();
#$check_get_extra_confirm_result = mysql_query($get_extra_confirm_result);
foreach ($result as $extra_confirm_result_array){
	$extra_confirm_result = $extra_confirm_result_array['confirm_result'];
	$display_confirm_result .= "<option value=\"$extra_confirm_result\">$extra_confirm_result</option>";

}

$display_confirm_pcr_protocol = "
<option value=\"$confirm_pcr_protocol\">$confirm_pcr_protocol</option>";


$get_extra_confirm_pcr_protocol = "select distinct(confirm_pcr_protocol) from BARCODES where confirm_pcr_protocol != '$confirm_pcr_protocol'";
try {
	$stmt = $db->prepare($get_extra_confirm_pcr_protocol);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}
$result = $stmt->fetchAll();
#$check_get_extra_confirm_pcr_protocol = mysql_query($get_extra_confirm_pcr_protocol);
foreach ($result as $extra_confirm_pcr_protocol_array){
	$extra_confirm_pcr_protocol = $extra_confirm_pcr_protocol_array['confirm_pcr_protocol'];
	$display_confirm_pcr_protocol .= "<option value=\"$extra_confirm_pcr_protocol\">$extra_confirm_pcr_protocol</option>";

}

$display_confirm_ds_primer = "
<option value=\"$confirm_ds_primer\">$confirm_ds_primer</option>";


$get_extra_confirm_ds_primer = "select distinct(confirm_ds_primer) from BARCODES where confirm_ds_primer != '$confirm_ds_primer'";
try {
	$stmt = $db->prepare($get_extra_confirm_ds_primer);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}
$result = $stmt->fetchAll();
#$check_get_extra_confirm_ds_primer = mysql_query($get_extra_confirm_ds_primer);
foreach ($result as $extra_confirm_ds_primer_array){
	$extra_confirm_ds_primer = $extra_confirm_ds_primer_array['confirm_ds_primer'];
	$display_confirm_ds_primer .= "<option value=\"$extra_confirm_ds_primer\">$extra_confirm_ds_primer</option>";

}

$display_confirm_amplicon_flag = "
<option value=\"$confirm_amplicon_flag\">$confirm_amplicon_flag</option>";


$get_extra_confirm_amplicon_flag = "select distinct(confirm_amplicon_flag) from BARCODES where confirm_amplicon_flag != '$confirm_amplicon_flag'";
try {
	$stmt = $db->prepare($get_extra_confirm_amplicon_flag);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}
$result = $stmt->fetchAll();
#$check_get_extra_confirm_amplicon_flag = mysql_query($get_extra_confirm_amplicon_flag);
foreach($result as $extra_confirm_amplicon_flag_array){
	$extra_confirm_amplicon_flag = $extra_confirm_amplicon_flag_array['confirm_amplicon_flag'];
	$display_confirm_amplicon_flag .= "<option value=\"$extra_confirm_amplicon_flag\">$extra_confirm_amplicon_flag</option>";
}

$display_ipcr_users = "<option value=\"$ipcr_user\">$ipcr_user</option>";

$get_extra_ipcr_user = "select distinct(ipcr_user) from BARCODES where ipcr_user != '$ipcr_user'";
try {
	$stmt = $db->prepare($get_extra_ipcr_user);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}
$result = $stmt->fetchAll();
#$check_get_extra_ipcr_user = mysql_query($get_extra_ipcr_user);
foreach($result as $extra_ipcr_user_array){
	$extra_ipcr_user = $extra_ipcr_user_array['ipcr_user'];
	$display_ipcr_users .= "<option value=\"$extra_ipcr_user\">$extra_ipcr_user</option>";
}

$display_bands = "<option value=\"$which_band\">$which_band</option>";
$get_extra_band = "select distinct(which_band) from BARCODES where which_band != '$which_band'";
try {
	$stmt = $db->prepare($get_extra_band);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}
$result = $stmt->fetchAll();
#$check_get_extra_band = mysql_query($get_extra_band);
foreach ($result as $extra_band_array){
	$extra_band = $extra_band_array['which_band'];
	$display_bands .= "<option value=\"$extra_band\">$extra_band</option>";
}

$display_enzymes = "
<option value=\"$restriction_enzyme\">$restriction_enzyme</option>";

$get_extra_enzymes = "select distinct(restriction_enzyme) from BARCODES where restriction_enzyme != '$restriction_enzyme'";
try {
	$stmt = $db->prepare($get_extra_enzymes);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}
$result = $stmt->fetchAll();
#$check_get_extra_enzymes = mysql_query($get_extra_enzymes);
foreach($result as $extra_enzyme_array) {
	$extra_enzyme_name = $extra_enzyme_array['restriction_enzyme'];
	$display_enzymes .= "<option value=\"$extra_enzyme_name\">$extra_enzyme_name</option>";
}

if ($ds_donor == "yes" || $ds_donor == "Yes"){
	$display_ds_donors = "<input type=\"radio\" name=\"ds_donor\" value=\"yes\" checked=\"checked\" />Yes<input type=\"radio\" name=\"ds_donor\" value=\"no\" />No";
} else if ($ds_donor == "no" || $ds_donor == "No") {
	$display_ds_donors = "<input type=\"radio\" name=\"ds_donor\" value=\"yes\" />Yes</input><input type=\"radio\" name=\"ds_donor\" value=\"no\" checked=\"checked\" />No";

} else {
	$display_ds_donors = "<input type=\"radio\" name=\"ds_donor\" value=\"yes\" />Yes<input type=\"radio\" name=\"ds_donor\" value=\"no\" />No";
}

if ($parental == "yes" || $parental == "Yes"){
	$display_parentals = "<input type=\"radio\" name=\"parental\" value=\"yes\" checked=\"checked\" />Yes<input type=\"radio\" name=\"parental\" value=\"no\" />No";
} else if ($parental == "no" || $parental == "No") {
	$display_parentals = "<input type=\"radio\" name=\"parental\" value=\"yes\" />Yes<input type=\"radio\" name=\"parental\" value=\"no\" checked=\"checked\" />No";

} else {
	$display_parentals = "<input type=\"radio\" name=\"parental\" value=\"yes\" />Yes<input type=\"radio\" name=\"parental\" value=\"no\" />No";
}

$display_block .= "
<h1 class=\"bottommargin1 admin\">$barcode &nbsp; &nbsp; <span class=\"heading\"><a class=\"admin smallerfont\" href=\"/prj/AcDsTagging/Admin/barcodes_admin.php\">Return to Barcodes</a></span></h1>

<!--Code for search by a specific barcode -->

<form method=\"post\" name=\"given_barcode_data\" action=\"/prj/AcDsTagging/Admin/search_by_barcode.php\">
Search by a specific barcode : <input name=\"gbarcode\" size=\"20\" />
<input type=\"submit\" value=\"Search\" name=\"Search\" />
</form>

<!--End of Code for search by a specific barcode -->

<!--Code for navigating barcodes-->

<br />
<form method=\"post\" action=\"/prj/AcDsTagging/Admin/navigate_barcodes.php\">
<input type=\"hidden\" name=\"barcode\" value=\"$barcode\" />
<table style=\"font-size:12px\">
<tr>
<td align = \"left\">
<input type=\"submit\" value=\"Previous Record\" name=\"Previous\" />
</td><td align = \"right\">
<input type=\"submit\" value=\"Next Record\" name=\"Next\" />
</td></tr></table></form>


<!--End of Code for navigating barcodes-->


<br />


<form method=\"post\" name=\"barcode_data\" action=\"/prj/AcDsTagging/Admin/update_barcodes.php\">

<table id=\"barcode_admin\" border=\"0\" style=\"font-size:12px\">
<tr style=\"height: 20px\"><td width=\"135\">barcode </td><td width=\"25\">$barcode</td></tr>
<tr style=\"height: 20px\"><td width=\"35\">placement:</td><td width=\"5\">$placement &nbsp;&nbsp;<a href=\"/prj/AcDsTagging/generate.php?id=$barcode\">View Placement (v1)</a>; &nbsp;&nbsp;<a href=\"/prj/AcDsTagging/generate_v2.php?id=$barcode\">View Placement (v2)</a>; &nbsp;&nbsp;<a href=\"/prj/AcDsTagging/Admin/generate_admin.php?id=$barcode\">Edit Placement Data</a></td></tr>
<tr style=\"height: 20px\"><td width=\"35\">chromosome: </td><td width=\"5\">$chr</td></tr>
<tr style=\"height: 20px\"><td width=\"35\">coordinate: </td><td width=\"5\">$coord</td></tr>
<tr><td width=\"135\">ipcr_date </td><td width=\"300\"><input name=\"ipcr_date\" size=\"8\" value=\"$formatted_ipcr_date\" /></td></tr>
<tr><td width=\"135\">ipcr_user </td><td width=\"300\"><select name=\"ipcr_user\">$display_ipcr_users</select></td></tr>
<tr><td width=\"135\">restriction_enzyme </td><td width=\"300\"><select name=\"restriction_enzyme\">$display_enzymes</select></td></tr>
<tr><td width=\"135\">which_band </td><td width=\"300\"><select name=\"which_band\">$display_bands</select></td></tr>
<tr><td width=\"135\">southern_band_size </td><td width=\"300\"><input name=\"southern_band_size\" size=\"1\" value=\"$southern_band_size\" /></td></tr>
<tr><td width=\"135\">southern_notes </td><td width=\"300\"><input name=\"southern_notes\" size=\"50\" value=\"$southern_notes\" /></td></tr>
<tr><td width=\"135\">ipcr_primer_set </td><td width=\"300\"><select name=\"ipcr_primer_set\">$display_ipcr_primer_sets</select></td></tr>
<tr><td width=\"135\">re_pcr_primer_set </td><td width=\"300\"><select name=\"re_pcr_primer_set\">$display_re_pcr_primer_sets</select></td></tr>
<tr><td width=\"135\">ipcr_band_size </td><td width=\"300\"><input name=\"ipcr_band_size\" size=\"1\" value=\"$ipcr_band_size\" /></td></tr>
<tr><td width=\"135\">amplified_fragment </td><td width=\"300\"><input name=\"amplified_fragment\" size=\"1\" value=\"$amplified_fragment\" /></td></tr>
<tr><td width=\"135\">ipcr_notes </td><td width=\"300\"><input name=\"ipcr_notes\" size=\"50\" value=\"$ipcr_notes\" /></td></tr>
<tr><td width=\"135\">template </td><td width=\"300\"><select name=\"template\">$display_templates</select></td></tr>
<tr><td width=\"135\">sent_to_ia </td><td width=\"300\"><input name=\"sent_to_ia\" size=\"8\" value=\"$formatted_sent_to_ia\" /></td></tr>
<tr><td width=\"135\">shipping_notes </td><td width=\"300\"><input name=\"shipping_notes\" size=\"50\" value=\"$shipping_notes\" /></td></tr>
<tr><td width=\"135\">selection </td><td width=\"300\"><input name=\"selection\" size=\"20\" value=\"$selection\" /></td></tr>
<tr><td width=\"135\">ds_donor </td><td width=\"300\">$display_ds_donors</td></tr>
<tr><td width=\"135\">seq_expt_date </td><td width=\"300\"><input name=\"seq_expt_date\" size=\"8\" value=\"$formatted_seq_expt_date\" /></td></tr>
<tr><td width=\"135\">seq_experimenter </td><td width=\"300\"><select name=\"seq_experimenter\">$display_seq_experimenters</select></td></tr>
<tr><td width=\"135\">f_seq_primer </td><td width=\"300\"><select name=\"f_seq_primer\">$display_f_seq_primers</select></td></tr>
<tr><td width=\"135\">r_seq_primer </td><td width=\"300\"><select name=\"r_seq_primer\">$display_r_seq_primers</select></td></tr>
<tr><td width=\"135\">expected_size </td><td width=\"300\"><input name=\"expected_size\" size=\"1\" value=\"$expected_size\" /></td></tr>
<tr><td width=\"135\">seq_size </td><td width=\"300\"><input name=\"seq_size\" size=\"1\" value=\"$seq_size\" /></td></tr>
<tr><td width=\"135\">sequencing_notes </td><td width=\"300\"><input name=\"sequencing_notes\" size=\"50\" value=\"$sequencing_notes\" /></td></tr>
<tr><td width=\"135\">parental </td><td width=\"300\">$display_parentals</td></tr>
<tr><td width=\"135\">release_seq </td><td width=\"300\"><input name=\"release_seq\" size=\"20\" value=\"$release_seq\" /></td></tr>
<tr><td width=\"135\">release_notes </td><td width=\"300\"><input name=\"release_notes\" size=\"50\" value=\"$release_notes\" /></td></tr>
<tr><td width=\"135\">placed_chr </td><td width=\"300\"><input name=\"placed_chr\" size=\"20\" value=\"$placed_chr\" /></td></tr>

<tr><td width=\"135\">confirm_method </td><td width=\"300\"><input name=\"confirm_method\" size=\"20\" value=\"$confirm_method\" /></td></tr>
<tr><td width=\"135\">confirm_result </td><td width=\"300\"><select name=\"confirm_result\">$display_confirm_result</select></td></tr>
<tr><td width=\"135\">confirm_pcr_protocol</td><td width=\"300\"><select name=\"confirm_pcr_protocol\">$display_confirm_pcr_protocol</select></td></tr>
<tr><td width=\"135\"> confirm_ds_primer </td><td width=\"300\"><select name=\"confirm_ds_primer\">$display_confirm_ds_primer</select></td></tr>

<tr><td width=\"135\"> confirm_ds_primersequence </td><td width=\"300\"><textarea cols=\"35\" rows=\"1\" name=\"confirm_ds_primersequence\"> $confirm_ds_primersequence </textarea></td></tr>
<tr><td width=\"135\"> confirm_flanking_primer_type  </td><td width=\"300\"><select name=\"confirm_flanking_primer_type\">$display_confirm_flanking_primer_type</select></td></tr>
<tr><td width=\"135\"> confirm_flanking_primer_seq </td><td width=\"300\"><textarea cols=\"35\" rows=\"1\" name=\"confirm_flanking_primer_seq\"> $confirm_flanking_primer_seq </textarea></td></tr>
<tr><td width=\"135\"> confirm_ds_primer_tm </td><td width=\"300\"><input name=\"confirm_ds_primer_tm\" size=\"20\" value=\" $confirm_ds_primer_tm\" /></td></tr>
<tr><td width=\"135\"> confirm_flanking_primer_tm  </td><td width=\"300\"><input name=\" $confirm_flanking_primer_tm \" size=\"20\" value=\" $confirm_flanking_primer_tm\" /></td></tr>

<tr><td width=\"135\">confirm_amplicon_size </td><td width=\"300\"><input name=\"confirm_amplicon_size\" size=\"20\" value=\"$confirm_amplicon_size\" /></td></tr>
<tr><td width=\"135\">confirm_amplicon_sequence </td><td width=\"300\"><textarea cols=\"50\" rows=\"5\" name=\"confirm_amplicon_sequence\" >$confirm_amplicon_sequence</textarea></td></tr>
<tr><td width=\"135\">confirm_amplicon_gc </td><td width=\"300\"><input name=\"confirm_amplicon_gc\" size=\"20\" value=\"$confirm_amplicon_gc\" /></td></tr>
<tr><td width=\"135\">confirm_amplicon_flag </td><td width=\"300\"><select name=\"confirm_amplicon_flag\"> $display_confirm_amplicon_flag</select></td></tr>

<tr><td width=\"135\">confirmed </td><td width=\"300\"><input name=\"confirmed\" size=\"20\" value=\"$confirmed\" /></td></tr>
<tr><td width=\"135\">Redundancy </td><td width=\"300\"><input name=\"Redundancy\" size=\"20\" value=\"$Redundancy\" /></td></tr>
<tr><td width=\"135\">ipcr_image </td><td width=\"300\"><input name=\"ipcr_image\" size=\"40\" value=\"$ipcr_image\" onblur=\"checkImage(this.name);\" /></td></tr>
<tr><td width=\"135\">southern_image </td><td width=\"300\"><input name=\"southern_image\" size=\"40\" value=\"$southern_image\" onblur=\"checkImage(this.name);\" /></td></tr>
<tr><td width=\"135\">southern_image_comments </td><td width=\"300\"><input name=\"southern_image_comments\" size=\"50\" value=\"$southern_image_comments\" /></td></tr>
<tr><td width=\"135\">ipcr_image_comments </td><td width=\"300\"><input name=\"ipcr_image_comments\" size=\"50\" value=\"$ipcr_image_comments\" /></td></tr>
<tr><td width=\"135\">fds_clone_5d </td><td width=\"300\"><input name=\"fds_clone_5d\" size=\"20\" value=\"$fds_clone_5d\" /></td></tr>
<tr><td width=\"135\">fds_clone_5a </td><td width=\"300\"><input name=\"fds_clone_5a\" size=\"20\" value=\"$fds_clone_5a\" /></td></tr>
<tr><td width=\"135\">fds_clone_3a </td><td width=\"300\"><input name=\"fds_clone_3a\" size=\"20\" value=\"$fds_clone_3a\" /></td></tr>
<tr><td width=\"135\">fds_clone_3d </td><td width=\"300\"><input name=\"fds_clone_3d\" size=\"20\" value=\"$fds_clone_3d\" /></td></tr>
<tr>
<td width=\"135\"><p>&nbsp;</p><input type=\"hidden\" name=\"barcode\" value=\"$barcode\" />
</td><td width=\"300\" align=\"right\"><input type=\"submit\" name=\"submit\" value=\"Update\" /></td></tr>

</table>
<br />
</form>

<form method=\"post\" action=\"/prj/AcDsTagging/Admin/delete_barcode.php\">
<table><tr>
<td width=\"135\"><p>&nbsp;</p><input type=\"hidden\" name=\"barcode\" value=\"$barcode\" /></td>
<td width=\"300\" align=\"left\"><input type=\"submit\" name=\"delete\" value=\"Delete\" onclick=\"confirmAndDelete();\" /></td>
</tr></table>
</form>

";

echo $display_block;

?>
<?php require("../lib/page_body.php") ?>