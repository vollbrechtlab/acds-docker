<?php require("../lib/page_top.php") ?>
<?php require("../lib/login_check.php"); ?>
<?php 

$query = "select * from SEED_USERS order by uid desc";

try {
	$stmt = $db->prepare($query);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}

?>
<h2>Manage Invoices</h2>
<script type="text/javascript" src="/js/jquery-latest.js"></script> 
<script type="text/javascript" src="/js/jquery.tablesorter.js"></script> 
<script type="text/javascript">
$(document).ready(function(){
	$("#myTable").tablesorter({headers: {0: {sorter:"currency"}}});
});
</script> 
<table class="tab tablesorter" id="myTable">
<thead>
	<tr>
	<th>Invoice Number</th>
	<th width="100px">Barcode</th>
	<th width="100px">Order Date</th>
	<th width="100px">Invoiced date</th>
	<th width="100px">Shipped date</th>
	<th>Institution</th>
	<th>Department</th>
	<th width="200px">Name</th>
	<th>Order Subtotal</th>
	<th>Order Total</th>
	<th>Order Status</th>
</tr>
</thead>
<tbody>

<?php
$result = $stmt->fetchAll();

foreach($result as $row){
	#$html = '<tr><td>'.$row['uid'].'</td>';
	
	$in_query = "select * from INVOICES where user_uid = ". $row['uid'] ." group by user_uid";
	#echo $in_query;
	
	try {
		$in_stmt = $db->prepare($in_query);
		$in_row_result = $in_stmt->execute();
	}
	catch(PDOException $ex) {
		die("Failed to run query: " . $ex->getMessage());
	}
	$in_row_result = $in_stmt->fetchAll();
	
	foreach($in_row_result as $in_result){
		$html = '<tr><td><a href="/admin/request_view.php?invoice_no='.$in_result['invoice_no'].'">#'.$in_result['invoice_no'].'</a></td>';
		$html .= '<td>'.$in_result['order_barcode'].'</td>';
		$html .= '<td>'.$in_result['order_date'].'</td>';
		$html .= '<td>'. (($in_result['invoice_date'] == "0000-00-00") ? "" : $in_result['invoice_date']).'</td>';
		#$html .= '<td>'.$in_result['invoice_no'].'</td>';
		$html .= '<td>'.$in_result['shipped_date'].'</td>';
		
		$shipped_date = $in_result['shipped_date'];
		if ($shipped_date > '0000-00-00'){
			$status = "Shipped";
		} else if ($invoice_date > '0000-00-00'){
			$status = "Invoiced";
		} else if ($payment_recvd_date > '0000-00-00'){
			$status = "Payment Recvd";
		} else {
			$status = "Ordered";
		};
	
		$html .= '<td>'. (($row['institution'] == "NULL") ? "" : $row['institution']) .'</td>';
		$html .= '<td>'. (($row['department']== "NULL") ? "" : $row['department']) .'</td>';
		$html .= '<td>'.$row['sfname'].' '.$row['slname'].'</td>';
		$html .= '<td>'.$in_result['order_subtotal'].'</td>';
		$html .= '<td>'.$in_result['order_total'].'</td>';
		$html .= '<td>'.$status.'</td>';
		$html .= '</tr>';
	
		echo $html;
	}
}

?>

</tbody>
</table>
</div>
		<div id="sidebar">
			<div class="section">
				<?php require("../lib/sidebar.php") ?>
			</div>
			<div id="section" >
				<?php require("../lib/sidebar_admin.php") ?>
			</div>
		</div>
	</div>
</div>
<?php require("footer.php") ?>