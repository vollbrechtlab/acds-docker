<?php require("../lib/page_top.php") ?>
<?php require("../lib/login_check.php"); ?>
<?php 
$invoice_no = mysql_real_escape_string($_GET['invoice_no']);

$select_invoice = "select * from INVOICES where invoice_no = '$invoice_no'";

try {
	$stmt = $db->prepare($select_invoice);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}

$result = $stmt->fetchAll();

foreach($result as $row){
	$user_uid = $row['user_uid'];
	$order_date = $row['order_date'];
	$payment_recvd_date = $row['payment_recvd_date'];
	$invoice_date = $row['invoice_date'];
	$shipped_date = $row['shipped_date'];
}

$select_users = "select * from SEED_USERS where uid = '$user_uid'";
try {
	$stmt = $db->prepare($select_users);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}

$result = $stmt->fetchAll();
foreach($result as $user_array){
	$sfname = $user_array['sfname'];
	$slname = $user_array['slname'];
	
	$sdepartment = $user_array['department'];
	$sinstitution = $user_array['institution'];
	$sstreet_address = $user_array['street_address'];
	$scountry = $user_array['scountry'];

	$scity = $user_array['city'];
	$sstate = $user_array['state'];
	$szip = $user_array['zip'];
	$semail = $user_array['email_address'];
	$sphone = $user_array['phone'];
	$sproject_leader = $user_array['project_leader'];
	$spurchase_order = $user_array['purchase_order_no'];
	$bfname = $user_array['bfname'];
	$bcountry = $user_array['bcountry'];

	$blname = $user_array['blname'];
	$bdepartment = $user_array['billing_department'];
	$binstitution = $user_array['billing_institution'];
	$bstreet_address = $user_array['billing_street_address'];
	$bcity = $user_array['billing_city'];
	$bstate = $user_array['billing_state'];
	$bzip = $user_array['billing_zip'];
	$bemail = $user_array['billing_email_address'];

	$bphone = $user_array['phone'];
}

$display_block = '
<h2>Seed Order Invoice - Invoice Number '.$invoice_no .'</h2>

<a class="admin smallerfont" href="/admin/request_admin.php">Return to Seed Requests</a>

<!--
<p><form method="post" action="/prj/AcDsTagging/Admin/navigate_request_view.php">
<input type="hidden" name="invoice_no" value="$invoice_no">
<table>
<tr>
<td></td>
<td>
	<input type="submit" value="Previous Record" name="Previous">
</td>
<td>
	<input type="submit" value="Next Record" name="Next">
</td>
</tr>
</table>
</form>
</p>
-->

<table>
<tr>
	<td>Order Date:</td>
	<td width="150" align="left">'. $order_date .'</td>
	<td>-</td>
</tr>
<tr>
	<td>Invoice Date:</td>
	<td>
		<form method="post" action="/admin/request_invoice.php">
		'.$invoice_date.'
		<input type="hidden" name="invoice_date" value="'. $invoice_date .'">
		<input type="hidden" name="invoice_no" value="'.$invoice_no .'">
	</td>
	<td>
		<input type="submit" name="submit" value="Invoice Order">
		</form>
	</td>
</tr>
<tr>
	<td>Shipped Date:</td>
	<td>
		<form method="post" action="/admin/request_shipped.php">
		'.$shipped_date.'
		<input type="hidden" name="shipped_date" value="'.$shipped_date.'">
		<input type="hidden" name="invoice_no" value="'.$invoice_no .'">
	</td>
	<td>
		<input type="submit" name="submit" value="Shipped Order">
		</form>
	</td>
</tr>
<tr>
	<td>Payment Rec:</td>
	<td>
		<form method="post" action="/admin/request_pay_recd.php">
		'.$payment_recvd_date.'
		<input type="hidden" name="payment_recvd_date" value="'.$payment_recvd_date.'">
		<input type="hidden" name="invoice_no" value="'.$invoice_no.'">
	</td>
	<td width="150">
		<input type="submit" name="submit" value="Payment Received">
		</form>
	</td>
</tr>
</table>

<p></p>

<table width="100%">
<tr>
	<td width="50%">
	<form method="post" action="/admin/save_changes.php" id="save_changes">
	<table>
	<h2>Ship To:</h2>
		<tr>
			<td width="100">First Name</td>
			<td width="300">
				<input type="text" name="sfname" value="'. $sfname .'">
			</td>
		</tr>
		<tr>
			<td width="100">Last Name</td>
			<td width="300">
				<input type="text" name="slname" value="'. $slname .'">
			</td>
		</tr>
		<tr>
			<td width="100">Department</td>
			<td width="300">
				<input type="text" name="sdepartment" value="'. $sdepartment .'">
			</td>
		</tr>
		<tr>
			<td width="100">Company/School</td>
			<td width="300">
				<input type="text" name="sinstitution" value="'. $sinstitution .'">
			</td>
		</tr>
		<tr>
			<td width="100">Street Address</td>
			<td width="300">
				<input type="text" name="sstreet_address" value="'. $sstreet_address .'">
			</td>
		</tr>
		<tr>
			<td width="100">City</td>
			<td width="300">
				<input type="text" name="scity" value="'. $scity .'">
			</td>
		</tr>
		<tr>
			<td width="100">Country</td>
			<td width="300">
				<input type="text" name="scountry" value="'. $scountry .'">
			</td>
		</tr>
		<tr>
			<td width="100">State</td>
			<td width="300">
				<input type="text" name="sstate" value="'. $sstate .'">
			</td>
		</tr>
		<tr>
			<td width="100">Zip</td>
			<td width="300">
				<input type="text" name="szip" value="'. $szip .'">
			</td>
		</tr>
		<tr>
			<td width="100">Email</td>
			<td width="300">
				<input type="text" name="semail" value="'. $semail .'">
			</td>
		</tr>
		<tr>
			<td width="100">Phone #</td>
			<td width="300">
				<input type="text" name="sphone" value="'. $sphone .'">
			</td>
		</tr>
		<tr>
			<td width="100"><b>Project Leader</b></td>
			<td width="300">
				<input type="text" name="sproject_leader" value="'. $sproject_leader .'">
			</td>
		</tr>
		</table>
	</td>
	<td width="50%">
	
	<table>
	<h2>Bill To:</h2>
	<tr>
		<td width="100">First Name</td>
		<td width="300">
			<input type="text" name="bfname" value="'. $bfname .'">
		</td>
	</tr>
	<tr>
		<td width="100">Last Name</td>
		<td width="300">
			<input type="text" name="blname" value="'. $blname .'">
		</td>
	</tr>
	<tr>
		<td width="100">Department</td>
		<td width="300">
			<input type="text" name="bdepartment" value="'. $bdepartment .'">
		</td>
	</tr>
	<tr>
		<td width="100">Company/School</td>
		<td width="300">
			<input type="text" name="binstitution" value="'. $binstitution .'">
		</td>
	</tr>
	<tr>
		<td width="100">Street Address</td>
		<td width="300">
			<input type="text" name="bstreet_address" value="'. $bstreet_address .'">
		</td>
	</tr>
	<tr>
		<td width="100">City</td>
		<td width="300">
			<input type="text" name="bcity" value="'. $bcity .'">
		</td>
	</tr>
	<tr>
		<td width="100">Country</td>
		<td width="300">
			<input type="text" name="bcountry" value="'. $bcountry .'">
		</td>
	</tr>
	<tr>
		<td width="100">State</td>
		<td width="300">
			<input type="text" name="bstate" value="'. $bstate .'">
		</td>
	</tr>
	<tr>
		<td width="100">Zip</td>
		<td width="300">
			<input type="text" name="bzip" value="'. $bzip .'">
		</td>
	</tr>
	<tr>
		<td width="100">Email</td>
		<td width="300">
			<input type="text" name="bemail" value="'. $bemail .'">
		</td>
	</tr>
	<tr>
		<td width="100">Phone #</td>
		<td width="300">
			<input type="text" name="bphone" value="'. $bphone .'">
		</td>
	</tr>
	<tr>
		<td width="100"><b>Purchase Order #</b></td>
		<td width="300">
			<input type="text" name="spurchase_order" value="'. $spurchase_order .'">
		</td>
	</tr>
	</table>
	</td>
	</tr>
</table>
				
<p></p>

<h2>Barcodes ordered:</h2>

<table width="100%" border="0" cellspacing="5"  style="font-size:12px">
<tr>
<th width="5%" align="center">Packs</th>
<th width="15%" align="center">Barcode</th>
<th width="10%" align="center">Barcode Link</th>
<th width="5%" align="center">Segr. Ac</th>
<th width="10%" align="center">Phenotype</th>
<th width="20%" align="center">Nursery Propagation</th>
<th width="10%" align="center">Genotyping/ Addressing Errors checked?</td>
<th width="10%" align="center">AC Immobilized Stocks</th>
<th width="10%" align="center">Tester</th>
<th width="20%" align="center">Notes</th>
<th width="10%" align="center">Total</th>
</tr>
';


$select_invoice = "select * from INVOICES where invoice_no = '". $invoice_no ."'";

try {
	$stmt = $db->prepare($select_invoice);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}


$i=0;
$subtotal = 0;
$check_order_price = 0;
$result = $stmt->fetchAll();

foreach ($result as $invoice_array){
	$uid = $invoice_array['uid'];
	$quantity = $invoice_array['order_quantity'];
	$barcode = $invoice_array['order_barcode'];
	$pricing = $invoice_array['order_price'];
	$check_order_price = $pricing;
	$price = $quantity*$pricing;
	$segregates_ac = $invoice_array['segregates_ac'];
	$phenotype = $invoice_array['phenotype'];
	$nursery_propagation = $invoice_array['nursery_propagation'];
	$genotyping = $invoice_array['genotyping'];
	$ac_immobilized_stock = $invoice_array['ac_immobilized_stock'];
	$tester = $invoice_array['tester'];
	$note = $invoice_array['note'];

	$subtotal = $subtotal + $price;
	$shipping = $invoice_array['order_shipping'];
	$certification = $invoice_array['order_certification'];
	$ship_cost = $invoice_array['ship_cost'];
	if($ship_cost==NULL) $ship_cost=0;
	$grand_total = $invoice_array['order_total'];
	if($segregates_ac ==1) $chk = "checked";
	else $chk ="";
	$display_block .= "
<tr>
<!--form method=\"post\" action=\"/prj/AcDsTagging/Admin/save_changes.php\"-->

<input type=\"hidden\" name=\"invoice_no\" value=\"$invoice_no\">
<input type=\"hidden\" name=\"uid$i\" value=\"$uid\">
<input type=\"hidden\" name=\"user_uid\" value=\"$user_uid\">
<input type=\"hidden\" name=\"pricing\" value=\"$pricing\">
<!--input type=\"hidden\" name=\"shipping\" value=\"$shipping\"-->
<input type=\"hidden\" name=\"certification\" value=\"$certification\">

<td width=\"1%\" align=\"center\">
	<textarea cols=\"1\" rows=\"2\" name=\"quantity$i\" maxlength=\"2\" style=\"font-family:Verdana; font-size:10px\">$quantity</textarea>
</td>
<td width=\"5%\" align=\"center\">
	<textarea cols=\"10\" rows=\"2\" name=\"barcode$i\" maxlength=\"255\" style=\"font-family:Verdana; font-size:10px\">$barcode</textarea>
</td>
<td width=\"5%\" align=\"center\">
	<!-- <a href=\"/admin/data_admin.php?id=$barcode\">$barcode</a> -->
	$barcode
</td>
<td width=\"1%\" align=\"center\">
	<input type=\"checkbox\" name=\"segregates_ac$i\" value=\"true\"  $chk >
</td>
<td width=\"10%\" align=\"center\">
	<textarea cols=\"12\" rows=\"2\" name=\"phenotype$i\" maxlength=\"255\" style=\"font-family:Verdana; font-size:10px\">$phenotype</textarea>
</td>
<td width=\"10%\" align=\"center\">
	<textarea cols=\"12\" rows=\"2\" name=\"nursery_propagation$i\" maxlength=\"255\" style=\"font-family:Verdana; font-size:10px\">$nursery_propagation</textarea>
</td>
<td width=\"10%\" align=\"center\">
	<textarea cols=\"12\" rows=\"2\" name=\"genotyping$i\" maxlength=\"255\" style=\"font-family:Verdana; font-size:10px\">$genotyping</textarea>
</td>
<td width=\"10%\" align=\"center\">
	<textarea cols=\"20\" rows=\"2\" name=\"ac_immobilized_stock$i\" maxlength=\"255\" style=\"font-family:Verdana; font-size:10px\">$ac_immobilized_stock</textarea>
</td>
<td width=\"10%\" align=\"center\">
	<textarea cols=\"12\" rows=\"2\" name=\"tester$i\" maxlength=\"255\" style=\"font-family:Verdana; font-size:10px\">$tester</textarea>
</td>
<td width=\"10%\" align=\"center\">
	<textarea cols=\"40\" rows=\"2\" name=\"note$i\" maxlength=\"255\" style=\"font-family:Verdana; font-size:10px\">$note</textarea>
</td>
<td width=\"15%\" align=\"center\">
	$$price
</td>
</tr>
";
	$i = $i +1;
};

$display_block .= "
</table>
<p>Institution type: 
";

if ($check_order_price == 100){
	$display_block .= "<label><input type=\"radio\" name=\"us_ac_ind\" value=\"100\" checked=\"checked\">US Academic</label>
	<label><input type=\"radio\" name=\"us_ac_ind\" value=\"160\" >US Industry</label>";
} else {
	$display_block .= "<label><input type=\"radio\" name=\"us_ac_ind\" value=\"100\" >US Academic</label>
	<label><input type=\"radio\" name=\"us_ac_ind\" value=\"160\" checked=\"checked\">US Industry</label>";
}

$display_block .= "
</p>
<p>Add a barcode:
	<input type='text' name='barcodeadd' value=''>
	<input type=\"hidden\" name=\"border\" value=\"$order_date\">
	<span style='background-color: teal;color:white; padding:2px 12px 3px 12px; cursor:pointer' onclick='barcodeadd()'>Add barcode</span>
	<br>
	*NOTE: Click on \"Save Changes\" to update the Grand Total.
	<script language='javascript' type='text/javascript'>
	function barcodeadd(){
		bcode = $(\"input[name='barcodeadd']\").val();
		binv = 139;
		user_uid = $(\"input[name='user_uid']\").val();
		border = $(\"input[name='border']\").val();
		us_ac_ind = $('input:radio[name=\"us_ac_ind\"]:checked').val();
		console.log(bcode, binv, user_uid, border, us_ac_ind);
		ajax_barcodeadd(bcode, binv, user_uid, border, us_ac_ind);
	}
	function ajax_barcodeadd(bcode, binv, user_uid, border, us_ac_ind){
		var url = 'ajax_barcodeadd.php';	
		$.ajax({
			//* file
			url: url,
			//* data required
			data: {
				bcode: bcode,
				binv: binv,
				user_uid: user_uid,
				border: border,
				us_ac_ind: us_ac_ind
			},
			//* datatype returned
			dataType: 'json',
			//* request method
			method: 'GET',
			//* If success
			success: function(data){
				console.log(data);
				$('#barcodemsg').css('display', 'block');
				$('#save_changes').submit();
				window.location.reload();
			},
			//* If error. show the error in console.log
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(textStatus+' - '+errorThrown);
				console.log(XMLHttpRequest.responseText);
			}
		});
	}
	</script>
</p>
<hr />
<p>
";

$display_block .= '
<table width="100%">
<tr>
<td style="font-size:12px" width="90%" align="right">Subtotal ($)</td>
<td align="right" style="border: 1px solid gainsboro">'. $subtotal .'</td>
</tr>
<tr>
<td style="font-size:12px" width="90%" align="right">'.getcert($certification).'</td>
<td align="right" style="border: 1px solid gainsboro"><span id="certvalue">'. (($certification == 0) ? 0 : $certification) .'</span></td>
</tr>
<tr>
<td style="font-size:12px" width="90%" align="right">Expedited Shipping ($)</td>
<td align="right">
	<input type="text" name="ship_cost" style="text-align:right" width="5%" maxlength="5" size="5" value="'. $ship_cost .'">
</td>
</tr>
<tr>
<td style="font-size:12px" width="90%" align="right">Grand Total ($)</td>
<td align="right" style="border: 1px solid gainsboro"><span id="grandtotal">'. $grand_total .'</span></td>
</tr>
</table>
';

$display_block .= "
<table>
<tr>
<td/><td/><td/><td/><td/>
<td align=\"right\" width=\"5%\">
	<input type=\"submit\" name=\"submit\" value=\"Save Changes\"></input>
</td>
</tr>
</table>
</form>

<form method=\"post\" action=\"/admin/delete_invoice.php\">
<table>
<tr>
<td/><td/><td/><td/><td/>
<td width=\"135\">
	<p>&nbsp;</p><input type=\"hidden\" name=\"invoice_no\" value=\"$invoice_no\"> 
</td>
<td width=\"5%\" align=\"right\">
	<input type=\"submit\" name=\"delete\" value=\"Delete\" onclick=\"confirmAndDelete();\">

<script language=\"javascript\" type=\"text/javascript\">
	function confirmAndDelete(){
	var agree=confirm(\"Are you sure you wish to delete this invoice?\");
	if(agree)
		return true;
	else
		return false;
	}
</script>

</td>
</tr></table>
</form>

<p></p>
";

echo $display_block;

?>
</div>
		<div id="sidebar">
			<div class="section">
				<?php require("../lib/sidebar.php") ?>
			</div>
			<div id="section" >
				<?php require("../lib/sidebar_admin.php") ?>
			</div>
		</div>
	</div>
</div>
<?php require("../lib/footer.php") ?>

<?php 
function getcert($val){
	$txt = '';
	if($val == 0){
		$txt .= '<span onclick="updatecert(this)" style="background-color: teal;color:white; padding:2px 12px 3px 12px; cursor:pointer">ADD</span>';
	}
	else {
		$txt .= '<span onclick="updatecert(this)" style="background-color: teal;color:white; padding:2px 12px 3px 12px; cursor:pointer">REMOVE</span>';
	}
	$txt .= " Phytosanitary Cert. ($)
	<script language='javascript' type='text/javascript'>
		function updatecert(tt){
			val = $(tt).html();
			if(val == 'REMOVE'){
				// Get the initial certificate value must be 60
				cert = $(\"input[name='certification']\").val();
				// Change the remove to add
				$(tt).html('ADD');
				// Update the box, input 0
				$(\"#certvalue\").html('0')
				// Get the grandtotal and remove the 60 from it
				gt = $(\"#grandtotal\").html()
				$(\"#grandtotal\").html(parseInt(gt) - 60);
				// Set the certificate value to 0
				$(\"input[name='certification']\").val(0);
			} else if(val == 'ADD'){
				cert = $(\"input[name='certification']\").val();
				$(tt).html('REMOVE');
				$(\"#certvalue\").html('60')
				gt = $(\"#grandtotal\").html()
				$(\"#grandtotal\").html(parseInt(gt) + 60)
				$(\"input[name='certification']\").val(60);
			}
		}
	</script>
	";
	return $txt;
}
?>