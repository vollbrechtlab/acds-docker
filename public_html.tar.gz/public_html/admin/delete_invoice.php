<?php require("../lib/page_top.php") ?>
<?php require("../lib/login_check.php"); ?>
<?php
$invoice_no = mysql_real_escape_string($_POST['invoice_no']);
	
$query = "select distinct user_uid from INVOICES where invoice_no = '$invoice_no'";

try {
	$stmt = $db->prepare($query);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}

#echo "$invoice_no<br>";

$result = $stmt->fetch();
$user = $result['user_uid'];
$count = $stmt->rowCount();

#echo "$user<br>";
#echo "$count<br>";


echo '<h2>Seed Order Invoice - Invoice Number '.$invoice_no .'</h2>';
echo "Effected number of rows: " . $count ."<br><br>";


$query = "delete from INVOICES where invoice_no = '$invoice_no'";
echo "$query<br>";
try {
	$stmt = $db->prepare($query);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}

$query2 = "delete from SEED_USERS where uid = '$user'";
echo "$query2<br>";
try {
	$stmt = $db->prepare($query2);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}

$redirect_query = "select invoice_no from INVOICES where invoice_no > '$invoice_no' order by invoice_no ASC limit 1";
try {
	$stmt = $db->prepare($redirect_query);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}
$n = $stmt->rowCount();
$result = $stmt->fetch();
$new_barcode = $result['invoice_no'];

if($n==0) {
	#header("Location: request_admin.php");
} else {
	#header("Location: request_view.php?invoice_no=".$new_barcode);
}
#header("Location: request_view.php?invoice_no=$invoice_no");
#exit();

?>
<a href="request_admin.php">Manage invoices</a>
<?php require("../lib/page_body.php") ?>