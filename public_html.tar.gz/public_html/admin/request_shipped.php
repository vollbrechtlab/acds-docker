<?php require("../lib/page_top.php") ?>
<?php require("../lib/login_check.php"); ?>
<?php
$invoice_no = mysql_real_escape_string($_POST['invoice_no']);
	
$update = "update INVOICES set shipped_date = now() where invoice_no = '$invoice_no'";

try {
	$stmt = $db->prepare($update);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}

header("Location: request_view.php?invoice_no=$invoice_no");
exit();
	
?>
<?php require("../lib/page_body.php") ?>