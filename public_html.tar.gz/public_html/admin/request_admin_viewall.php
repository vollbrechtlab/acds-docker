<?php require("../lib/page_top.php") ?>
<?php require("../lib/login_check.php"); ?>
<?php
$passed = mysql_real_escape_string($_GET['passed']);
$search_in2 = 0;

if($_GET['submit'] == "Clear"){
	unset($_GET);
	unset($passed);
}

#echo $passed . "<br>";

$get_users = "select * from SEED_USERS order by uid desc";

try {
	$stmt = $db->prepare($get_users);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}

$counter = 0;

/*


				if (($_SESSION['field_in2']))
				{
					echo "<a href=\"/prj/AcDsTagging/Admin/request_admin_viewall.php?destroy=true\" style=\"white-space:nowrap\">Clear Search</a> <br />";
					
				}
		 
				?>


 */

$display_block = '
<form method="get" action="/admin/request_admin_viewall.php">
	Search By: 
	<select name="field">
		<option value="invoice_no" '. ((mysql_real_escape_string($_GET['field']) == "invoice_no") ? "selected: selected" : "" ).'>Invoice Number</option>
		<option value="order_barcode" '. ((mysql_real_escape_string($_GET['field']) == "order_barcode") ? "selected: selected" : "" ).'>Barcode </option>
		<option value="order_date" '. ((mysql_real_escape_string($_GET['field']) == "order_date") ? "selected: selected" : "" ).'>Order Date</option>
		<option value="shipped_date" '. ((mysql_real_escape_string($_GET['field']) == "shipped_date") ? "selected: selected" : "" ).'>Shipped Date</option>
		<option value="sfname" '. ((mysql_real_escape_string($_GET['field']) == "sfname") ? "selected: selected" : "" ).'>Shipped to name</option>
		<option value="project_leader" '. ((mysql_real_escape_string($_GET['field']) == "project_leader") ? "selected: selected" : "" ).'>Project leader</option>
		<option value="email_address" '. ((mysql_real_escape_string($_GET['field']) == "email_address") ? "selected: selected" : "" ).'>Shipped to email</option>
		<option value="segregates_ac" '. ((mysql_real_escape_string($_GET['field']) == "segregates_ac") ? "selected: selected" : "" ).'>Segregates Ac</option>
		<option value="nursery_propagation" '. ((mysql_real_escape_string($_GET['field']) == "nursery_propagation") ? "selected: selected" : "" ).'>Nursery propagation</option>
		<option value="genotyping" '. ((mysql_real_escape_string($_GET['field']) == "genotyping") ? "selected: selected" : "" ).'>Genotyping</option>
		<option value="note" '. ((mysql_real_escape_string($_GET['field']) == "note") ? "selected: selected" : "" ).'>Notes</option>
	</select>
	for 
	<input type="text" name="search" size="15" value="'.mysql_real_escape_string($_GET['search']).'">
	<input type="hidden" name="passed" value="1">
	<input type="submit" name="submit" value="Search">
	<input type="submit" name="submit" value="Clear">
</form>
<br>
<table class="tab">
<thead>
<tr>
	<th width=\"10%\">Invoice Number</th>
	<th width=\"10%\">Barcode</th>
	<th width=\"10%\">Shipped To Name</th>
	<th width=\"10%\">Project Leader</th>
	<th width=\"10%\">Order Date</th>
	<th width=\"10%\">Ship To Email</th>
	<th width=\"10%\">Shipped date</th>
	<th width=\"5%\">Segregates Ac</th>
	<th width=\"10%\">Nursery Propagation</th>
	<th width=\"10%\">Genotyping</th>
	<th width=\"10%\">Notes</th>
</tr>
</thead>
<tbody>
';

$result = $stmt->fetchAll();

foreach($result as $users_array){
	$uid = $users_array['uid'];
	$pl = $users_array['project_leader'];
	$semail = $users_array['email_address'];
	$sfname = $users_array['sfname'];
	$slname = $users_array['slname'];
	$name = "$sfname $slname";
	
	if ($_GET['passed'] == 1){ //start of outer big if	
		#echo "inside";
		$searchWord = $_GET['field'];
		$forWord= $_GET['search'];
		if ($searchWord=='invoice_no'||$searchWord=='order_barcode'||$searchWord=='order_date'||$searchWord=='shipped_date'){	
			$searchQuery = "Select * from INVOICES where user_uid = $uid and $searchWord like '$forWord'  ORDER by user_uid ";
		}
		else if($searchWord=='segregates_ac'){
			if($forWord=='yes'||$forWord=='Yes'||$forWord=='YES'||$forWord=='Y'||$forWord=='y'){				
				$searchQuery = "Select * from INVOICES where user_uid = $uid and segregates_ac = 1  ORDER by user_uid";
			}
			if($forWord=='no' || $forWord=='No'||$forWord=='NO'||$forWord=='N'||$forWord=='n'){					
				$searchQuery = "Select * from INVOICES where user_uid = $uid and segregates_ac = 0 ORDER by user_uid";
			}
		}
		else if($searchWord=='sfname'||$searchWord=='project_leader'||$searchWord=='email_address'){
			$searchQuery = "Select * from SEED_USERS,INVOICES where SEED_USERS.uid=INVOICES.user_uid and user_uid= $uid and $searchWord like '%$forWord%' ORDER by user_uid";
		}
		else{
			$searchQuery = "Select * from INVOICES where user_uid = $uid and $searchWord like '%$forWord%'  ORDER by user_uid";
		}
		#echo $searchQuery . "<br>";
		#$_SESSION['field_in2'] = mysql_real_escape_string($_POST[field]);
		$field_in2 = mysql_real_escape_string($_GET[field]);
		#$_SESSION['search_in2'] = mysql_real_escape_string(str_replace("*", "", trim($_POST[search])));
		$search_in2 = mysql_real_escape_string(str_replace("*", "", trim($_GET[search])));
	}//end of outer big if
	#else if($_SESSION['search_in2']!=""){
	else if($search_in2 != ""){
		#$searchWord = $_SESSION['search_in2'];
		$searchWord = $search_in2;
		#$searchField = $_SESSION['field_in2'];
		$searchField = $field_in2;
		$searchQuery = "Select * from INVOICES where user_uid = $uid and $searchWord like '%$forWord%'  ORDER by user_uid";
	}
	else{
		$searchQuery = "select * from INVOICES WHERE user_uid = $uid ORDER by user_uid";
	};

	#echo $searchQuery . "<br>";
	
	$get_invoice = $searchQuery;
	try {
		$stmt = $db->prepare($get_invoice);
		$result = $stmt->execute();
	}
	catch(PDOException $ex) {
		die("Failed to run query: " . $ex->getMessage());
	}

	$result = $stmt->fetchAll();
	foreach ($result as $invoice_array){
		$barcode = $invoice_array['order_barcode'];
		$invoice_no = $invoice_array['invoice_no'];
		$order_date = $invoice_array['order_date'];
		$shipped_date = $invoice_array['shipped_date'];
		$segregates_ac = $invoice_array['segregates_ac'];
		if($segregates_ac==1) $segregates_ac="Yes";
		else if($segregates_ac==0)  $segregates_ac="No";
		$nursery_propagation = $invoice_array['nursery_propagation'];
		$genotyping = $invoice_array['genotyping'];
		$note = $invoice_array['note'];
			
		$display_block .= "
		<tr>
		<td width=\"10%\" align=\"center\"><a href=\"/admin/request_view.php?invoice_no=$invoice_no\">#$invoice_no</a></td>
		<td width=\"10%\">$barcode</td>
		<td width=\"10%\">$name</td>
		<td width=\"10%\">$pl</td>
		<td width=\"10%\">$order_date</td>
		<td width=\"10%\">$semail</td>
		<td width=\"10%\">$shipped_date</td>
		<td width=\"5%\">$segregates_ac</td>
		<td width=\"10%\">$nursery_propagation</td>
		<td width=\"10%\">$genotyping</td>
		<td width=\"10%\">$note</td>
		</tr>
		";
		$counter= $counter+1;//just for testing
	};//end of inner foreach
};//end of outer big foreach



$display_block .= "</tbody></table>";

echo $display_block;

?>
</div>
		<div id="sidebar">
			<div class="section">
				<?php require("../lib/sidebar.php") ?>
			</div>
			<div id="section" >
				<?php require("../lib/sidebar_admin.php") ?>
			</div>
		</div>
	</div>
</div>
<?php require("footer.php") ?>