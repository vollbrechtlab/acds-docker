<?php require("../lib/login_check.php"); ?>
<?php 
$bcode = mysql_real_escape_string($_GET['bcode']);
$binv = mysql_real_escape_string($_GET['binv']);
$user_uid = mysql_real_escape_string($_GET['user_uid']);
$border = mysql_real_escape_string($_GET['border']);
$us_ac_ind = mysql_real_escape_string($_GET['us_ac_ind']);

if($bcode == ''){
	echo json_encode("ERROR: no barcode provided.");
	exit;
}

$select_invoice = "insert into INVOICES (order_barcode, invoice_no, user_uid, order_date, order_quantity, order_price) values('$bcode', '$binv', '$user_uid', '$border', '1', '$us_ac_ind')";

#echo $select_invoice;
#echo "<br>";

try {
	$stmt = $db->prepare($select_invoice);
	$result = $stmt->execute();
}
catch(PDOException $ex) {
	die("Failed to run query: " . $ex->getMessage());
}

echo json_encode("Barcode added. Click on Save changes to update the page.");
?>